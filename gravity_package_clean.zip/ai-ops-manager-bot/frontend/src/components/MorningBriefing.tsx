import React from 'react';
import { motion } from 'framer-motion';
import { Sun, Target, CalendarClock } from 'lucide-react';

export const MorningBriefing: React.FC = () => {
    return (
        <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
        >
            <div className="flex justify-between items-start mb-4">
                <div>
                    <h2 className="text-gray-400 text-sm font-medium">Good Morning,</h2>
                    <h1 className="text-3xl font-light tracking-tight">Denis</h1>
                </div>
                <div className="flex items-center gap-2 bg-white/5 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10">
                    <Sun size={16} className="text-yellow-400" />
                    <span className="text-sm font-medium">24°C</span>
                </div>
            </div>

            <div className="glass-card p-4 bg-gradient-to-br from-blue-500/20 to-purple-500/20 border-white/10">
                <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 rounded-full bg-blue-500/20 text-blue-400">
                        <Target size={18} />
                    </div>
                    <div>
                        <div className="text-xs text-gray-400 uppercase tracking-wider">Today's Goal</div>
                        <div className="font-medium">Review Q3 Financial Report</div>
                    </div>
                </div>

                <div className="h-px bg-white/10 my-3" />

                <div className="flex items-center gap-3">
                    <div className="p-2 rounded-full bg-purple-500/20 text-purple-400">
                        <CalendarClock size={18} />
                    </div>
                    <div>
                        <div className="text-xs text-gray-400 uppercase tracking-wider">Schedule</div>
                        <div className="font-medium">3 Meetings • 5 Tasks Due</div>
                    </div>
                </div>
            </div>
        </motion.div>
    );
};

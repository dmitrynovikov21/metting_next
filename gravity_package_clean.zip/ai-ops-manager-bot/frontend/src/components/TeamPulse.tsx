import React from 'react';
import { motion } from 'framer-motion';

const TEAM = [
    { id: 1, name: 'Ekaterina', status: 'online', initials: 'EK' },
    { id: 2, name: 'Violetta', status: 'busy', initials: 'VI' },
    { id: 3, name: 'Kirill', status: 'offline', initials: 'KI' },
    { id: 4, name: 'Radmir', status: 'online', initials: 'RA' },
    { id: 5, name: 'Denis', status: 'busy', initials: 'DE' },
];

export const TeamPulse: React.FC = () => {
    return (
        <div className="mb-8">
            <h3 className="text-lg font-medium mb-4">Team Pulse</h3>
            <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
                {TEAM.map((member, i) => (
                    <motion.div
                        key={member.id}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="flex flex-col items-center gap-2 min-w-[64px]"
                    >
                        <div className="relative">
                            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-gray-700 to-gray-800 flex items-center justify-center border border-white/10 shadow-lg">
                                <span className="font-medium text-sm">{member.initials}</span>
                            </div>
                            <div
                                className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-[#0f0f0f] ${member.status === 'online'
                                        ? 'bg-green-500'
                                        : member.status === 'busy'
                                            ? 'bg-red-500'
                                            : 'bg-gray-500'
                                    }`}
                            />
                        </div>
                        <span className="text-xs text-gray-400">{member.name}</span>
                    </motion.div>
                ))}
            </div>
        </div>
    );
};

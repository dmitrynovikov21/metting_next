import React from 'react';
import { motion } from 'framer-motion';
import { Users, Link as LinkIcon, Clock, Video } from 'lucide-react';

interface Meeting {
    id: number;
    title: string;
    time: string;
    platform: 'Zoom' | 'Meet';
    attendees: string[];
    meetingUrl: string;
    isNow?: boolean;
}

interface MeetingPrepCardProps {
    meeting: Meeting;
    onJoin: () => void;
}

export const MeetingPrepCard: React.FC<MeetingPrepCardProps> = ({ meeting, onJoin }) => {
    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card p-6 mb-4"
        >
            {/* Header */}
            <div className="flex justify-between items-start mb-4">
                <div>
                    <h3 className="text-xl font-medium mb-1">{meeting.title}</h3>
                    <div className="flex items-center gap-2 text-sm text-gray-400">
                        <Clock size={14} />
                        <span>{meeting.time}</span>
                        <span>•</span>
                        <span>{meeting.platform}</span>
                    </div>
                </div>
                {meeting.isNow && (
                    <div className="flex items-center gap-2 bg-red-500/20 text-red-400 px-2 py-1 rounded-full text-xs">
                        <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                        LIVE
                    </div>
                )}
            </div>

            {/* Attendees */}
            <div className="mb-4">
                <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                    <Users size={14} />
                    <span>Attendees</span>
                </div>
                <div className="flex -space-x-2">
                    {meeting.attendees.map((attendee, idx) => (
                        <div
                            key={idx}
                            className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-700 to-gray-800 flex items-center justify-center border-2 border-[#0f0f0f] text-xs font-medium"
                            title={attendee}
                        >
                            {attendee.split(' ').map(n => n[0]).join('')}
                        </div>
                    ))}
                </div>
            </div>

            {/* Quick Links */}
            <div className="mb-4">
                <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                    <LinkIcon size={14} />
                    <span>Quick Links</span>
                </div>
                <div className="flex gap-2">
                    <button className="text-xs px-3 py-1 bg-white/5 hover:bg-white/10 rounded-lg transition-colors border border-white/10">
                        Agenda
                    </button>
                    <button className="text-xs px-3 py-1 bg-white/5 hover:bg-white/10 rounded-lg transition-colors border border-white/10">
                        Last Notes
                    </button>
                </div>
            </div>

            {/* Join Button */}
            <motion.button
                onClick={onJoin}
                whileTap={{ scale: 0.95 }}
                className={`w-full py-3 rounded-xl font-medium flex items-center justify-center gap-2 transition-all ${meeting.isNow
                        ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg shadow-blue-600/30 animate-pulse'
                        : 'bg-blue-600 hover:bg-blue-500 text-white'
                    }`}
            >
                <Video size={20} />
                <span>Join Meeting</span>
            </motion.button>
        </motion.div>
    );
};

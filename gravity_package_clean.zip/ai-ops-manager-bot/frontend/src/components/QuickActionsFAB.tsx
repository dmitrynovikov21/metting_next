import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Mic, Calendar, CheckSquare, Timer } from 'lucide-react';

interface QuickActionProps {
    icon: React.ReactNode;
    label: string;
    onClick: () => void;
    delay: number;
}

const QuickAction: React.FC<QuickActionProps> = ({ icon, label, onClick, delay }) => (
    <motion.button
        initial={{ opacity: 0, y: 20, scale: 0.8 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.8 }}
        transition={{ delay, duration: 0.2 }}
        onClick={onClick}
        className="flex items-center gap-3 w-full p-3 mb-2 rounded-xl bg-white/10 backdrop-blur-md border border-white/10 text-white shadow-lg active:scale-95 transition-transform"
    >
        <div className="p-2 rounded-full bg-blue-500/20 text-blue-400">
            {icon}
        </div>
        <span className="font-medium whitespace-nowrap">{label}</span>
    </motion.button>
);

interface QuickActionsFABProps {
    onFocusMode?: () => void;
    onVoiceRecord?: () => void;
}

export const QuickActionsFAB: React.FC<QuickActionsFABProps> = ({ onFocusMode, onVoiceRecord }) => {
    const [isOpen, setIsOpen] = useState(false);

    const toggleOpen = () => setIsOpen(!isOpen);

    const actions = [
        { icon: <Timer size={20} />, label: 'Focus Mode', onClick: () => onFocusMode?.() },
        { icon: <CheckSquare size={20} />, label: 'New Task', onClick: () => console.log('New Task') },
        { icon: <Mic size={20} />, label: 'Record Voice', onClick: () => onVoiceRecord?.() },
        { icon: <Calendar size={20} />, label: 'Schedule Meeting', onClick: () => console.log('Schedule Meeting') },
    ];

    return (
        <div className="relative z-50 flex flex-col items-center">
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.9 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.9 }}
                        className="absolute bottom-full mb-4 flex flex-col items-center gap-2 min-w-[200px]"
                    >
                        {actions.map((action, index) => (
                            <QuickAction
                                key={action.label}
                                icon={action.icon}
                                label={action.label}
                                onClick={() => {
                                    action.onClick();
                                    setIsOpen(false);
                                }}
                                delay={index * 0.05}
                            />
                        ))}
                    </motion.div>
                )}
            </AnimatePresence>

            <motion.button
                onClick={toggleOpen}
                whileTap={{ scale: 0.9 }}
                animate={{ rotate: isOpen ? 45 : 0 }}
                className={`p-4 rounded-full shadow-lg shadow-blue-600/20 text-white transition-colors ${isOpen ? 'bg-gray-700' : 'bg-blue-600'
                    }`}
            >
                <Plus size={24} />
            </motion.button>

            {/* Backdrop to close when clicking outside */}
            {isOpen && (
                <div
                    onClick={() => setIsOpen(false)}
                    className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[-1]"
                />
            )}
        </div>
    );
};

import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, X, Send } from 'lucide-react';

interface VoiceVisualizerProps {
    onClose: () => void;
    onSend?: (audioBlob: Blob) => void;
}

export const VoiceVisualizer: React.FC<VoiceVisualizerProps> = ({ onClose, onSend }) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [isRecording, setIsRecording] = useState(false);
    const [duration, setDuration] = useState(0);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioContextRef = useRef<AudioContext | null>(null);
    const analyserRef = useRef<AnalyserNode | null>(null);
    const animationFrameRef = useRef<number>(0);
    const chunksRef = useRef<Blob[]>([]);

    const formatDuration = (seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    };

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

            // Setup MediaRecorder
            const mediaRecorder = new MediaRecorder(stream);
            mediaRecorderRef.current = mediaRecorder;
            chunksRef.current = [];

            mediaRecorder.ondataavailable = (e) => {
                if (e.data.size > 0) {
                    chunksRef.current.push(e.data);
                }
            };

            mediaRecorder.start();
            setIsRecording(true);

            // Setup Audio Visualization
            const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
            const analyser = audioContext.createAnalyser();
            const source = audioContext.createMediaStreamSource(stream);

            analyser.fftSize = 256;
            source.connect(analyser);

            audioContextRef.current = audioContext;
            analyserRef.current = analyser;

            visualize();
        } catch (err) {
            console.error('Error accessing microphone:', err);
        }
    };

    const stopRecording = () => {
        if (mediaRecorderRef.current && isRecording) {
            mediaRecorderRef.current.stop();
            setIsRecording(false);

            if (audioContextRef.current) {
                audioContextRef.current.close();
            }

            if (animationFrameRef.current) {
                cancelAnimationFrame(animationFrameRef.current);
            }
        }
    };

    const handleSend = () => {
        stopRecording();

        if (chunksRef.current.length > 0) {
            const audioBlob = new Blob(chunksRef.current, { type: 'audio/webm' });
            onSend?.(audioBlob);
        }

        onClose();
    };

    const visualize = () => {
        if (!canvasRef.current || !analyserRef.current) return;

        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const analyser = analyserRef.current;
        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);

        const draw = () => {
            animationFrameRef.current = requestAnimationFrame(draw);

            analyser.getByteFrequencyData(dataArray);

            // Clear canvas
            ctx.fillStyle = 'transparent';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // Draw wave
            const barCount = 50;
            const barWidth = canvas.width / barCount;
            const centerY = canvas.height / 2;

            for (let i = 0; i < barCount; i++) {
                const dataIndex = Math.floor((i / barCount) * bufferLength);
                const value = dataArray[dataIndex] / 255;
                const barHeight = value * (canvas.height / 2) * 0.8;

                // Gradient
                const gradient = ctx.createLinearGradient(0, centerY - barHeight, 0, centerY + barHeight);
                gradient.addColorStop(0, '#3b82f6');
                gradient.addColorStop(0.5, '#8b5cf6');
                gradient.addColorStop(1, '#ec4899');

                ctx.fillStyle = gradient;

                // Draw symmetric bars
                const x = i * barWidth;
                const radius = barWidth / 4;

                // Top half
                ctx.beginPath();
                ctx.roundRect(x + barWidth * 0.2, centerY - barHeight, barWidth * 0.6, barHeight, radius);
                ctx.fill();

                // Bottom half
                ctx.beginPath();
                ctx.roundRect(x + barWidth * 0.2, centerY, barWidth * 0.6, barHeight, radius);
                ctx.fill();
            }
        };

        draw();
    };

    useEffect(() => {
        let interval: number | undefined;
        if (isRecording) {
            interval = setInterval(() => {
                setDuration((prev) => prev + 1);
            }, 1000);
        }
        return () => clearInterval(interval);
    }, [isRecording]);

    useEffect(() => {
        return () => {
            if (animationFrameRef.current) {
                cancelAnimationFrame(animationFrameRef.current);
            }
            if (audioContextRef.current) {
                audioContextRef.current.close();
            }
        };
    }, []);

    return (
        <AnimatePresence>
            <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl"
            >
                <div className="w-full max-w-md relative">
                    <button
                        onClick={onClose}
                        className="absolute -top-12 right-0 p-2 text-gray-400 hover:text-white"
                    >
                        <X size={24} />
                    </button>

                    <div className="text-center mb-8">
                        <h2 className="text-2xl font-light tracking-tight mb-2">Voice Message</h2>
                        <div className="text-sm text-gray-400">{formatDuration(duration)}</div>
                    </div>

                    {/* Canvas Visualizer */}
                    <div className="mb-8 bg-white/5 rounded-3xl p-6 border border-white/10">
                        <canvas
                            ref={canvasRef}
                            width={400}
                            height={200}
                            className="w-full h-48"
                        />
                    </div>

                    {/* Controls */}
                    <div className="flex justify-center items-center gap-6">
                        {isRecording && (
                            <motion.button
                                initial={{ opacity: 0, scale: 0 }}
                                animate={{ opacity: 1, scale: 1 }}
                                onClick={handleSend}
                                whileTap={{ scale: 0.9 }}
                                className="p-5 rounded-full bg-green-600 hover:bg-green-500 text-white shadow-lg transition-all"
                            >
                                <Send size={28} />
                            </motion.button>
                        )}

                        <motion.button
                            onClick={isRecording ? stopRecording : startRecording}
                            whileTap={{ scale: 0.9 }}
                            animate={isRecording ? { scale: [1, 1.05, 1] } : {}}
                            transition={isRecording ? { repeat: Infinity, duration: 1.5 } : {}}
                            className={`p-6 rounded-full text-white shadow-2xl transition-all ${isRecording
                                ? 'bg-red-600 hover:bg-red-500'
                                : 'bg-blue-600 hover:bg-blue-500'
                                }`}
                        >
                            <Mic size={32} />
                        </motion.button>
                    </div>

                    <p className="text-center text-sm text-gray-400 mt-6">
                        {isRecording ? 'Tap mic to stop • Tap send to finish' : 'Tap the mic to start recording'}
                    </p>
                </div>
            </motion.div>
        </AnimatePresence>
    );
};

import React from 'react';
import { motion, type PanInfo, useMotionValue, useTransform } from 'framer-motion';
import { CheckCircle, UserPlus, Clock } from 'lucide-react';

export interface Task {
    id: number;
    title: string;
    priority: 'high' | 'medium' | 'low';
    status: string;
    assignee?: string;
}

interface SwipeableCardProps {
    task: Task;
    onSwipe: (direction: 'right' | 'left' | 'up') => void;
    index: number;
}

export const SwipeableCard: React.FC<SwipeableCardProps> = ({ task, onSwipe, index }) => {
    const x = useMotionValue(0);
    const y = useMotionValue(0);
    const rotate = useTransform(x, [-200, 200], [-10, 10]);
    const opacity = useTransform(x, [-200, -100, 0, 100, 200], [0, 1, 1, 1, 0]);

    // Background color indicators based on swipe direction


    const handleDragEnd = (_: any, info: PanInfo) => {
        const threshold = 100;
        if (info.offset.x > threshold) {
            onSwipe('right');
        } else if (info.offset.x < -threshold) {
            onSwipe('left');
        } else if (info.offset.y < -threshold) {
            onSwipe('up');
        }
    };

    return (
        <motion.div
            style={{ x, y, rotate, opacity, zIndex: 100 - index }}
            drag
            dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
            dragElastic={0.7}
            onDragEnd={handleDragEnd}
            className="absolute top-0 left-0 w-full h-full"
            whileTap={{ cursor: 'grabbing' }}
        >
            <motion.div
                className="relative w-full h-full bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-3xl shadow-2xl p-6 flex flex-col justify-between overflow-hidden"
            >
                {/* Swipe Indicators */}
                <motion.div style={{ opacity: useTransform(x, [50, 150], [0, 1]) }} className="absolute top-6 left-6 text-green-500 flex items-center gap-2 border-2 border-green-500 rounded-lg px-2 py-1 transform -rotate-12">
                    <CheckCircle size={24} />
                    <span className="font-bold uppercase">Done</span>
                </motion.div>

                <motion.div style={{ opacity: useTransform(x, [-150, -50], [1, 0]) }} className="absolute top-6 right-6 text-blue-500 flex items-center gap-2 border-2 border-blue-500 rounded-lg px-2 py-1 transform rotate-12">
                    <UserPlus size={24} />
                    <span className="font-bold uppercase">Delegate</span>
                </motion.div>

                <motion.div style={{ opacity: useTransform(y, [-150, -50], [1, 0]) }} className="absolute bottom-6 left-1/2 -translate-x-1/2 text-yellow-500 flex items-center gap-2 border-2 border-yellow-500 rounded-lg px-2 py-1">
                    <Clock size={24} />
                    <span className="font-bold uppercase">Later</span>
                </motion.div>

                {/* Content */}
                <div className="mt-12">
                    <div className={`inline-block px-3 py-1 rounded-full text-xs font-medium mb-4 ${task.priority === 'high' ? 'bg-red-500/20 text-red-400' :
                        task.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-green-500/20 text-green-400'
                        }`}>
                        {task.priority.toUpperCase()} PRIORITY
                    </div>
                    <h2 className="text-3xl font-light leading-tight mb-4">{task.title}</h2>
                    <p className="text-gray-400">Swipe right to complete, left to delegate.</p>
                </div>

                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-700 to-gray-800 flex items-center justify-center border border-white/10">
                        <span className="text-sm font-medium">DE</span>
                    </div>
                    <div>
                        <div className="text-xs text-gray-500">Assignee</div>
                        <div className="text-sm font-medium">Denis (You)</div>
                    </div>
                </div>
            </motion.div>
        </motion.div>
    );
};

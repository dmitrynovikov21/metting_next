import React, { useState } from 'react';

import { SwipeableCard, type Task } from './SwipeableCard';
import { CheckCircle2 } from 'lucide-react';

const MOCK_TASKS: Task[] = [
    { id: 1, title: "Review Q3 Financial Report", priority: "high", status: "todo" },
    { id: 2, title: "Call with Violetta regarding Design", priority: "medium", status: "in-progress" },
    { id: 3, title: "Update Asana GIDs for new project", priority: "low", status: "todo" },
    { id: 4, title: "Prepare presentation for Monday", priority: "high", status: "todo" },
    { id: 5, title: "Approve vacation requests", priority: "low", status: "todo" },
];

export const TaskStack: React.FC = () => {
    const [tasks, setTasks] = useState<Task[]>(MOCK_TASKS);

    const handleSwipe = (id: number, direction: 'right' | 'left' | 'up') => {
        console.log(`Swiped task ${id} to ${direction}`);
        // Remove task from stack after a small delay to allow animation to complete visually if needed
        // But with AnimatePresence and key change it should be fine to remove immediately
        setTasks((prev) => prev.filter((t) => t.id !== id));
    };

    return (
        <div className="relative w-full h-[60vh] max-h-[500px] flex items-center justify-center mt-4">
            {tasks.length > 0 ? (
                tasks.map((task, index) => (
                    index >= tasks.length - 2 && ( // Only render top 2 cards for performance
                        <SwipeableCard
                            key={task.id}
                            task={task}
                            index={tasks.length - 1 - index} // 0 is top card
                            onSwipe={(dir) => handleSwipe(task.id, dir)}
                        />
                    )
                ))
            ) : (
                <div className="text-center p-8">
                    <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4 text-green-500">
                        <CheckCircle2 size={40} />
                    </div>
                    <h3 className="text-2xl font-light mb-2">All Caught Up!</h3>
                    <p className="text-gray-400">You've cleared your inbox for today.</p>
                </div>
            )}
        </div>
    );
};

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Play, Pause, RotateCcw, X } from 'lucide-react';

interface FocusModeProps {
    onClose: () => void;
}

export const FocusMode: React.FC<FocusModeProps> = ({ onClose }) => {
    const [timeLeft, setTimeLeft] = useState(25 * 60);
    const [isActive, setIsActive] = useState(false);
    const [mode, setMode] = useState<'focus' | 'break'>('focus');

    // Sound Effects using Web Audio API
    const playSound = (type: 'start' | 'end') => {
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);

        if (type === 'start') {
            // Rising chime
            oscillator.type = 'sine';
            oscillator.frequency.setValueAtTime(440, audioContext.currentTime);
            oscillator.frequency.exponentialRampToValueAtTime(880, audioContext.currentTime + 0.1);
            gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
            oscillator.start();
            oscillator.stop(audioContext.currentTime + 0.5);
        } else {
            // Relaxing end chime
            oscillator.type = 'sine';
            oscillator.frequency.setValueAtTime(880, audioContext.currentTime);
            oscillator.frequency.exponentialRampToValueAtTime(440, audioContext.currentTime + 0.5);
            gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 1);
            oscillator.start();
            oscillator.stop(audioContext.currentTime + 1);
        }
    };

    useEffect(() => {
        let interval: number | undefined;

        if (isActive && timeLeft > 0) {
            interval = setInterval(() => {
                setTimeLeft((prev) => prev - 1);
            }, 1000);
        } else if (timeLeft === 0 && isActive) {
            // Timer finished
            playSound('end');

            if (mode === 'focus') {
                // Auto-start break
                setMode('break');
                setTimeLeft(5 * 60);
                // Keep active to auto-start
                setIsActive(true);
            } else {
                // Stop after break
                setIsActive(false);
                setMode('focus');
                setTimeLeft(25 * 60);
            }
        }

        return () => clearInterval(interval);
    }, [isActive, timeLeft, mode]);

    const toggleTimer = () => {
        if (!isActive) {
            playSound('start');
        }
        setIsActive(!isActive);
    };

    const resetTimer = () => {
        setIsActive(false);
        setTimeLeft(mode === 'focus' ? 25 * 60 : 5 * 60);
    };

    const switchMode = (newMode: 'focus' | 'break') => {
        setMode(newMode);
        setIsActive(false);
        setTimeLeft(newMode === 'focus' ? 25 * 60 : 5 * 60);
    };

    const formatTime = (seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    };

    const progress = mode === 'focus'
        ? ((25 * 60 - timeLeft) / (25 * 60)) * 100
        : ((5 * 60 - timeLeft) / (5 * 60)) * 100;

    return (
        <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl"
        >
            <div className="w-full max-w-sm relative">
                <button
                    onClick={onClose}
                    className="absolute -top-12 right-0 p-2 text-gray-400 hover:text-white"
                >
                    <X size={24} />
                </button>

                <div className="text-center mb-8">
                    <h2 className="text-2xl font-light tracking-tight mb-2">Focus Mode</h2>
                    <div className="flex justify-center gap-2 p-1 bg-white/10 rounded-full w-fit mx-auto">
                        <button
                            onClick={() => switchMode('focus')}
                            className={`px-4 py-1 rounded-full text-sm transition-colors ${mode === 'focus' ? 'bg-blue-600 text-white' : 'text-gray-400'
                                }`}
                        >
                            Focus
                        </button>
                        <button
                            onClick={() => switchMode('break')}
                            className={`px-4 py-1 rounded-full text-sm transition-colors ${mode === 'break' ? 'bg-green-600 text-white' : 'text-gray-400'
                                }`}
                        >
                            Break
                        </button>
                    </div>
                </div>

                {/* Circular Timer */}
                <div className="relative w-64 h-64 mx-auto mb-12 flex items-center justify-center">
                    <svg className="w-full h-full transform -rotate-90">
                        <circle
                            cx="128"
                            cy="128"
                            r="120"
                            stroke="currentColor"
                            strokeWidth="8"
                            fill="transparent"
                            className="text-white/10"
                        />
                        <circle
                            cx="128"
                            cy="128"
                            r="120"
                            stroke="currentColor"
                            strokeWidth="8"
                            fill="transparent"
                            strokeDasharray={2 * Math.PI * 120}
                            strokeDashoffset={2 * Math.PI * 120 * (1 - progress / 100)}
                            className={`${mode === 'focus' ? 'text-blue-500' : 'text-green-500'} transition-all duration-1000 ease-linear`}
                            strokeLinecap="round"
                        />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-6xl font-thin font-mono tracking-wider">
                            {formatTime(timeLeft)}
                        </span>
                        <span className="text-sm text-gray-400 mt-2 uppercase tracking-widest">
                            {isActive ? 'Running' : 'Paused'}
                        </span>
                    </div>
                </div>

                {/* Controls */}
                <div className="flex justify-center gap-6">
                    <button
                        onClick={resetTimer}
                        className="p-4 rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors"
                    >
                        <RotateCcw size={24} />
                    </button>
                    <button
                        onClick={toggleTimer}
                        className={`p-6 rounded-full text-white shadow-lg transition-transform active:scale-95 ${mode === 'focus' ? 'bg-blue-600 hover:bg-blue-500' : 'bg-green-600 hover:bg-green-500'
                            }`}
                    >
                        {isActive ? <Pause size={32} fill="currentColor" /> : <Play size={32} fill="currentColor" className="ml-1" />}
                    </button>
                </div>
            </div>
        </motion.div>
    );
};

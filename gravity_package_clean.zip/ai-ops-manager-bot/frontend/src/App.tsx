import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LayoutDashboard,
  CheckSquare,
  Calendar,
  Bell,
  Settings,
  ChevronRight
} from 'lucide-react'
import WebApp from '@twa-dev/sdk'
import { QuickActionsFAB } from './components/QuickActionsFAB'
import { MorningBriefing } from './components/MorningBriefing'
import { TeamPulse } from './components/TeamPulse'
import { FocusMode } from './components/FocusMode'
import { TaskStack } from './components/TaskStack'
import { MeetingPrepCard } from './components/MeetingPrepCard'
import { VoiceVisualizer } from './components/VoiceVisualizer'

// Mock Data
const TASKS = [
  { id: 1, title: "Review Q3 Report", priority: "high", status: "todo" },
  { id: 2, title: "Call with Violetta", priority: "medium", status: "in-progress" },
  { id: 3, title: "Update Asana GIDs", priority: "low", status: "done" },
]

const MEETINGS = [
  { id: 1, title: "Weekly Sync", time: "14:00", platform: "Zoom" as const },
  { id: 2, title: "Client Intro", time: "16:30", platform: "Meet" as const },
]

function App() {
  const [activeTab, setActiveTab] = useState('dashboard')

  useEffect(() => {
    // Initialize Telegram WebApp
    if (typeof window !== 'undefined') {
      try {
        WebApp.ready()
        WebApp.expand()
      } catch (e) {
        console.log('WebApp not available')
      }
    }
  }, [])

  const [isFocusModeOpen, setIsFocusModeOpen] = useState(false)
  const [isVoiceVisualizerOpen, setIsVoiceVisualizerOpen] = useState(false)

  return (
    <div className="w-full min-h-screen text-white pb-24 px-4 pt-6">
      <AnimatePresence>
        {isFocusModeOpen && <FocusMode onClose={() => setIsFocusModeOpen(false)} />}
        {isVoiceVisualizerOpen && <VoiceVisualizer onClose={() => setIsVoiceVisualizerOpen(false)} />}
      </AnimatePresence>

      {/* Header */}
      <header className="flex justify-between items-start mb-2">
        <div className="w-full">
          <MorningBriefing />
        </div>
        <div className="glass-button p-2 rounded-full bg-white/10 absolute top-6 right-4">
          <Bell size={20} />
        </div>
      </header>

      {/* Content based on Tab */}
      {activeTab === 'dashboard' && (
        <>
          {/* Stats Cards */}
          <div className="grid grid-cols-2 gap-4 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="glass-card p-4 relative overflow-hidden"
            >
              <div className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              <div className="text-3xl font-bold mb-1">5</div>
              <div className="text-gray-400 text-sm">Tasks Due</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="glass-card p-4 relative overflow-hidden"
            >
              <div className="absolute top-2 right-2 w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
              <div className="text-3xl font-bold mb-1">3</div>
              <div className="text-gray-400 text-sm">Meetings</div>
            </motion.div>
          </div>

          {/* Team Pulse */}
          <TeamPulse />

          {/* Upcoming Meetings */}
          <section className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">Upcoming</h3>
              <span className="text-blue-400 text-sm">See all</span>
            </div>
            <div className="space-y-3">
              {MEETINGS.map((meeting, i) => (
                <motion.div
                  key={meeting.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + i * 0.1 }}
                  className="glass-card p-4 flex justify-between items-center"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400">
                      <Calendar size={20} />
                    </div>
                    <div>
                      <div className="font-medium">{meeting.title}</div>
                      <div className="text-xs text-gray-400">{meeting.platform} • {meeting.time}</div>
                    </div>
                  </div>
                  <button className="glass-button text-xs py-1 px-3">Join</button>
                </motion.div>
              ))}
            </div>
          </section>

          {/* Recent Tasks */}
          <section>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">Recent Tasks</h3>
            </div>
            <div className="space-y-3">
              {TASKS.map((task, i) => (
                <motion.div
                  key={task.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + i * 0.1 }}
                  className="glass-card p-4 flex justify-between items-center"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${task.priority === 'high' ? 'bg-red-500' :
                      task.priority === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                      }`} />
                    <span className={task.status === 'done' ? 'line-through text-gray-500' : ''}>
                      {task.title}
                    </span>
                  </div>
                  <ChevronRight size={16} className="text-gray-500" />
                </motion.div>
              ))}
            </div>
          </section>
        </>
      )}

      {activeTab === 'tasks' && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <h2 className="text-2xl font-light mb-6">Task Flow</h2>
          <TaskStack />
        </motion.div>
      )}

      {activeTab === 'calendar' && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <h2 className="text-2xl font-light mb-6">Today's Meetings</h2>
          {MEETINGS.map((meeting) => (
            <MeetingPrepCard
              key={meeting.id}
              meeting={{
                ...meeting,
                attendees: ['Denis K', 'Violetta', 'Kirill'],
                meetingUrl: 'https://zoom.us/j/123',
                isNow: meeting.id === 1
              }}
              onJoin={() => window.open(`https://zoom.us/${meeting.platform.toLowerCase()}/j/123`, '_blank')}
            />
          ))}
        </motion.div>
      )}


      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 w-full bg-black/50 backdrop-blur-xl border-t border-white/10 p-4 pb-8">
        <div className="flex justify-around items-center">
          <button onClick={() => setActiveTab('dashboard')} className={`flex flex-col items-center gap-1 ${activeTab === 'dashboard' ? 'text-blue-400' : 'text-gray-500'}`}>
            <LayoutDashboard size={24} />
            <span className="text-[10px]">Home</span>
          </button>
          <button onClick={() => setActiveTab('tasks')} className={`flex flex-col items-center gap-1 ${activeTab === 'tasks' ? 'text-blue-400' : 'text-gray-500'}`}>
            <CheckSquare size={24} />
            <span className="text-[10px]">Tasks</span>
          </button>

          {/* FAB */}
          <div className="-mt-8">
            <QuickActionsFAB
              onFocusMode={() => setIsFocusModeOpen(true)}
              onVoiceRecord={() => setIsVoiceVisualizerOpen(true)}
            />
          </div>

          <button onClick={() => setActiveTab('calendar')} className={`flex flex-col items-center gap-1 ${activeTab === 'calendar' ? 'text-blue-400' : 'text-gray-500'}`}>
            <Calendar size={24} />
            <span className="text-[10px]">Calendar</span>
          </button>
          <button onClick={() => setActiveTab('settings')} className={`flex flex-col items-center gap-1 ${activeTab === 'settings' ? 'text-blue-400' : 'text-gray-500'}`}>
            <Settings size={24} />
            <span className="text-[10px]">Settings</span>
          </button>
        </div>
      </div>
    </div>
  )
}

export default App

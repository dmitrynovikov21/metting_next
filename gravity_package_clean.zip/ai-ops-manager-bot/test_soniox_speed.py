import asyncio
import time
import os
import logging
from app.services.soniox_service import soniox_service

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def test_speed():
    # Use one of the existing files
    test_file = "storage/uploads/a1af470a-9e18-468f-a86b-e4ebc59407f2.mp3"
    
    if not os.path.exists(test_file):
        logger.error(f"Test file not found: {test_file}")
        return

    file_size = os.path.getsize(test_file)
    logger.info(f"Starting benchmark for {test_file} ({file_size} bytes)")

    start_time = time.time()

    try:
        # 1. Upload
        upload_start = time.time()
        file_id = await soniox_service.upload_file(test_file)
        upload_time = time.time() - upload_start
        logger.info(f"Upload took: {upload_time:.2f}s. File ID: {file_id}")

        # 2. Start Transcription
        transcribe_start = time.time()
        transcription_id = await soniox_service.start_transcription(file_id, "en")
        start_req_time = time.time() - transcribe_start
        logger.info(f"Start request took: {start_req_time:.2f}s. ID: {transcription_id}")

        # 3. Poll
        poll_start = time.time()
        status = "queued"
        polls = 0
        while status in ["queued", "transcribing", "processing"]:
            polls += 1
            await asyncio.sleep(1) # Poll every 1s for benchmark
            status = await soniox_service.get_transcription_status(transcription_id)
            logger.info(f"Poll #{polls}: {status}")
            
            if status in ["failed", "error"]:
                logger.error("Transcription failed")
                return

        poll_time = time.time() - poll_start
        logger.info(f"Polling took: {poll_time:.2f}s")

        # 4. Get Transcript
        get_start = time.time()
        transcript = await soniox_service.get_transcript(transcription_id)
        get_time = time.time() - get_start
        logger.info(f"Get transcript took: {get_time:.2f}s")

        total_time = time.time() - start_time
        logger.info(f"TOTAL TIME: {total_time:.2f}s")
        logger.info(f"Transcript length: {len(transcript.get('text', ''))} chars")

    except Exception as e:
        logger.error(f"Benchmark failed: {e}")

if __name__ == "__main__":
    asyncio.run(test_speed())

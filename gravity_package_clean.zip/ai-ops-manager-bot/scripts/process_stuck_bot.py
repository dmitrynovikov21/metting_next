import asyncio
import logging
from app.services.meeting_processing_service import meeting_processing_service
from app.services.recall_service import recall_service

# Configure logging
logging.basicConfig(level=logging.INFO)

async def main():
    bot_id = "f3b33339-57ba-4306-9854-a6d79fa14e0b"
    print(f"Processing stuck bot {bot_id}...")
    
    # Fetch bot info to get video_url
    bot_info = await recall_service.get_bot(bot_id)
    
    data = {}
    recordings = bot_info.get('recordings', [])
    if recordings:
        last_rec = recordings[-1]
        video_mixed = last_rec.get('media_shortcuts', {}).get('video_mixed', {})
        data['video_url'] = video_mixed.get('data', {}).get('download_url')
        
        # Duration
        start = last_rec.get('started_at')
        end = last_rec.get('completed_at')
        if start and end:
            from dateutil import parser
            s = parser.parse(start)
            e = parser.parse(end)
            data['duration'] = (e - s).total_seconds()
    
    print(f"Data: {data}")
    
    await meeting_processing_service.process_meeting(bot_id, data)
    print("Done!")

if __name__ == "__main__":
    asyncio.run(main())

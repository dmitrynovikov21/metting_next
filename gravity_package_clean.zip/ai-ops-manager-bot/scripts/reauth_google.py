import asyncio
import os
import shutil
from app.services.google_calendar_service import google_calendar_service

async def reauth():
    print("🔄 Starting Google Re-authentication...")
    
    # 1. Backup existing token
    if os.path.exists('token.json'):
        print("📦 Backing up existing token.json to token.json.bak")
        shutil.move('token.json', 'token.json.bak')
        # Reload service to clear cached creds
        google_calendar_service.creds = None
    
    # 2. Get Auth URL
    try:
        auth_url = google_calendar_service.get_auth_url()
        
        print("\n" + "="*60)
        print("🔑  AUTHORIZATION LINK (COPY EVERYTHING BELOW)")
        print("="*60)
        print(auth_url)
        print("="*60 + "\n")
        
        print("⚠️  INSTRUCTIONS:")
        print("1. Copy the ENTIRE link above (it is very long!).")
        print("2. Paste it into your browser.")
        print("3. Log in and authorize.")
        print("4. You will be redirected to a page that might fail to load.")
        print("5. Copy the 'code=' part from that page's address bar.")
        
        # 3. Get Code
        code = input("\nPaste the 'code' parameter here: ").strip()
        
        if code:
            # 4. Save Credentials
            if google_calendar_service.save_credentials_from_code(code):
                print("\n✅ Successfully re-authenticated and saved new token.json!")
                
                # 5. Verify Scopes (Implicitly verified by successful token fetch)
                print("Scopes included: Calendar, Drive, Sheets")
            else:
                print("\n❌ Failed to save credentials.")
        else:
            print("\n❌ No code provided.")
            
    except Exception as e:
        print(f"\n❌ Error during re-authentication: {e}")
        # Restore backup if failed
        if os.path.exists('token.json.bak'):
            shutil.move('token.json.bak', 'token.json')
            print("Restored original token.json")

if __name__ == "__main__":
    asyncio.run(reauth())

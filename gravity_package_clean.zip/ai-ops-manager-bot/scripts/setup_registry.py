import asyncio
import logging
from app.core.config import settings
from app.services.google_sheets_service import google_sheets_service

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def setup_registry():
    print(f"🎨 Setting up Professional Registry in Sheet: {settings.GOOGLE_SHEETS_ID}")
    
    service = google_sheets_service.get_service()
    if not service:
        print("❌ Service not available")
        return

    spreadsheet_id = settings.GOOGLE_SHEETS_ID
    sheet_id = 0 # Assuming first sheet

    # 1. Define Headers (User v2 Schema)
    headers = [
        "Дата", "Название (тема)", "Участники", "Протокол (Doc)", "Запись (Drive)", 
        "Транскрибация", "Саммари", "Решения", "Задачи (Asana)", "Статус", 
        "Следующие шаги", "Ответственный"
    ]

    try:
        # Batch Update Request
        requests = [
            # 1. Update Header Row (A1:L1)
            {
                "updateCells": {
                    "rows": [{
                        "values": [{"userEnteredValue": {"stringValue": h}, 
                                    "userEnteredFormat": {
                                        "textFormat": {"bold": True, "foregroundColor": {"red": 1.0, "green": 1.0, "blue": 1.0}},
                                        "backgroundColor": {"red": 0.1, "green": 0.1, "blue": 0.3}, # Dark Blue
                                        "horizontalAlignment": "CENTER",
                                        "wrapStrategy": "WRAP"
                                    }} for h in headers]
                    }],
                    "fields": "userEnteredValue,userEnteredFormat",
                    "range": {
                        "sheetId": sheet_id,
                        "startRowIndex": 0,
                        "endRowIndex": 1,
                        "startColumnIndex": 0,
                        "endColumnIndex": len(headers)
                    }
                }
            },
            # 2. Freeze Top Row
            {
                "updateSheetProperties": {
                    "properties": {
                        "sheetId": sheet_id,
                        "gridProperties": {
                            "frozenRowCount": 1
                        }
                    },
                    "fields": "gridProperties.frozenRowCount"
                }
            },
            # 3. Set Column Widths
            { "updateDimensionProperties": { "range": { "sheetId": sheet_id, "dimension": "COLUMNS", "startIndex": 0, "endIndex": 1 }, "properties": { "pixelSize": 100 }, "fields": "pixelSize" } }, # Date
            { "updateDimensionProperties": { "range": { "sheetId": sheet_id, "dimension": "COLUMNS", "startIndex": 1, "endIndex": 2 }, "properties": { "pixelSize": 250 }, "fields": "pixelSize" } }, # Topic
            { "updateDimensionProperties": { "range": { "sheetId": sheet_id, "dimension": "COLUMNS", "startIndex": 6, "endIndex": 8 }, "properties": { "pixelSize": 300 }, "fields": "pixelSize" } }, # Summary, Decisions
        ]

        service.spreadsheets().batchUpdate(
            spreadsheetId=spreadsheet_id,
            body={"requests": requests}
        ).execute()
        
        print("✅ Registry Headers & Formatting Applied Successfully!")

    except Exception as e:
        print(f"❌ Error setting up registry: {e}")

if __name__ == "__main__":
    asyncio.run(setup_registry())

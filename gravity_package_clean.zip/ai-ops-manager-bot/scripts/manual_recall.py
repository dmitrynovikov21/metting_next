import asyncio
import os
import sys
from dotenv import load_dotenv

# Add app to path
sys.path.append(os.getcwd())

from app.services.recall_service import recall_service
from app.services.ai_service import ai_service

# Load env
load_dotenv()

async def manual_process(bot_id):
    print(f"Fetching bot {bot_id}...")
    try:
        bot_data = await recall_service.get_bot(bot_id)
        print("Status changes:")
        for change in bot_data.get("status_changes", []):
            print(f"- {change.get('status')} ({change.get('created_at')})")
            
        print("\nFull data (partial):")
        import json
        # Print only relevant parts
        print(json.dumps({
            "transcription": bot_data.get("transcription"),
            "video": bot_data.get("video"),
            "meeting_metadata": bot_data.get("meeting_metadata")
        }, indent=2))
        
        print("Fetching transcript...")
        transcript = await recall_service.get_transcript(bot_id)
        print(f"Transcript length: {len(transcript)}")
        
        print("Analyzing with AI...")
        # We need a dummy Asana GID if we don't want to query DB, or fetch it
        # For now let's just print the result
        protocol = await ai_service.analyze_meeting(transcript, "manual_run")
        
        print("\n--- PROTOCOL ---\n")
        print(protocol)
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    bot_id = "cca8d8bc-cdb5-46d9-88a0-f6cdb234f9d0"
    asyncio.run(manual_process(bot_id))

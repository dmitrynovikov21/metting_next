import asana
import os
import sys

# Add project root to python path
sys.path.append(os.getcwd())

from app.core.config import settings

def fetch_sections():
    print("--- FETCHING PROJECTS AND SECTIONS ---")
    configuration = asana.Configuration()
    configuration.access_token = settings.ASANA_ACCESS_TOKEN
    api_client = asana.ApiClient(configuration)
    projects_api = asana.ProjectsApi(api_client)
    sections_api = asana.SectionsApi(api_client)
    
    workspace_gid = settings.ASANA_WORKSPACE_GID
    
    try:
        # 1. List all projects
        print(f"Listing projects in workspace {workspace_gid}...")
        projects = projects_api.get_projects_for_workspace(workspace_gid, opts={'opt_fields': 'name,gid'})
        
        target_project_gid = None
        for p in projects:
            print(f"  - {p['name']} (GID: {p['gid']})")
            if "Задачи отделов" in p['name']:
                target_project_gid = p['gid']
                print(f"    ✅ MATCH FOUND!")
        
        if not target_project_gid:
            print("❌ Project 'Задачи отделов' not found (checked all projects).")
            return

        # 2. Fetch Sections for this project
        print(f"\nFetching sections for project {target_project_gid}...")
        sections = sections_api.get_sections_for_project(target_project_gid, opts={'opt_fields': 'name,gid'})
        
        print("\n--- SECTIONS MAPPING ---")
        for s in sections:
            print(f"Section: '{s['name']}' (GID: {s['gid']})")

    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    fetch_sections()

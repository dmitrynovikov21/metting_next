import httpx
import asyncio

async def main():
    url = "http://bot:8000/api/v1/webhook/recall"
    
    # Payload simulating a "call_ended" or "done" event with video_url but no transcript
    payload = {
        "event": {
            "type": "bot.status_change" # Or recording.ready? Let's try recording.ready
        },
        "data": {
            "bot_id": "ee0aa70c-41db-4091-a49a-9cfacf8487c5",
            "status": "done",
            "video_url": "https://us-west-2-recallai-production-bot-data.s3.amazonaws.com/dummy-video.mp4",
            "duration": 120
        }
    }
    
    # Actually, the endpoint handles "recording.ready" for processing.
    # Let's send "recording.ready"
    payload["event"]["type"] = "recording.ready"
    
    print(f"Sending webhook to {url}...")
    async with httpx.AsyncClient() as client:
        response = await client.post(url, json=payload)
        print(f"Status: {response.status_code}")
        print(f"Response: {response.text}")

if __name__ == "__main__":
    asyncio.run(main())

import asana
import os
import sys
import json

# Add project root to python path
sys.path.append(os.getcwd())

from app.core.config import settings

def fetch_custom_fields():
    print("--- FETCHING CUSTOM FIELDS ---")
    configuration = asana.Configuration()
    configuration.access_token = settings.ASANA_ACCESS_TOKEN
    api_client = asana.ApiClient(configuration)
    custom_fields_api = asana.CustomFieldsApi(api_client)
    projects_api = asana.ProjectsApi(api_client)
    
    project_gid = settings.ASANA_INBOX_PROJECT_GID
    print(f"Project GID: {project_gid}")
    
    try:
        # Get project's custom field settings
        # Note: In Asana API, you often get custom fields via the project's 'custom_field_settings' endpoint 
        # or by getting the project with opt_fields='custom_field_settings.custom_field'
        
        project = projects_api.get_project(
            project_gid, 
            opts={'opt_fields': 'custom_field_settings.custom_field.name,custom_field_settings.custom_field.enum_options'}
        )
        
        if hasattr(project, 'to_dict'):
            project_data = project.to_dict()
        else:
            project_data = project
            
        # Handle different response structures
        if 'data' in project_data:
            project_data = project_data['data']
            
        settings_list = project_data.get('custom_field_settings', [])
        
        print(f"Found {len(settings_list)} custom field settings.")
        
        for setting in settings_list:
            cf = setting.get('custom_field', {})
            name = cf.get('name')
            gid = cf.get('gid')
            print(f"\nField: {name} (GID: {gid})")
            
            if name == "Проект":
                print("!!! FOUND TARGET FIELD !!!")
                options = cf.get('enum_options', [])
                for opt in options:
                    print(f"  - Option: {opt.get('name')} (GID: {opt.get('gid')})")

    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    fetch_custom_fields()

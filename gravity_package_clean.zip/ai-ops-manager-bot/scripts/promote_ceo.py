import asyncio
import os
import sys
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy import select, update

# Add app to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from app.core.config import settings
from app.db.models import User

async def promote_ceo():
    engine = create_async_engine(settings.DATABASE_URL)
    AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    
    target_id = 162117471
    
    async with AsyncSessionLocal() as session:
        # Check if user exists
        result = await session.execute(select(User).where(User.telegram_id == target_id))
        user = result.scalars().first()
        
        if user:
            print(f"Found user: {user.full_name} (Role: {user.role}, Status: {user.status})")
            
            # Update
            user.role = 'ceo'
            user.status = 'approved'
            user.is_active = True
            
            await session.commit()
            print(f"✅ User {user.full_name} promoted to CEO and approved!")
        else:
            print(f"❌ User with ID {target_id} not found.")

if __name__ == "__main__":
    asyncio.run(promote_ceo())

import asana
import os
import sys

# Add parent directory to path to import app modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.core.config import settings

def main():
    print("--- FETCHING USER GID ---")
    configuration = asana.Configuration()
    configuration.access_token = settings.ASANA_ACCESS_TOKEN
    api_client = asana.ApiClient(configuration)
    users_api = asana.UsersApi(api_client)
    
    workspace_gid = settings.ASANA_WORKSPACE_GID
    target_name = "Виолетта"
    
    print(f"Fetching users in workspace {workspace_gid}...")
    try:
        users = users_api.get_users_for_workspace(workspace_gid, opts={'opt_fields': 'gid,name,email'})
        
        found = False
        for user in users:
            name = user['name'].lower()
            if "violetta" in name or "виолетта" in name:
                print(f"FOUND: {user['name']} | GID: {user['gid']} | Email: {user.get('email')}")
                found = True
                
        if not found:
            print(f"User 'Violetta/Виолетта' not found.")
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()

import asyncio
import os
from sqlalchemy import text
from app.db.base import AsyncSessionLocal

async def update_schema():
    print("Updating database schema...")
    async with AsyncSessionLocal() as session:
        try:
            # Add position column
            try:
                await session.execute(text("ALTER TABLE users ADD COLUMN position VARCHAR(100)"))
                print("Added 'position' column.")
            except Exception as e:
                print(f"Column 'position' might already exist: {e}")

            # Add status column
            try:
                await session.execute(text("ALTER TABLE users ADD COLUMN status VARCHAR(20) DEFAULT 'pending'"))
                print("Added 'status' column.")
            except Exception as e:
                print(f"Column 'status' might already exist: {e}")
                
            await session.commit()
            print("Schema update complete.")
        except Exception as e:
            print(f"Error updating schema: {e}")
            await session.rollback()

if __name__ == "__main__":
    asyncio.run(update_schema())

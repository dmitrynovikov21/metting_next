import json
import os

def check_creds():
    print("--- Checking Credentials ---")
    
    # Check token.json
    if os.path.exists('token.json'):
        try:
            with open('token.json', 'r') as f:
                data = json.load(f)
                client_id = data.get('client_id', '')
                print(f"token.json Client ID: {client_id}")
                if 'project_id' in data:
                    print(f"token.json Project ID: {data['project_id']}")
        except Exception as e:
            print(f"Error reading token.json: {e}")
    else:
        print("token.json not found.")

    # Check .env for GOOGLE_CLIENT_ID
    if os.path.exists('.env'):
        try:
            with open('.env', 'r') as f:
                for line in f:
                    if line.startswith('GOOGLE_CLIENT_ID'):
                        print(f".env GOOGLE_CLIENT_ID: {line.strip()}")
        except Exception as e:
            print(f"Error reading .env: {e}")
            
if __name__ == "__main__":
    check_creds()

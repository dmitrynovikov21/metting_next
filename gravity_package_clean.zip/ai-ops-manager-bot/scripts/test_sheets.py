import asyncio
import logging
from app.core.config import settings
from app.services.google_sheets_service import google_sheets_service

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def test_sheets():
    print(f"Testing Google Sheets API...")
    print(f"Spreadsheet ID: {settings.GOOGLE_SHEETS_ID}")
    
    if not settings.GOOGLE_SHEETS_ID:
        print("❌ GOOGLE_SHEETS_ID is not set in .env")
        return

    # Test Data
    import datetime
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    row_data = [now, "Test Meeting", "https://zoom.us/test", "https://drive.google.com/test", "Test Status"]
    
    print(f"Attempting to append row: {row_data}")
    
    # Try insert_row_at_top
    success = google_sheets_service.insert_row_at_top(settings.GOOGLE_SHEETS_ID, row_data)
    
    if success:
        print("✅ Successfully inserted row at top!")
    else:
        print("❌ Failed to insert row. Check logs for details.")

if __name__ == "__main__":
    asyncio.run(test_sheets())

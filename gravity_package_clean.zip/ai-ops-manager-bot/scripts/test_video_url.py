import httpx
import asyncio

async def main():
    url = "https://us-west-2-recallai-production-bot-data.s3.amazonaws.com/_workspace-4d7d9413-0b2e-4f7b-8075-bcf693681142/recordings/735bd467-57c0-4084-8caf-eb448052ad1a/video_mixed/3d9fe4d0-b86f-4cdb-9158-b58405a03281/bot/ee0aa70c-41db-4091-a49a-9cfacf8487c5/AROA3Z2PRSQANGTUQXHNJ%3Ai-0accd074eeefbf2b5/video.mp4?AWSAccessKeyId=ASIA3Z2PRSQAJ6AQVB2P&Signature=BTIaZxEIeanMgjFakbc0MAEVEhE%3D&x-amz-security-token=IQoJb3JpZ2luX2VjENP%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLXdlc3QtMiJIMEYCIQDrkNkuXKDJCp4bwIiOO25E8ELdZbAkXUi7yytRzuBeJgIhAM9HH2GQzR8QN22IZInlYYXPTe2UDDjzRpNN70k9W43yKsQFCJz%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEQABoMODExMzc4Nzc1MDQwIgwXsk4s4Opbf35d1xUqmAV%2FxGYVucm3xgDQFqANHkOsqa%2FAlWhD63v5TOzROGGq6pNs1MzmxtZjcAasr6NjOKgOyezSoweDb3UlJIt7Z%2FIxo%2BqezZMj%2BI%2FG7JGqwkUxH9zDi9oNb2ypYR1KWSd%2FKUiBsehMZIcj3Npf5bFHKMvpTw5pxNsrYypQMds2PeFvE3N8jqTyfC49FQ686baEEhVLXvUPM6sRyE14U1TpBLBHl5MarxRqizLUqJoIvZJAj%2BKsSUZ7AgkI2MJNn2rtr3RfPAKlt%2FbgDtNCXzsteBQrQ1pLgJ5MSUORiKbfXXRGX41765B8pyDkTc%2FRRLqKTdd7ETKS87g%2FuNMwJiELHwF4%2FnkhsB56s0ISax%2Bzox5wrAAgt%2BOtHj3hYvnmSTb8963SvHSbPsPsqc8o%2BTUVxBYOD1vHW5jWriolo6UVku8ZfUswgG16dGkHQcTeKr8WJ5Qn1pEvn0nGRvV%2FzO8C1tQl6Ds1rO8WQTETU6LaSe3xu15un3o%2FGu6Ap5acx%2FmBZi%2Bvxwqit8bQ1NiSJuMeCZ6bHo2NNIjTeNgVEkCI%2FKIDVbWAZ1ZFexh2HCZWR48yWhzUmP3sOGGXEY6YnVdNMGExENdWzHS48MmH4WixF%2F%2F12I7MTMo2JLix2Ew8tNQ6zjTLuQvJJ5gYzsvSjgj4rbwwwztKgIJa6ok9Xk0oobt7JIB3AjA%2BgBHO60ZHWs87BfBWa7C4FdjSgFg9v9sTxgpo9YK%2BZY4Fv%2BEHi9B8H9JYESHcQWwj52nQkaFwOl7hYkXfwuOnLA2CZNb6D1wz1sUCjTiSMvLRq7oY65FfyLQnigFwIe6bYGJATzVXa3gM29GXGvUeUmby7WxO2he7R%2BfsAnnIEQRw%2BnJUBo2PflPvixK7ZdBpUUjAMJHgoMkGOrABxKIx9gwj%2BZQUkcJUJwCMIPG45KVeYkduMtz8yQUVLAE9KfWq21l0MxfgSeoPnLeRYrsha1SwiCnVKaIINNuwgqvCz90oZ%2FyIns9NUJBnB%2B86yGMe6AyCBHNti5n%2FgPdnUkp2LKJa%2F7IiwbGpNDunm0PPOvZ1KnebMse8%2FolO7EOLjzY6yiZEwvxnbvVX%2FeuWw%2FXiYeldVh33NLOquXxpOjiYU0rb13pVyH8YqaEuHws%3D&Expires=1764263902"
    
    print(f"Checking URL: {url}")
    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36",
        "Referer": "https://app.recall.ai/"
    }
    async with httpx.AsyncClient() as client:
        response = await client.head(url, headers=headers)
        print(f"Status: {response.status_code}")
        
        if response.status_code == 200:
            print("URL is accessible!")
        else:
            print(f"URL failed: {response.text}")

if __name__ == "__main__":
    asyncio.run(main())

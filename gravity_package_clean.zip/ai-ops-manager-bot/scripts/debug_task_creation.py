import asana
import os
import sys

# Add project root to python path
sys.path.append(os.getcwd())

from app.core.config import settings

def test_create_task():
    print("--- TESTING TASK CREATION ---")
    print(f"Token: {settings.ASANA_ACCESS_TOKEN[:10]}...")
    print(f"Workspace: {settings.ASANA_WORKSPACE_GID}")
    print(f"Project: {settings.ASANA_INBOX_PROJECT_GID}")
    
    configuration = asana.Configuration()
    configuration.access_token = settings.ASANA_ACCESS_TOKEN
    api_client = asana.ApiClient(configuration)
    tasks_api = asana.TasksApi(api_client)
    
    body = {
        "data": {
            "name": "Test Task from Script",
            "notes": "Debugging 401 error",
            "projects": [settings.ASANA_INBOX_PROJECT_GID],
            "workspace": settings.ASANA_WORKSPACE_GID,
        }
    }
    
    try:
        result = tasks_api.create_task(body, opts={})
        print(f"✅ Task created: {result['data']['gid']}")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    test_create_task()

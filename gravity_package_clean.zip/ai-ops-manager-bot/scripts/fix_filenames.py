import os
import json
from datetime import datetime

UPLOAD_DIR = "storage/uploads"

def fix_filenames():
    print(f"Scanning {UPLOAD_DIR}...")
    
    count = 0
    for filename in os.listdir(UPLOAD_DIR):
        if filename.endswith("_transcript.json"):
            file_path = os.path.join(UPLOAD_DIR, filename)
            
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                
                current_name = data.get("filename")
                
                # Check if filename is missing or looks like a UUID/system name
                needs_fix = False
                if not current_name:
                    needs_fix = True
                elif "_transcript.json" in current_name:
                    needs_fix = True
                elif len(current_name) > 30 and "-" in current_name and "." not in current_name:
                    # Likely a UUID
                    needs_fix = True
                
                if needs_fix:
                    # Generate a nice name
                    created_at_str = data.get("created_at")
                    if created_at_str:
                        try:
                            dt = datetime.fromisoformat(created_at_str)
                            new_name = dt.strftime("Meeting %d.%m.%Y %H:%M")
                        except ValueError:
                            new_name = "Meeting (Recovered)"
                    else:
                        # Use file mtime
                        mtime = os.path.getmtime(file_path)
                        dt = datetime.fromtimestamp(mtime)
                        new_name = dt.strftime("Meeting %d.%m.%Y %H:%M")
                    
                    print(f"Fixing {filename}: {current_name} -> {new_name}")
                    
                    data["filename"] = new_name
                    
                    with open(file_path, "w", encoding="utf-8") as f:
                        json.dump(data, f, indent=2, ensure_ascii=False)
                    
                    count += 1
            
            except Exception as e:
                print(f"Error processing {filename}: {e}")

    print(f"Fixed {count} files.")

if __name__ == "__main__":
    fix_filenames()

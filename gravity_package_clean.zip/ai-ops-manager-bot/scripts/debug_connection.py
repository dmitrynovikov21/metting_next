import asana
import os
import sys

# Add project root to python path
sys.path.append(os.getcwd())

from app.core.config import settings

def test_connection():
    print("--- TESTING CONNECTION ---")
    configuration = asana.Configuration()
    configuration.access_token = settings.ASANA_ACCESS_TOKEN
    api_client = asana.ApiClient(configuration)
    users_api = asana.UsersApi(api_client)
    
    try:
        me = users_api.get_user("me", opts={'opt_fields': 'name,gid,workspaces'})
        print(f"✅ Connected as: {me.get('name') if isinstance(me, dict) else me.data.name}")
        
        workspaces = me.get('workspaces') if isinstance(me, dict) else me.data.workspaces
        for w in workspaces:
            print(f" - Workspace: {w['name']} ({w['gid']})")
            
    except Exception as e:
        print(f"❌ Connection failed: {e}")

if __name__ == "__main__":
    test_connection()

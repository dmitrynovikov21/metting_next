import httpx
import asyncio

async def main():
    url = "https://us-west-2-recallai-production-bot-data.s3.amazonaws.com/_workspace-4d7d9413-0b2e-4f7b-8075-bcf693681142/recordings/0e688fe8-24ba-4a76-9d51-868db326f61d/video_mixed/9fd0a4f4-84f2-491d-9de4-dcf2f1dcf6a6/bot/f3b33339-57ba-4306-9854-a6d79fa14e0b/AROA3Z2PRSQANGTUQXHNJ%3Ai-08257a8badb92b2cd/video.mp4?AWSAccessKeyId=ASIA3Z2PRSQANCPKDNBM&Signature=4eDCJJB7UCxSKHgHLKhp1fLipHA%3D&x-amz-security-token=IQoJb3JpZ2luX2VjEOb%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLXdlc3QtMiJHMEUCIFS3MhmfjavwNbutVfiLG5x2Hi6uJRy22uzoJuCcJYL9AiEArsGqGhDxabr2nCi5N98KWxE%2B3hsfUyS6xkphmghdQn0qxAUIr%2F%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FARAAGgw4MTEzNzg3NzUwNDAiDGkBg6uClRs6XO5%2BFiqYBR1L8s2yWB4K3HumXUGM11HGESfoiopzdQpE9zNSFgCs43ZgQatlbivig5Z4PPeR1JUIKIH8MhDztZysUynNts1FbbaDld0IrdKEszVe6tCQ3Kqf8qLR7bbuL17ZfuqXJbjWkdmmgySe5iVQnEnCCCFQDTzbKypbUWbOgB3asdsc%2FImSYMJxM5nm2fWsEksuotvl6knINrof0hdd8aX9K64fN8KPPyK6TSO3oiqhlw8AUEWO5toOJjh7nmJVM1BzoInzCVt058clhNhSXqmLqM1OnlmaBTmiK8qfH%2F%2BYpR138BWsOVQvw2zE5aUwdWihH3O9NQy9LJrpwFwFY9%2BnWguowDPQCoiK9YvsLS6PJ%2FNXSGRspf%2FpzT6QiytRlsdlvnNNyWXkE8%2BakyLb%2BRTJqJHkvTXdtuhFq6VA6sQ2icWECRIn8SpS4loRAjSnFhe6wvUCfzeuUrx4xI7FzeDpXPTKo1S2iY8vfb645C787%2FhiCyOqyOHGDeYXOIC71nCAt96iGKwyE1z6Ye5iFVyq2Oa6y0tmF%2FJkMiAQ1wlPLoMHGM6RLjchPOVxjDaXO7MkJ%2FaNrkHPzdxIUEkgAjMeQYjvgw9dGPFqRabPd1govgOK5cefLODgxx1KHQtYnYJOWuLVJdwj2v3dPwqZjvrw0pf7Tc1kl%2BNq0gHn2xXhGYKjLy0nlF4OL6l3RxzEkcB2kU%2F%2Fkp6fsH1gxq1v1JlNqW85GVl9dYrKW%2B2llC98f1Bykqvgiux8em5zhHvWDvoxpUYd%2Fng2VhurVj8QzLBUsXmGxonv1kMCtMnFu3m5TAZS2E4CDNjnJTbnC%2FX17iYIFOiEWqhlrH41OvxLl5NxsUHfV%2B0Lj%2FYnDj7cjzUaXiTUM4rig11otMkwtu6kyQY6sQEz8QI5%2FuV4miM6SZVAHJn0%2F5U7qCMrgg2o%2FbDta1eWG%2BPinyMk9m5fCK3LW4aWoTF0VLnTaAHbMMU5cBJVrTlof%2B450IkDOTa%2B4XwKZkqGFqVyAOOqGheQt4w%2BQYJp6gZkgbrYkps%2Bc6Z2mqHpi5W0quAWsGs4uvgB9p7hNv3YYKmD8nUNTWrbPFlGjCAQyKLXxAl2e5rpU59vgg86Rb4gmO85Pjj8JyLTj4JfvAKhV64%3D&Expires=1764332693"
    
    print(f"Testing download from: {url[:50]}...")
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(url, follow_redirects=True)
            print(f"Status Code: {response.status_code}")
            print(f"Headers: {response.headers}")
            
            if response.status_code == 200:
                print("Success! Can download video.")
                with open("test_video.mp4", "wb") as f:
                    f.write(response.content[:1024]) # Write first 1KB
                print("Saved first 1KB to test_video.mp4")
            else:
                print(f"Failed to download. Status: {response.status_code}")
                print(f"Response: {response.text[:500]}")
                
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    asyncio.run(main())

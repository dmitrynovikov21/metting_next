import asyncio
import sys
import os

# Add project root to python path
sys.path.append(os.getcwd())

from app.db.base import AsyncSessionLocal
from app.services.user_service import create_user
from app.core.config import settings

async def main():
    print(f"Creating CEO user with ID: {settings.CEO_TELEGRAM_ID}")
    
    async with AsyncSessionLocal() as session:
        try:
            user = await create_user(
                session=session,
                telegram_id=settings.CEO_TELEGRAM_ID,
                full_name="CEO",
                role="ceo",
                asana_gid="ceo_asana_gid"
            )
            print(f"✅ Successfully created user: {user.full_name} ({user.role})")
        except Exception as e:
            print(f"❌ Error creating user: {e}")

if __name__ == "__main__":
    asyncio.run(main())

import asyncio
import os
import sys

# Add parent directory to path to import app modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.db.base import AsyncSessionLocal
from app.db.models import User
from sqlalchemy.future import select

async def register_user():
    telegram_id = 293254961
    full_name = "Violetta Vlassova"
    asana_gid = "1210672849782779"
    username = "KuzneEkaterina"
    
    async with AsyncSessionLocal() as session:
        # Check if user exists
        result = await session.execute(select(User).where(User.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        
        if user:
            print(f"Updating existing user {telegram_id}...")
            user.full_name = full_name
            user.asana_gid = asana_gid
            user.is_active = True
        else:
            print(f"Creating new user {telegram_id}...")
            user = User(
                telegram_id=telegram_id,
                full_name=full_name,
                asana_gid=asana_gid,
                is_active=True,
                role="employee"
            )
            session.add(user)
            
        await session.commit()
        print(f"✅ User {full_name} (ID: {telegram_id}) registered/updated successfully!")

if __name__ == "__main__":
    asyncio.run(register_user())

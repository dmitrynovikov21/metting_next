import asana
import os
import sys

# Add project root to python path
sys.path.append(os.getcwd())

from app.core.config import settings
from app.services.asana_client import AsanaService

def debug_routing():
    print("--- DEBUGGING ROUTING ---")
    service = AsanaService()
    
    # Params simulating the failure case
    name = "Test Task for Violetta"
    notes = "Debug notes"
    
    # "Задачи отделов" project
    target_project = settings.ASANA_DEPARTMENTS_PROJECT_GID
    print(f"Target Project: {target_project}")
    
    # "HR - рекрутинг - Виолетта" section
    target_section = "1212001566672438"
    print(f"Target Section: {target_section}")
    
    # "Проект" custom field (e.g., "Общая группа")
    cf_gid = settings.ASANA_PROJECT_FIELD_GID
    cf_value = "1212001658029870" # Общая группа
    custom_fields = {cf_gid: cf_value}
    print(f"Custom Fields: {custom_fields}")
    
    try:
        print("Attempting to create task...")
        result = service.create_task(
            name=name,
            notes=notes,
            assignee_gid=service.get_me_gid(), # Assign to me for test
            custom_fields=custom_fields,
            projects=[target_project],
            section=target_section
        )
        print(f"✅ Success! Task created: {result.get('permalink_url')}")
    except Exception as e:
        print(f"❌ Error: {e}")
        # Print full error details if available
        if hasattr(e, 'body'):
            print(f"Body: {e.body}")

if __name__ == "__main__":
    debug_routing()

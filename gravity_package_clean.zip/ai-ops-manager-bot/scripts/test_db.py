import asyncio
import logging
import sys
import os

# Add project root to sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import text
from app.db.base import AsyncSessionLocal

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def test_connection():
    logger.info("Testing database connection...")
    try:
        # Check if greenlet is installed (implicit check by importing sqlalchemy async)
        import greenlet
        logger.info(f"Greenlet version: {greenlet.__version__}")
        
        async with AsyncSessionLocal() as session:
            logger.info("Executing SELECT 1...")
            result = await session.execute(text("SELECT 1"))
            val = result.scalar()
            logger.info(f"Query result: {val}")
            
            if val == 1:
                logger.info("✅ Database connection SUCCESSFUL!")
            else:
                logger.error("❌ Database returned unexpected value")
                
    except ImportError as e:
        logger.error(f"❌ Missing dependency: {e}")
    except Exception as e:
        logger.error(f"❌ Connection failed: {e}", exc_info=True)

if __name__ == "__main__":
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(test_connection())

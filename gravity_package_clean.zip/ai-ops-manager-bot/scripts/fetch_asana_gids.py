import os
import asana
from dotenv import load_dotenv

load_dotenv()

def fetch_gids():
    personal_access_token = os.getenv("ASANA_ACCESS_TOKEN")
    workspace_gid = os.getenv("ASANA_WORKSPACE_GID")

    configuration = asana.Configuration()
    configuration.access_token = personal_access_token
    api_client = asana.ApiClient(configuration)
    
    projects_api = asana.ProjectsApi(api_client)
    sections_api = asana.SectionsApi(api_client)
    custom_fields_api = asana.CustomFieldsApi(api_client)

    print(f"Fetching projects in workspace {workspace_gid}...")
    projects = projects_api.get_projects_for_workspace(workspace_gid, opts={'fields': 'name,gid'})
    
    target_project_gid = None
    target_project_name = "Denis Zaitssev" # Note: User spelling might vary slightly, checking for "Denis"
    
    for project in projects:
        if "Denis" in project['name']:
            print(f"Found Project: {project['name']} (GID: {project['gid']})")
            if project['name'] == target_project_name or "Denis Zaitsev" in project['name']:
                target_project_gid = project['gid']

    if target_project_gid:
        print(f"\nFetching sections for project {target_project_gid}...")
        sections = sections_api.get_sections_for_project(target_project_gid, opts={'fields': 'name,gid'})
        for section in sections:
            print(f"Section: {section['name']} (GID: {section['gid']})")
            
        print(f"\nFetching custom fields for project {target_project_gid}...")
        # Custom fields are usually associated with the project settings
        project_details = projects_api.get_project(target_project_gid, opts={'fields': 'custom_field_settings.custom_field.name,custom_field_settings.custom_field.gid'})
        
        if 'custom_field_settings' in project_details:
            for setting in project_details['custom_field_settings']:
                cf = setting['custom_field']
                print(f"Custom Field: {cf['name']} (GID: {cf['gid']})")
    else:
        print(f"Project '{target_project_name}' not found.")

if __name__ == "__main__":
    fetch_gids()

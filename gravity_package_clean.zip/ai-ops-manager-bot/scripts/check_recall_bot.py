import asyncio
import os
import sys

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.services.recall_service import recall_service

async def main():
    bot_id = "f3b33339-57ba-4306-9854-a6d79fa14e0b" # From logs
    print(f"Checking bot {bot_id}...")
    
    try:
        bot_info = await recall_service.get_bot(bot_id)
        import json
        with open("bot_info.json", "w") as f:
            json.dump(bot_info, f, indent=2)
        print("Bot info saved to bot_info.json")
        print(f"Bot Status: {bot_info.get('status')}")
        
        print("\nChecking transcript...")
        try:
            transcript = await recall_service.get_transcript(bot_id)
            print(f"Transcript length: {len(transcript)}")
            print(f"Transcript preview: {transcript[:200]}")
        except Exception as e:
            print(f"Transcript error: {e}")
            
    except Exception as e:
        print(f"Error getting bot info: {e}")

if __name__ == "__main__":
    asyncio.run(main())

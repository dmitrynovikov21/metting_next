import asyncio
import logging
from app.core.config import settings
from app.services.google_drive_service import google_drive_service

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def test_drive():
    print(f"Testing Google Drive API...")
    
    # Try to list files in the recordings folder
    folder_id = settings.DRIVE_RECORDINGS_ID
    if not folder_id:
        print("❌ DRIVE_RECORDINGS_ID is not set in .env")
        return

    print(f"Listing files in folder: {folder_id}")
    
    try:
        service = google_drive_service.get_service()
        results = service.files().list(
            q=f"'{folder_id}' in parents and trashed=false",
            pageSize=10,
            fields="nextPageToken, files(id, name, webViewLink)"
        ).execute()
        items = results.get('files', [])

        if not items:
            print("⚠️ No files found (but API seems to work).")
        else:
            print("✅ Files found:")
            for item in items:
                print(f" - {item['name']} ({item['id']})")
                
    except Exception as e:
        print(f"❌ Drive API Error: {e}")

if __name__ == "__main__":
    asyncio.run(test_drive())

import asyncio
import sys
import os
from telegram import Update

# Add project root to python path
sys.path.append(os.getcwd())

from app.bot.loader import create_bot_app

def main():
    print("🚀 Starting bot in POLLING mode...")
    application = create_bot_app()
    
    # Delete webhook to ensure polling works
    print("Checking webhook status...")
    # We need to run async method to delete webhook
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(application.bot.delete_webhook(drop_pending_updates=True))
    
    print("✅ Webhook deleted. Listening for updates...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()

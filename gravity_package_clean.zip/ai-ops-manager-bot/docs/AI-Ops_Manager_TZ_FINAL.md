# ТЕХНИЧЕСКОЕ ЗАДАНИЕ: AI-Ops Manager Bot v2.0
## SORP Group - Финальная версия с учетом CEO брифинга

**Дата:** 20.11.2025  
**Версия:** 2.0 Final  
**Статус:** Готово к разработке

---

## EXECUTIVE SUMMARY

**Проблема:** Нет системного управления задачами в SORP Group. Asana ведется эпизодически, задачи с собраний теряются, контроль ослабевает, менеджеры перестают фиксировать прогресс.

**Решение:** Telegram-бот с AI, который автоматизирует создание задач голосом, собирает ежедневные отчеты, проактивно контролирует прогресс и дает CEO полную видимость происходящего.

**Ключевое отличие от изначального ТЗ:**  
✅ Добавлена роль **Ассистента CEO (Екатерина)** как human-in-the-loop  
✅ CEO создает задачи голосом → попадают в "Неразобранное" → Екатерина назначает исполнителей  
✅ Фокус на **проблемах и блокерах** в отчетах  
✅ HR-функционал вынесен в **Phase 2**  
✅ MVP за **4 недели** с минимальным набором функций

---

## 1. CORE CONCEPT

### 1.1 Трехуровневая система создания задач

```
┌──────────────────────────────────────────────────────────┐
│ LEVEL 1: CEO                                              │
│ Создает задачи голосом/текстом → AI обрабатывает →      │
│ Задача падает в Asana "Входящие/Неразобранное"          │
└──────────────────────────────────────────────────────────┘
                            ↓
┌──────────────────────────────────────────────────────────┐
│ LEVEL 2: Ассистент CEO (Екатерина)                      │
│ Видит задачу в боте → AI рекомендует исполнителя →      │
│ Екатерина назначает → Задача активируется                │
└──────────────────────────────────────────────────────────┘
                            ↓
┌──────────────────────────────────────────────────────────┐
│ LEVEL 3: Исполнитель                                      │
│ Получает уведомление → Работает над задачей →            │
│ Отчитывается через бота (18:00)                          │
└──────────────────────────────────────────────────────────┘
```

### 1.2 Целевые метрики успеха

| Метрика | Текущее | Цель | Способ измерения |
|---------|---------|------|------------------|
| Время на постановку задач | 15 мин | 4 мин (-70%) | Время от идеи до задачи в Asana |
| Дисциплина отчетности | 60-70% | 95-100% | % сотрудников, сдавших отчет вовремя |
| Задачи в срок | Baseline | +20% | % задач, завершенных до дедлайна |
| Adoption rate | - | 90%+ | % сотрудников, использующих бота ежедневно |

---

## 2. РОЛЕВАЯ МОДЕЛЬ

### 2.1 CEO (Futuristic)

**Права:**
- ✅ Создание задач голосом (через ассистента)
- ✅ Просмотр ВСЕХ задач и отчетов
- ✅ Daily Digest (09:00)
- ✅ Burnout alerts (конфиденциально)
- ✅ Финальное подтверждение задач из протоколов встреч

**Главный use case:** 
```
CEO (голос): "Кирилл, подготовь презентацию для партнеров по ИИ, 
возьми цифры у Мейраса, к среде нужно"

↓ Бот обрабатывает через GPT-4o

Бот → CEO: "✅ Задача создана в 'Неразобранное'
Екатерина назначит исполнителя в течение часа"

Бот → Екатерина: "📥 Новая задача от CEO
AI рекомендует: Кирилл А. (Маркетинг), confidence 90%
[Назначить как предложено] [Изменить]"
```

### 2.2 Ассистент CEO (Екатерина)

**Роль:** Human-in-the-loop для контроля качества AI

**Права:**
- ✅ Видит все задачи в "Неразобранное"
- ✅ Может назначать задачи любым сотрудникам
- ✅ Устанавливает/меняет дедлайны
- ✅ Видит AI-рекомендации

**Workflow:**
```
1. Получает уведомление о новой задаче от CEO
2. Видит AI-анализ: рекомендуемый исполнитель, дедлайн, приоритет
3. Принимает решение:
   - Согласна → нажимает кнопку → задача назначается автоматически
   - Не согласна → меняет в Asana вручную
4. Система уведомляет всех участников
```

### 2.3 Топ-менеджер (8 человек)

**Права:**
- ✅ Создание задач своему отделу (напрямую, без ассистента)
- ✅ Просмотр задач/отчетов только своего департамента
- ✅ Департаментская аналитика
- ❌ НЕ видит другие департаменты

### 2.4 Рядовой сотрудник (50 человек)

**Главный use case:**
```
18:00 - Бот напоминает об отчете

Сотрудник (голосовое 2 мин): "Сегодня закончил анализ конкурентов, 
нашел 12 компаний. Завтра начну контент-план. Проблема - нет доступа 
к Google Analytics, писал IT три дня назад, ответа нет"

↓ AI обрабатывает

Бот:
1. Обновляет задачу "Анализ конкурентов" → completed
2. Добавляет блокер к задаче "Контент-план"
3. Уведомляет менеджера о проблеме
4. Эскалирует IT

Бот → Сотрудник: "✅ Отчет принят!
✓ Задача 'Анализ' отмечена выполненной
⚠️ Проблему с Analytics эскалировал руководителю и IT"
```

---

## 3. MVP SCOPE (4 недели)

### ✅ ЧТО ВХОДИТ В MVP

**1. Создание задач CEO**
- Голосовые/текстовые сообщения
- Whisper API транскрипция
- GPT-4o парсинг (intent + entities)
- Создание в Asana "Входящие/Неразобранное"
- Уведомление ассистенту

**2. Обработка ассистентом**
- Интерфейс для просмотра необработанных задач
- AI-рекомендации (исполнитель, дедлайн)
- Быстрое назначение одной кнопкой
- Обновление в Asana

**3. Ежедневные отчеты (18:00)**
- Массовая рассылка напоминаний
- Прием голосовых/текстовых отчетов
- AI-анализ (GPT-4o)
- Сопоставление с задачами Asana
- Обновление прогресса
- Детекция блокеров → уведомления менеджерам

**4. Daily Digest для CEO (09:00)**
- Кто не отчитался
- Завершенные задачи вчера
- Проблемы и блокеры (severity: high/critical)
- Дедлайны сегодня
- Топ achievements

**5. Проактивные запросы**
- Задачи просрочены → запрос статуса
- Задачи долго без движения → "Как дела?"
- Дедлайн завтра → "Успеваешь?"

**6. Базовый поиск**
- "Покажи мои задачи на неделю"
- "Какие задачи у Радмира просрочены?"
- "Найди задачу про презентацию"

### ❌ ЧТО НЕ ВХОДИТ В MVP

- HR-функционал (отпуска, командировки) → Phase 2
- Согласование документов → Phase 2
- Транскрипция встреч → Phase 3
- Burnout detection → Phase 3 (нужны данные за 2+ недели)
- Интеграция AmoCRM → Phase 3
- Детальная аналитика → Phase 3

---

## 4. ТЕХНИЧЕСКИЙ СТЕК

### Backend
```yaml
Language: Python 3.11+
Framework: FastAPI
Queue: Celery + Redis
DB: PostgreSQL 15+
ORM: SQLAlchemy 2.0+
```

### AI/ML
```yaml
Primary LLM: OpenAI GPT-4o (gpt-4o-2024-08-06)
Speech-to-Text: OpenAI Whisper (whisper-1)
Embeddings: text-embedding-3-large
Vector DB: Pinecone (Starter) / Weaviate (self-hosted)
```

### Integrations
```yaml
Telegram: python-telegram-bot 20.6+
Asana: asana 3.2+ (official lib)
Google Drive: google-api-python-client
```

### Infrastructure
```yaml
Development: Antigravity (AI-assisted coding)
Containers: Docker + Docker Compose
Hosting: DigitalOcean / AWS
CI/CD: GitHub Actions
Monitoring: Sentry
```

---

## 5. БАЗА ДАННЫХ (Ключевые таблицы)

```sql
-- USERS
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    telegram_id BIGINT UNIQUE NOT NULL,
    asana_gid VARCHAR(50) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role VARCHAR(20) NOT NULL, -- ceo, ceo_assistant, manager, employee, admin
    department VARCHAR(50),
    manager_id INTEGER REFERENCES users(id),
    timezone VARCHAR(50) DEFAULT 'Asia/Dubai',
    language VARCHAR(5) DEFAULT 'ru'
);

-- TASKS CACHE (синхронизация из Asana)
CREATE TABLE tasks_cache (
    id SERIAL PRIMARY KEY,
    asana_gid VARCHAR(50) UNIQUE NOT NULL,
    name TEXT NOT NULL,
    assignee_user_id INTEGER REFERENCES users(id),
    due_date DATE,
    status VARCHAR(50),
    priority VARCHAR(20),
    progress INTEGER DEFAULT 0,
    last_sync TIMESTAMP DEFAULT NOW()
);

-- DAILY REPORTS
CREATE TABLE daily_reports (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) NOT NULL,
    report_date DATE NOT NULL,
    completed_tasks JSONB,
    in_progress JSONB,
    blockers JSONB,
    tomorrow_plans TEXT[],
    raw_text TEXT,
    sentiment VARCHAR(20),
    submitted_at TIMESTAMP DEFAULT NOW(),
    UNIQUE (user_id, report_date)
);

-- ACTION LOGS
CREATE TABLE action_logs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    action_type VARCHAR(50) NOT NULL,
    action_data JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);
```

---

## 6. AI PROMPTS (Критически важные)

### 6.1 Task Creation Prompt

```python
system_prompt = f"""
Проанализируй текст и извлеки информацию для создания задачи.

Текст: "{transcribed_text}"

Контекст: Сообщение от CEO компании SORP Group с 59 сотрудниками.

База сотрудников: {employees_database}

Задача:
1. Определи intent (создание задачи / вопрос / общение)
2. Если задача, извлеки:
   - Кому (имя, отдел если упомянут)
   - Что нужно сделать (название + детали)
   - Дедлайн (если упомянут)
   - Упомянутые другие сотрудники
   - Приоритет

Верни JSON с полями confidence для каждой сущности.
"""

# Ответ:
{
  "intent": "create_task",
  "confidence": 0.95,
  "entities": {
    "assignee_candidates": [
      {
        "name": "Кирилл Александров",
        "department": "Маркетинг",
        "asana_gid": "1234567890",
        "confidence": 0.9
      }
    ],
    "task_title": "Подготовить презентацию для партнеров по ИИ",
    "task_description": "Взять цифры у Мейраса из бухгалтерии",
    "deadline": {
      "raw": "к среде",
      "parsed_date": "2025-11-27",
      "confidence": 0.85
    },
    "mentioned_collaborators": ["Мейрас"],
    "priority": "normal"
  }
}
```

### 6.2 Report Analysis Prompt

```python
system_prompt = f"""
Проанализируй ежедневный отчет сотрудника.

Сотрудник: {employee_name} ({department})
Активные задачи в Asana: {active_tasks_json}

Отчет: \"\"\"{report_text}\"\"\"

Извлеки:
1. completed_tasks - что завершено (сопоставь с задачами Asana)
2. in_progress - что в процессе (оцени прогресс %)
3. blockers - проблемы (оцени severity: low/medium/high/critical)
4. tomorrow_plans - планы на завтра
5. sentiment - тональность (positive/neutral/negative)
6. burnout_indicators - признаки усталости

Для завершенных задач определи: нужно ли отметить completed в Asana?
Для блокеров: нужна ли эскалация менеджеру?

Верни JSON.
"""
```

---

## 7. PHASE 2: HR & ДОКУМЕНТООБОРОТ (Недели 5-10)

### 7.1 HR Функционал

**Отпуска:**
```
User: "Хочу оформить отпуск"

Bot: (диалоговый интерфейс)
1. Какие даты?
2. Тип отпуска?
3. Причина?

→ Генерирует PDF заявление
→ Запускает цифровой workflow согласования:
   Руководитель → HR → CEO
→ Сохраняет в Google Drive
→ Обновляет реестр согласований
```

**Командировки:**
- Аналогичный flow
- Дополнительные поля: место, цель, бюджет
- Согласование: Руководитель → Finance → CEO

**Больничные:**
- Уведомление без согласования
- Автоматическая эскалация руководителю
- Перенос задач с ближайшими дедлайнами

### 7.2 Согласование документов

```
User: [отправляет PDF]
User: "Нужно согласовать с Кириллом и CEO"

Bot: Настройка цепочки:
1. Кирилл → 2. CEO

→ Уведомления по цепочке
→ Каждый может: Согласовать / Отклонить / Запросить правки
→ Все действия логируются в реестр
→ Финальный документ в Google Drive
```

### 7.3 Обратная связь и жалобы

**Обычная обратная связь:**
- Идеи, предложения
- Отправка руководителю / HR / CEO

**Жалобы на руководителя:**
- С указанием имени / Анонимно
- Напрямую CEO (конфиденциально)
- ID: COMPLAINT-ANON-2025-XXXX

---

## 8. PHASE 3: РАСШИРЕННАЯ АВТОМАТИЗАЦИЯ (Недели 11-14)

### 8.1 Транскрипция встреч

**Источники:**
1. Zoom recordings (автоматически через webhook)
2. Диктофонные записи (ручная загрузка)
3. Текстовые протоколы

**Process:**
```
Аудио → Whisper API (транскрипция) →
GPT-4o (извлечение action items) →
CEO просматривает и подтверждает →
Задачи создаются в "Неразобранное" →
Екатерина назначает
```

### 8.2 Burnout Detection

```python
BURNOUT_INDICATORS = {
    "negative_keywords": ["устал", "не успеваю", "опять", "тяжело"],
    "short_responses": True,  # <20 слов
    "late_responses": True,   # После 21:00
    "weekend_work": True,
    "consecutive_days": 3     # Порог для алерта
}

# Алгоритм:
1. Анализ каждого отчета (sentiment)
2. Подсчет индикаторов за 7 дней
3. Score > threshold → алерт CEO (конфиденциально)
```

---

## 9. БЕЗОПАСНОСТЬ

### 9.1 Разграничение доступа

| Роль | Видит задачи | Видит отчеты | Burnout alerts | Жалобы |
|------|--------------|--------------|----------------|--------|
| CEO | Все | Все | ✅ | ✅ (все, вкл. анонимные) |
| Ассистент | Все | Все | ❌ | ❌ |
| Менеджер | Свой отдел | Свой отдел | ❌ | ❌ |
| Сотрудник | Свои | Свои | ❌ | ❌ |

### 9.2 Шифрование

- Все чувствительные данные в БД: AES-256
- HTTPS для всех API запросов
- Конфиденциальные алерты: отдельное шифрование

### 9.3 Audit Logging

```sql
-- Все действия логируются
INSERT INTO action_logs (user_id, action_type, action_data)
VALUES (123, 'task_created', '{"task_gid": "...", "via": "voice"}');
```

---

## 10. МЕТРИКИ И МОНИТОРИНГ

### 10.1 System Health

```python
# Celery task каждые 5 минут
@celery.task
async def check_system_health():
    checks = {
        "telegram_bot": await check_telegram_connection(),
        "asana_api": await check_asana_connection(),
        "openai_api": await check_openai_connection(),
        "database": await check_database_connection(),
        "redis": await check_redis_connection()
    }
    
    if not all(checks.values()):
        await alert_admin(checks)
```

### 10.2 Business Metrics

```python
async def calculate_kpis(date_from, date_to):
    return {
        "adoption_rate": 92.3,  # % using bot daily
        "report_compliance": 96.8,  # % reports on time
        "time_saved_hours": 45.2,  # CEO time saved
        "task_completion_rate": 87.5,  # % tasks on time
        "avg_response_time_ms": 1234,  # Bot response time
        "user_satisfaction": 4.6  # /5 rating
    }

# Еженедельная отправка CEO
```

---

## 11. ПЛАН РАЗРАБОТКИ

### Week 1: Infrastructure
- ✅ Server setup (DigitalOcean)
- ✅ PostgreSQL setup
- ✅ Basic Telegram bot (webhook)
- ✅ User authentication
- ✅ Asana API integration (basic)

### Week 2: Task Creation
- ✅ Whisper API integration
- ✅ GPT-4o task parsing
- ✅ Create in "Неразобранное"
- ✅ Assistant interface for processing
- ✅ Notifications

### Week 3: Daily Reports
- ✅ Reminder system (18:00)
- ✅ GPT-4o report analysis
- ✅ Match with Asana tasks
- ✅ Update progress
- ✅ Blocker escalation

### Week 4: Daily Digest & Testing
- ✅ Generate Daily Digest (09:00)
- ✅ Proactive status requests
- ✅ Basic search
- ✅ Testing with top managers
- ✅ Bug fixes

**MVP Complete! 🎉**

---

## 12. БЮДЖЕТ

### 12.1 Development

- **MVP (4 weeks):** $9,500
  - Backend dev: $6,000
  - AI/ML: $2,000
  - DevOps: $1,500

- **Phase 2 (6 weeks):** $10,500
- **Phase 3 (4 weeks):** $8,000

**Total:** $28,000

### 12.2 Monthly Operational

| Item | Cost |
|------|------|
| Infrastructure (DO/AWS) | $250 |
| OpenAI API | $800 |
| Pinecone | $70 |
| Other | $180 |
| **Total** | **$1,300/mo** |

При 200 пользователях: ~$3,200/mo

---

## 13. SUCCESS CRITERIA

### MVP Launch (End of Week 4)

✅ CEO can create tasks via voice → lands in "Неразобранное"  
✅ Екатерина sees task in bot, can assign with 1 click  
✅ All 59 employees can submit reports via bot at 18:00  
✅ Reports processed by AI, update Asana  
✅ CEO receives Daily Digest at 09:00  
✅ System stable, no critical bugs  

### 3 Months Post-Launch

✅ Adoption rate >90%  
✅ Report compliance >95%  
✅ CEO time saved: 70%+  
✅ Task completion rate: +20%  
✅ User satisfaction: 4.5/5  

---

## 14. RISKS & MITIGATION

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Asana API downtime | Medium | High | Local cache, retry logic |
| OpenAI limits exceeded | Medium | Medium | Monitor usage, fallback to Claude |
| Low adoption | Low | High | Training, gamification, personal onboarding |
| AI parsing errors | Medium | Medium | Clarification system, human-in-the-loop |

---

## 15. NEXT STEPS

### This Week
1. ✅ Approve final TZ
2. ⏳ Hire backend dev (via Antigravity)
3. ⏳ Setup infrastructure
4. ⏳ Get API keys (OpenAI, Asana, Google)

### Week 1 Development
1. ⏳ Project setup
2. ⏳ Database schema
3. ⏳ Basic Telegram bot
4. ⏳ Authentication system
5. ⏳ Asana integration (basic)

---

## ПРИЛОЖЕНИЯ

### A. Ключевые команды бота

```
/start - Регистрация
/tasks - Мои задачи
/report - Отправить отчет
/search - Поиск задач
/help - Справка

Менеджеры:
/team - Задачи команды
/stats - Статистика отдела

CEO:
/digest - Daily Digest
/analytics - Полная аналитика
/unprocessed - Необработанные задачи (для ассистента)
```

### B. Структура проекта

```
ai-ops-manager-bot/
├── app/
│   ├── bot/          # Telegram handlers
│   ├── api/          # REST endpoints
│   ├── services/     # Business logic
│   ├── integrations/ # External APIs
│   ├── ai/           # LLM prompts & parsers
│   ├── db/           # Database models
│   └── tasks/        # Celery tasks
├── tests/
├── scripts/
└── docs/
```

---

## ПОДПИСИ

**Согласовано:**
- CEO (Futuristic): _______________ Дата: _______
- Ассистент CEO (Екатерина): _______________ Дата: _______
- Backend Developer: _______________ Дата: _______

---

**КОНЕЦ ДОКУМЕНТА**

*Готово к разработке. MVP за 4 недели. Let's build! 🚀*

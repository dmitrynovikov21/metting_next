# 🚀 QUICK START GUIDE
## AI-Ops Manager Bot - Быстрый старт для разработки

---

## ✅ ЧТО НУЖНО СДЕЛАТЬ ПРЯМО СЕЙЧАС

### 1. Утвердить ТЗ ✍️
- [ ] CEO (Futuristic) просмотрел и согласен
- [ ] Ассистент (Екатерина) ознакомлена с workflow
- [ ] Подтверждены приоритеты MVP

### 2. Найти Backend Developer 👨‍💻
**Требования:**
- Python 3.11+
- Опыт с FastAPI + Celery
- Знание PostgreSQL
- Опыт интеграции с API (Telegram, Asana, OpenAI)
- **Инструмент:** Antigravity для AI-assisted coding

**Где искать:**
- Antigravity (рекомендовано)
- Ваша сеть контактов
- Фриланс платформы

### 3. Получить API Keys 🔑
```
✅ Telegram Bot Token
   → @BotFather: /newbot
   
✅ Asana Access Token
   → https://app.asana.com/0/my-apps
   → Create Personal Access Token
   
✅ OpenAI API Key
   → https://platform.openai.com/api-keys
   → Проверить лимиты billing
   
✅ Google Service Account
   → Google Cloud Console
   → Enable Drive API
   → Create Service Account
   → Download JSON key
```

### 4. Setup Infrastructure 🖥️
**Option A: DigitalOcean (Рекомендуется для начала)**
```bash
# Droplet specs for MVP:
- 4 vCPUs
- 8 GB RAM
- 160 GB SSD
- Ubuntu 24.04

Cost: ~$48/month
```

**Option B: AWS**
```bash
# EC2 instance:
- t3.large
- 2 vCPUs, 8 GB RAM
- 50 GB EBS

Cost: ~$70/month
```

---

## 📋 MVP CHECKLIST (4 WEEKS)

### Week 1: Foundation
```
Day 1-2: Infrastructure
- [ ] Server setup
- [ ] Domain & SSL (bot.sorpgroup.com)
- [ ] PostgreSQL installation
- [ ] Redis installation
- [ ] Docker setup

Day 3-4: Bot basics
- [ ] Telegram webhook setup
- [ ] Basic message handling
- [ ] User authentication system
- [ ] Access codes generation

Day 5: Asana integration
- [ ] Connect to Asana API
- [ ] Test create/read tasks
- [ ] Find "Inbox" project
- [ ] Create "Неразобранное" section
```

### Week 2: Task Creation
```
Day 1-2: AI Integration
- [ ] OpenAI API setup
- [ ] Whisper transcription test
- [ ] GPT-4o task parsing
- [ ] Entity extraction

Day 3-4: Create task flow
- [ ] CEO sends voice → transcript
- [ ] AI parses → entities
- [ ] Create in Asana "Неразобранное"
- [ ] Notify assistant

Day 5: Assistant interface
- [ ] Show unprocessed tasks
- [ ] AI recommendations display
- [ ] Quick assign button
- [ ] Update Asana when assigned
```

### Week 3: Daily Reports
```
Day 1: Reminders
- [ ] Celery setup
- [ ] 18:00 mass reminder
- [ ] Track who reported
- [ ] Second reminder logic

Day 2-3: Report processing
- [ ] Accept voice/text reports
- [ ] GPT-4o report analysis
- [ ] Extract: completed, in_progress, blockers
- [ ] Store in database

Day 4-5: Asana updates
- [ ] Match report → tasks
- [ ] Update progress
- [ ] Mark completed
- [ ] Add blocker comments
- [ ] Notify managers
```

### Week 4: Daily Digest & Polish
```
Day 1-2: Daily Digest
- [ ] Collect yesterday's data
- [ ] Format digest message
- [ ] Send to CEO at 09:00
- [ ] Include: reporting, achievements, blockers

Day 3: Proactive checks
- [ ] Detect overdue tasks
- [ ] Detect stale tasks
- [ ] Send status requests

Day 4: Testing
- [ ] Test with 8 top managers
- [ ] Fix critical bugs
- [ ] Performance testing

Day 5: Launch prep
- [ ] Documentation
- [ ] Training materials
- [ ] Rollout plan
```

---

## 🔥 КРИТИЧНЫЕ РЕШЕНИЯ АРХИТЕКТУРЫ

### 1. Роль Ассистента
```python
# CEO создает → "Неразобранное" → Ассистент назначает

# WHY: 
# - AI не всегда точен (особенно русские имена)
# - Нужен human-in-the-loop для качества
# - CEO доверяет, что задачи не потеряются
```

### 2. Проблемы важнее достижений
```python
# В отчетах фокус на blockers:
severity = ["low", "medium", "high", "critical"]

# Автоэскалация:
if severity in ["high", "critical"]:
    notify_manager()
    if "IT" in blocker_text:
        notify_it_department()
```

### 3. MVP минимален
```
✅ ВКЛЮЧЕНО:
- Task creation (CEO voice)
- Daily reports (all employees)
- Daily digest (CEO)
- Proactive checks

❌ ИСКЛЮЧЕНО:
- HR (Phase 2)
- Document approvals (Phase 2)
- Meeting transcripts (Phase 3)
- Burnout detection (Phase 3)
```

---

## 💻 TECH_STACK_SETUP

### Docker Compose
```yaml
version: '3.8'

services:
  bot:
    build: .
    environment:
      - DATABASE_URL=postgresql://...
      - REDIS_URL=redis://redis:6379
      - TELEGRAM_BOT_TOKEN=...
      - OPENAI_API_KEY=...
    depends_on:
      - postgres
      - redis
  
  postgres:
    image: postgres:15
    volumes:
      - postgres_data:/var/lib/postgresql/data
    environment:
      - POSTGRES_DB=aiops
      - POSTGRES_USER=...
      - POSTGRES_PASSWORD=...
  
  redis:
    image: redis:7-alpine
  
  celery_worker:
    build: .
    command: celery -A app.tasks worker
    depends_on:
      - redis
      - postgres
  
  celery_beat:
    build: .
    command: celery -A app.tasks beat
    depends_on:
      - redis

volumes:
  postgres_data:
```

### Environment Variables
```bash
# .env file
DATABASE_URL=postgresql://user:pass@localhost/aiops
REDIS_URL=redis://localhost:6379
TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
OPENAI_API_KEY=sk-...
ASANA_ACCESS_TOKEN=...
ASANA_WORKSPACE_GID=...
CEO_TELEGRAM_ID=123456789
ASSISTANT_TELEGRAM_ID=987654321
```

---

## 🧪 ТЕСТИРОВАНИЕ MVP

### Сценарий 1: CEO создает задачу
```
1. CEO отправляет голосовое: "Кирилл, презентация к среде"
2. Проверить: задача в Asana "Неразобранное"
3. Проверить: Екатерина получила уведомление
4. Екатерина нажимает "Назначить"
5. Проверить: Кирилл получил уведомление
6. Проверить: задача переместилась в правильный проект

✅ PASS если все шаги работают < 2 минут
```

### Сценарий 2: Отчет сотрудника
```
1. 18:00 - все получили напоминание
2. Сотрудник отправляет отчет (голос)
3. Проверить: отчет сохранен в БД
4. Проверить: задачи обновлены в Asana
5. Если блокер → менеджер получил уведомление

✅ PASS если < 30 секунд на обработку
```

### Сценарий 3: Daily Digest
```
1. 09:00 - CEO получает digest
2. Проверить: данные актуальные (вчера)
3. Проверить: все секции присутствуют
4. Проверить: блокеры отображены корректно

✅ PASS если digest приходит точно в 09:00 ±1 мин
```

---

## 📊 SUCCESS METRICS (Конец Week 4)

```
Target:
✅ 8/8 топ-менеджеров используют бота
✅ 95%+ отчетность (56+/59 сотрудников)
✅ CEO создал 20+ задач голосом
✅ Uptime 99%+ (менее 1 часа downtime)
✅ Avg response time < 2 секунд
✅ 0 критичных багов
```

---

## 🆘 ЧАСТЫЕ ПРОБЛЕМЫ

### Problem: Whisper плохо распознает русский
```
Solution:
- Используй language="ru" параметр
- Для mixed speech: language="auto"
- Если проблема persist: попробуй Deepgram API
```

### Problem: AI неправильно парсит имена
```
Solution:
- Добавь examples в промпт (few-shot learning)
- Уменьши confidence threshold → больше уточняющих вопросов
- Human-in-the-loop (ассистент) решает проблему
```

### Problem: Asana API rate limits
```
Solution:
- Кешируй задачи в PostgreSQL
- Синхронизируй каждые 15 мин, не каждый запрос
- Используй webhooks для реал-тайм обновлений
```

---

## 📞 КОНТАКТЫ

**Проект-команда:**
- Product Owner: Futuristic (CEO)
- Key User: Екатерина (Assistant)
- Developer: [TBD]
- Code Reviewer: [Профи программист SORP]

**Каналы:**
- Daily Standup: Telegram @ 10:00
- Code: GitHub (private repo)
- Tasks: Asana project "AI-Ops Manager Bot"

---

## 🎯 NEXT STEPS

1. **Сегодня:**
   - [ ] Утвердить это Quick Start Guide
   - [ ] Начать поиск разработчика
   
2. **Эта неделя:**
   - [ ] Нанять разработчика
   - [ ] Setup сервера
   - [ ] Получить все API keys
   
3. **Следующий понедельник:**
   - [ ] Kick-off meeting с командой
   - [ ] Sprint 1 начало разработки

---

**LET'S BUILD! 🚀**

# ТЕХНИЧЕСКИЕ СПЕЦИФИКАЦИИ - Детальное дополнение к ТЗ
## AI-Ops Manager Bot - Техническая документация

---

## 1. ДЕТАЛЬНАЯ АРХИТЕКТУРА СИСТЕМЫ

### 1.1 Компоненты

```
┌─────────────────────────────────────────────────────────────┐
│                    USER LAYER (Telegram)                     │
│  59 пользователей: CEO, Assistant, 8 Managers, 50 Employees │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│              TELEGRAM BOT (python-telegram-bot)              │
│  • Webhook handler                                           │
│  • Message routing                                           │
│  • State management (ConversationHandler)                    │
└──────────────────────────┬──────────────────────────────────┘
                           │
                    ┌──────┴──────┐
                    │             │
                    ▼             ▼
         ┌─────────────────┐  ┌─────────────────┐
         │  FastAPI Server │  │   Celery Queue  │
         │  (REST API)     │  │   (Background)  │
         └────────┬─────────┘  └────────┬────────┘
                  │                     │
         ┌────────┴────────┬────────────┴────────┐
         │                 │                     │
         ▼                 ▼                     ▼
   ┌──────────┐     ┌──────────┐        ┌──────────┐
   │PostgreSQL│     │  Redis   │        │ Pinecone │
   │   (DB)   │     │ (Cache)  │        │ (Vector) │
   └──────────┘     └──────────┘        └──────────┘
                           │
              ┌────────────┴────────────┐
              │                         │
              ▼                         ▼
      ┌───────────────┐         ┌───────────────┐
      │   Asana API   │         │  OpenAI API   │
      │               │         │  (GPT+Whisper)│
      └───────────────┘         └───────────────┘
```

### 1.2 Data Flow: Создание задачи CEO

```python
# Step 1: CEO sends voice message
telegram_update = {
    "message": {
        "from": {"id": CEO_TELEGRAM_ID},
        "voice": {
            "file_id": "AwACAgIAAxkDAAIC...",
            "duration": 154
        }
    }
}

# Step 2: Download & transcribe
voice_file = await bot.download_file(file_id)
transcript = await whisper_api.transcribe(voice_file)
# → "Кирилл, подготовь презентацию для партнеров по ИИ..."

# Step 3: AI parsing
parsed = await gpt_parse_task(transcript)
{
    "intent": "create_task",
    "assignee": "Кирилл Александров",
    "task_title": "Подготовить презентацию...",
    "confidence": 0.92
}

# Step 4: Create in Asana
task = await asana_client.tasks.create({
    "name": parsed["task_title"],
    "projects": [INBOX_PROJECT_GID],
    "memberships": [{
        "project": INBOX_PROJECT_GID,
        "section": UNPROCESSED_SECTION_GID
    }],
    "custom_fields": {
        STATUS_FIELD: "awaiting_assignment"
    }
})

# Step 5: Notify assistant
await bot.send_message(
    ASSISTANT_TELEGRAM_ID,
    "📥 Новая задача от CEO\n[AI рекомендует...]"
)
```

---

## 2. ПОЛНАЯ СХЕМА БАЗЫ ДАННЫХ

```sql
-- ============================================
-- USER MANAGEMENT
-- ============================================

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    telegram_id BIGINT UNIQUE NOT NULL,
    asana_gid VARCHAR(50) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role VARCHAR(20) NOT NULL 
        CHECK (role IN ('ceo', 'ceo_assistant', 'manager', 'employee', 'admin')),
    department VARCHAR(50),
    manager_id INTEGER REFERENCES users(id),
    timezone VARCHAR(50) DEFAULT 'Asia/Dubai',
    language VARCHAR(5) DEFAULT 'ru',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_users_telegram ON users(telegram_id);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_dept ON users(department);

-- Notification preferences
CREATE TABLE notification_settings (
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    daily_reminder BOOLEAN DEFAULT TRUE,
    daily_reminder_time TIME DEFAULT '18:00',
    task_updates BOOLEAN DEFAULT TRUE,
    deadline_reminders BOOLEAN DEFAULT TRUE,
    quiet_hours_start TIME DEFAULT '22:00',
    quiet_hours_end TIME DEFAULT '08:00',
    enable_voice_responses BOOLEAN DEFAULT FALSE,
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Access codes for registration
CREATE TABLE access_codes (
    code VARCHAR(50) PRIMARY KEY,
    asana_gid VARCHAR(50) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role VARCHAR(20) NOT NULL,
    department VARCHAR(50),
    manager_telegram_id BIGINT,
    is_used BOOLEAN DEFAULT FALSE,
    used_by_telegram_id BIGINT,
    used_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    created_by INTEGER REFERENCES users(id)
);

CREATE INDEX idx_access_codes_used ON access_codes(is_used);

-- ============================================
-- TASKS (Cache from Asana)
-- ============================================

CREATE TABLE tasks_cache (
    id SERIAL PRIMARY KEY,
    asana_gid VARCHAR(50) UNIQUE NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    assignee_user_id INTEGER REFERENCES users(id),
    assignee_asana_gid VARCHAR(50),
    project_gid VARCHAR(50),
    project_name VARCHAR(200),
    section_gid VARCHAR(50),
    section_name VARCHAR(100),
    due_date DATE,
    due_time TIME,
    start_date DATE,
    completed BOOLEAN DEFAULT FALSE,
    completed_at TIMESTAMP,
    status VARCHAR(50),
    priority VARCHAR(20),
    progress INTEGER DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
    created_by_user_id INTEGER REFERENCES users(id),
    created_at_asana TIMESTAMP,
    modified_at_asana TIMESTAMP,
    last_sync TIMESTAMP DEFAULT NOW(),
    permalink_url TEXT
);

CREATE INDEX idx_tasks_asana_gid ON tasks_cache(asana_gid);
CREATE INDEX idx_tasks_assignee ON tasks_cache(assignee_user_id);
CREATE INDEX idx_tasks_due_date ON tasks_cache(due_date) WHERE completed = FALSE;
CREATE INDEX idx_tasks_status ON tasks_cache(status);
CREATE INDEX idx_tasks_project ON tasks_cache(project_gid);
CREATE INDEX idx_tasks_composite ON tasks_cache(assignee_user_id, status, due_date);

-- Task followers
CREATE TABLE task_followers (
    task_id INTEGER REFERENCES tasks_cache(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    added_at TIMESTAMP DEFAULT NOW(),
    PRIMARY KEY (task_id, user_id)
);

-- Task tags
CREATE TABLE task_tags (
    task_id INTEGER REFERENCES tasks_cache(id) ON DELETE CASCADE,
    tag_gid VARCHAR(50),
    tag_name VARCHAR(100),
    PRIMARY KEY (task_id, tag_gid)
);

-- ============================================
-- DAILY REPORTS
-- ============================================

CREATE TABLE daily_reports (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) NOT NULL,
    report_date DATE NOT NULL,
    
    -- Structured data from AI analysis
    completed_tasks JSONB,  
    /* Structure:
    [
        {
            "description": "Завершен анализ конкурентов",
            "related_asana_task_gid": "1234567890",
            "should_mark_complete": true,
            "confidence": 0.95
        }
    ]
    */
    
    in_progress JSONB,
    /* Structure:
    [
        {
            "description": "Контент-план на декабрь",
            "related_asana_task_gid": "9876543210",
            "progress_percentage": 70,
            "confidence": 0.85
        }
    ]
    */
    
    blockers JSONB,
    /* Structure:
    [
        {
            "description": "Нет доступа к Google Analytics",
            "severity": "high",
            "related_asana_task_gid": "1122334455",
            "needs_escalation": true,
            "suggested_action": "Эскалировать в IT"
        }
    ]
    */
    
    tomorrow_plans TEXT[],
    raw_text TEXT,
    
    -- Sentiment analysis
    sentiment VARCHAR(20) CHECK (sentiment IN ('positive', 'neutral', 'negative')),
    sentiment_score FLOAT CHECK (sentiment_score >= 0 AND sentiment_score <= 1),
    
    -- Performance metrics
    productivity_estimate FLOAT CHECK (productivity_estimate >= 0 AND productivity_estimate <= 1),
    
    -- Burnout indicators
    burnout_indicators TEXT[],
    /* Examples: 
       ["negative_keywords", "late_submission", "weekend_work"]
    */
    
    -- Processing status
    submitted_at TIMESTAMP DEFAULT NOW(),
    processed BOOLEAN DEFAULT FALSE,
    asana_updated BOOLEAN DEFAULT FALSE,
    processing_errors TEXT,
    
    UNIQUE (user_id, report_date)
);

CREATE INDEX idx_reports_user_date ON daily_reports(user_id, report_date DESC);
CREATE INDEX idx_reports_date ON daily_reports(report_date);
CREATE INDEX idx_reports_sentiment ON daily_reports(sentiment);
CREATE INDEX idx_reports_processed ON daily_reports(user_id, report_date DESC, processed);

-- ============================================
-- DOCUMENTS
-- ============================================

CREATE TABLE documents (
    id SERIAL PRIMARY KEY,
    file_name VARCHAR(255) NOT NULL,
    file_path TEXT NOT NULL,
    google_drive_id VARCHAR(100),
    google_drive_url TEXT,
    file_type VARCHAR(20),
    file_size INTEGER,
    mime_type VARCHAR(100),
    uploaded_by INTEGER REFERENCES users(id),
    uploaded_at TIMESTAMP DEFAULT NOW(),
    related_task_gid VARCHAR(50),
    
    -- AI extracted data
    extracted_text TEXT,
    summary TEXT,
    key_points TEXT[],
    
    -- Vector search
    embedding_id VARCHAR(100), -- ID in Pinecone
    
    is_deleted BOOLEAN DEFAULT FALSE
);

CREATE INDEX idx_docs_uploaded_by ON documents(uploaded_by);
CREATE INDEX idx_docs_related_task ON documents(related_task_gid);
CREATE INDEX idx_docs_type ON documents(file_type);

-- ============================================
-- PHASE 2: APPROVALS (HR)
-- ============================================

CREATE TABLE approvals (
    id SERIAL PRIMARY KEY,
    approval_id VARCHAR(50) UNIQUE NOT NULL,  -- HR-VAC-2025-0001
    type VARCHAR(50) NOT NULL CHECK (type IN (
        'vacation', 'business_trip', 'sick_leave', 
        'document', 'other'
    )),
    requester_id INTEGER REFERENCES users(id) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN (
        'pending', 'approved', 'rejected', 'cancelled'
    )),
    created_at TIMESTAMP DEFAULT NOW(),
    completed_at TIMESTAMP,
    
    -- Approval data (flexible JSONB)
    data JSONB NOT NULL,
    
    -- Related documents
    document_id INTEGER REFERENCES documents(id),
    google_drive_url TEXT
);

CREATE INDEX idx_approvals_requester ON approvals(requester_id);
CREATE INDEX idx_approvals_status ON approvals(status);
CREATE INDEX idx_approvals_type ON approvals(type);
CREATE INDEX idx_approvals_created ON approvals(created_at DESC);

-- Approval workflow steps
CREATE TABLE approval_steps (
    id SERIAL PRIMARY KEY,
    approval_id INTEGER REFERENCES approvals(id) ON DELETE CASCADE NOT NULL,
    step_order INTEGER NOT NULL,
    approver_id INTEGER REFERENCES users(id) NOT NULL,
    approver_role VARCHAR(50),
    status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN (
        'pending', 'approved', 'rejected'
    )),
    decision_at TIMESTAMP,
    comment TEXT,
    
    UNIQUE (approval_id, step_order)
);

CREATE INDEX idx_approval_steps_approval ON approval_steps(approval_id);
CREATE INDEX idx_approval_steps_approver ON approval_steps(approver_id, status);

-- ============================================
-- FEEDBACK & COMPLAINTS
-- ============================================

CREATE TABLE feedback (
    id SERIAL PRIMARY KEY,
    feedback_id VARCHAR(50) UNIQUE NOT NULL,  -- FB-2025-00123
    type VARCHAR(50) NOT NULL CHECK (type IN (
        'idea', 'complaint_manager', 'complaint_colleague',
        'complaint_conditions', 'bot_satisfaction', 'other'
    )),
    from_user_id INTEGER REFERENCES users(id),  -- NULL if anonymous
    is_anonymous BOOLEAN DEFAULT FALSE,
    content TEXT NOT NULL,
    category VARCHAR(100),
    severity VARCHAR(20) CHECK (severity IN ('low', 'medium', 'high', 'critical')),
    status VARCHAR(20) DEFAULT 'submitted' CHECK (status IN (
        'submitted', 'reviewing', 'resolved', 'dismissed'
    )),
    assigned_to_id INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW(),
    resolved_at TIMESTAMP,
    resolution_comment TEXT,
    
    -- For bot satisfaction
    rating INTEGER CHECK (rating >= 1 AND rating <= 5)
);

CREATE INDEX idx_feedback_type ON feedback(type);
CREATE INDEX idx_feedback_status ON feedback(status);
CREATE INDEX idx_feedback_created ON feedback(created_at DESC);
CREATE INDEX idx_feedback_from_user ON feedback(from_user_id) WHERE from_user_id IS NOT NULL;

-- ============================================
-- AUDIT LOGS
-- ============================================

CREATE TABLE action_logs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    action_type VARCHAR(50) NOT NULL,
    action_data JSONB,
    success BOOLEAN DEFAULT TRUE,
    error_message TEXT,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_logs_user_action ON action_logs(user_id, action_type);
CREATE INDEX idx_logs_created ON action_logs(created_at DESC);
CREATE INDEX idx_logs_action_type ON action_logs(action_type);

-- Bot messages (for debugging and analytics)
CREATE TABLE bot_messages (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    message_type VARCHAR(50) CHECK (message_type IN ('incoming', 'outgoing')),
    telegram_message_id BIGINT,
    content_type VARCHAR(20),
    content TEXT,
    intent VARCHAR(50),
    confidence FLOAT,
    response_time_ms INTEGER,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_bot_messages_user ON bot_messages(user_id, created_at DESC);

-- ============================================
-- AI & KNOWLEDGE BASE
-- ============================================

CREATE TABLE knowledge_base (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255),
    content TEXT NOT NULL,
    source_type VARCHAR(50) CHECK (source_type IN (
        'task', 'document', 'manual_entry', 'faq'
    )),
    source_id INTEGER,
    embedding_id VARCHAR(100),  -- Pinecone ID
    metadata JSONB,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    is_active BOOLEAN DEFAULT TRUE
);

CREATE INDEX idx_kb_source ON knowledge_base(source_type, source_id);
CREATE INDEX idx_kb_created ON knowledge_base(created_at DESC);

-- AI prompts versioning
CREATE TABLE ai_prompts (
    id SERIAL PRIMARY KEY,
    prompt_key VARCHAR(100) NOT NULL,
    prompt_text TEXT NOT NULL,
    version INTEGER DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    created_by INTEGER REFERENCES users(id)
);

CREATE INDEX idx_prompts_key ON ai_prompts(prompt_key, is_active);

-- API usage tracking (for budget control)
CREATE TABLE api_usage (
    id SERIAL PRIMARY KEY,
    date DATE NOT NULL,
    model VARCHAR(50) NOT NULL,  -- gpt-4o, whisper, etc
    prompt_tokens INTEGER DEFAULT 0,
    completion_tokens INTEGER DEFAULT 0,
    audio_seconds INTEGER DEFAULT 0,
    cost_usd DECIMAL(10, 4),
    UNIQUE (date, model)
);

CREATE INDEX idx_usage_date ON api_usage(date DESC);

-- ============================================
-- SYSTEM CONFIGURATION
-- ============================================

CREATE TABLE system_settings (
    key VARCHAR(100) PRIMARY KEY,
    value JSONB NOT NULL,
    description TEXT,
    updated_at TIMESTAMP DEFAULT NOW(),
    updated_by INTEGER REFERENCES users(id)
);

CREATE TABLE scheduled_tasks (
    id SERIAL PRIMARY KEY,
    task_type VARCHAR(50) NOT NULL,
    schedule_time TIME NOT NULL,
    target_users INTEGER[],  -- NULL = all users
    is_active BOOLEAN DEFAULT TRUE,
    last_run TIMESTAMP,
    next_run TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- TRIGGERS
-- ============================================

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER users_updated_at 
    BEFORE UPDATE ON users
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER notification_settings_updated_at 
    BEFORE UPDATE ON notification_settings
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER knowledge_base_updated_at 
    BEFORE UPDATE ON knowledge_base
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at();

-- ============================================
-- FULL TEXT SEARCH
-- ============================================

CREATE INDEX idx_tasks_name_fts 
    ON tasks_cache 
    USING gin(to_tsvector('english', name));

CREATE INDEX idx_tasks_desc_fts 
    ON tasks_cache 
    USING gin(to_tsvector('english', coalesce(description, '')));
```

---

## 3. API ИНТЕГРАЦИИ - ПОЛНЫЕ ПРИМЕРЫ

### 3.1 Asana API Complete Flow

```python
import asana
from typing import List, Dict, Optional

class AsanaService:
    def __init__(self, access_token: str):
        self.client = asana.Client.access_token(access_token)
        self.client.options['client_name'] = "AI-Ops Manager"
        self.workspace_gid = settings.ASANA_WORKSPACE_GID
        self.inbox_project_gid = settings.ASANA_INBOX_PROJECT_GID
        self.unprocessed_section_gid = settings.ASANA_UNPROCESSED_SECTION_GID
    
    async def create_task_for_ceo(
        self, 
        task_data: Dict,
        ai_recommendations: Dict
    ) -> Dict:
        """
        Создает задачу от CEO в "Неразобранное"
        """
        task = await self.client.tasks.create({
            "name": task_data["name"],
            "notes": self._format_task_description(
                task_data["description"],
                ai_recommendations
            ),
            "projects": [self.inbox_project_gid],
            "memberships": [{
                "project": self.inbox_project_gid,
                "section": self.unprocessed_section_gid
            }],
            "due_on": task_data.get("due_date"),
            "custom_fields": {
                settings.STATUS_FIELD_GID: "awaiting_assignment",
                settings.PRIORITY_FIELD_GID: task_data.get("priority", "normal"),
                settings.SOURCE_FIELD_GID: "telegram_bot_ceo"
            },
            "followers": [
                settings.CEO_ASANA_GID,
                *task_data.get("follower_gids", [])
            ]
        })
        
        # Add AI analysis as comment
        await self.client.tasks.add_comment(task["gid"], {
            "text": self._format_ai_comment(ai_recommendations)
        })
        
        return task
    
    def _format_task_description(
        self, 
        description: str,
        ai_recommendations: Dict
    ) -> str:
        """Format with AI metadata"""
        return f"""{description}

━━━━━━━━━━━━━━━━━━━━━━
[Создано через AI-Ops Manager]
От: CEO
Метод: Голосовое сообщение
AI Confidence: {ai_recommendations.get('confidence', 0):.0%}

Рекомендации AI:
👤 Исполнитель: {ai_recommendations.get('assignee_name')}
📅 Дедлайн: {ai_recommendations.get('deadline')}
🔴 Приоритет: {ai_recommendations.get('priority')}
"""
    
    async def assign_task(
        self,
        task_gid: str,
        assignee_gid: str,
        due_date: str,
        move_to_project: str,
        move_to_section: str
    ) -> Dict:
        """
        Назначение задачи ассистентом
        """
        # Update task
        task = await self.client.tasks.update(task_gid, {
            "assignee": assignee_gid,
            "due_on": due_date,
            "custom_fields": {
                settings.STATUS_FIELD_GID: "ready_to_start"
            }
        })
        
        # Move to correct project/section
        await self.client.tasks.add_project(task_gid, {
            "project": move_to_project,
            "section": move_to_section
        })
        
        # Remove from inbox
        await self.client.tasks.remove_project(
            task_gid, 
            {"project": self.inbox_project_gid}
        )
        
        # Add comment
        await self.client.tasks.add_comment(task_gid, {
            "text": "✅ Задача назначена через AI-Ops Manager\n"
                   f"Назначил: Екатерина (Ассистент CEO)"
        })
        
        return task
    
    async def update_task_from_report(
        self,
        task_gid: str,
        report_data: Dict
    ):
        """
        Обновление задачи на основе отчета
        """
        updates = {}
        
        # Mark completed if confidence high
        if report_data.get("should_mark_complete") and \
           report_data.get("confidence", 0) > 0.8:
            updates["completed"] = True
        
        # Update progress
        if "progress_percentage" in report_data:
            updates["custom_fields"] = {
                settings.PROGRESS_FIELD_GID: report_data["progress_percentage"]
            }
        
        if updates:
            await self.client.tasks.update(task_gid, updates)
        
        # Add comment with progress
        comment = self._format_report_comment(report_data)
        await self.client.tasks.add_comment(task_gid, {"text": comment})
    
    def _format_report_comment(self, report_data: Dict) -> str:
        """Format report as Asana comment"""
        return f"""📊 Обновление из ежедневного отчета

{report_data.get('description', '')}

Прогресс: {report_data.get('progress_percentage', 'N/A')}%
Отчитался: {report_data.get('employee_name')}
Дата: {report_data.get('report_date')}

[Обновлено через AI-Ops Manager]
"""
    
    async def add_blocker_comment(
        self,
        task_gid: str,
        blocker_data: Dict
    ):
        """Add blocker as comment"""
        severity_emoji = {
            "low": "🟡",
            "medium": "🟠",
            "high": "🔴",
            "critical": "🚨"
        }
        
        emoji = severity_emoji.get(blocker_data["severity"], "⚠️")
        
        comment = f"""{emoji} БЛОКЕР: {blocker_data['description']}

Severity: {blocker_data['severity'].upper()}
Reported by: {blocker_data['employee_name']}
Suggested action: {blocker_data.get('suggested_action', 'N/A')}

[Автоматически зафиксировано AI-Ops Manager]
"""
        
        await self.client.tasks.add_comment(task_gid, {"text": comment})
        
        # Update priority if critical
        if blocker_data["severity"] in ["high", "critical"]:
            await self.client.tasks.update(task_gid, {
                "custom_fields": {
                    settings.PRIORITY_FIELD_GID: "high"
                }
            })
    
    async def sync_tasks_to_db(self):
        """
        Периодическая синхронизация задач в локальную БД
        """
        # Get all projects
        projects = await self.client.projects.find_by_workspace(
            self.workspace_gid
        )
        
        for project in projects:
            tasks = await self.client.tasks.find_by_project(
                project["gid"],
                opt_fields=[
                    "name", "notes", "assignee", "due_on",
                    "completed", "completed_at", "modified_at",
                    "custom_fields", "permalink_url"
                ]
            )
            
            for task in tasks:
                await self._upsert_task_to_db(task)
    
    async def _upsert_task_to_db(self, asana_task: Dict):
        """Update or insert task in local DB"""
        # Find assignee in our DB
        assignee_user = None
        if asana_task.get("assignee"):
            assignee_user = await db.users.find_one({
                "asana_gid": asana_task["assignee"]["gid"]
            })
        
        task_data = {
            "asana_gid": asana_task["gid"],
            "name": asana_task["name"],
            "description": asana_task.get("notes"),
            "assignee_user_id": assignee_user.id if assignee_user else None,
            "assignee_asana_gid": asana_task.get("assignee", {}).get("gid"),
            "due_date": asana_task.get("due_on"),
            "completed": asana_task.get("completed", False),
            "status": self._extract_status(asana_task),
            "priority": self._extract_priority(asana_task),
            "progress": self._extract_progress(asana_task),
            "permalink_url": asana_task.get("permalink_url"),
            "last_sync": datetime.now()
        }
        
        await db.tasks_cache.update_one(
            {"asana_gid": asana_task["gid"]},
            {"$set": task_data},
            upsert=True
        )
```

---

## 4. CELERY TASKS - Полная спецификация

```python
from celery import Celery
from celery.schedules import crontab

celery = Celery('ai_ops_manager')

celery.conf.beat_schedule = {
    # Daily reminders
    'daily-report-reminder': {
        'task': 'app.tasks.reminders.send_daily_report_reminders',
        'schedule': crontab(hour=18, minute=0),  # 18:00 Dubai
    },
    'daily-report-second-reminder': {
        'task': 'app.tasks.reminders.send_second_reminders',
        'schedule': crontab(hour=19, minute=30),
    },
    
    # Daily digest
    'daily-digest-ceo': {
        'task': 'app.tasks.scheduled.generate_ceo_daily_digest',
        'schedule': crontab(hour=9, minute=0),  # 09:00 Dubai
    },
    
    # Sync with Asana
    'sync-asana-tasks': {
        'task': 'app.tasks.sync.sync_asana_tasks',
        'schedule': crontab(minute='*/15'),  # Every 15 minutes
    },
    
    # Proactive checks
    'check-stale-tasks': {
        'task': 'app.tasks.proactive.check_stale_tasks',
        'schedule': crontab(hour='*/2'),  # Every 2 hours
    },
    'check-approaching-deadlines': {
        'task': 'app.tasks.proactive.check_approaching_deadlines',
        'schedule': crontab(hour=10, minute=0),  # 10:00
    },
    
    # Burnout analysis
    'analyze-burnout-risks': {
        'task': 'app.tasks.analytics.analyze_burnout-risks',
        'schedule': crontab(hour=20, minute=0),  # 20:00 (after reports)
    },
    
    # Cleanup
    'cleanup-old-logs': {
        'task': 'app.tasks.maintenance.cleanup_old_logs',
        'schedule': crontab(hour=3, minute=0, day_of_week=1),  # Monday 03:00
    },
}

@celery.task
async def send_daily_report_reminders():
    """Отправка напоминаний об отчетах в 18:00"""
    users = await db.users.find({
        "role": {"$in": ["manager", "employee"]},
        "is_active": True
    }).to_list(None)
    
    for user in users:
        # Check if already reported today
        today = datetime.now().date()
        report = await db.daily_reports.find_one({
            "user_id": user.id,
            "report_date": today
        })
        
        if report:
            continue  # Already reported
        
        # Send reminder
        await bot.send_message(
            user.telegram_id,
            "📊 Привет! Время ежедневного отчета 😊\n\n"
            "Расскажи кратко (текстом или голосовым):\n"
            "✅ Что сделано сегодня?\n"
            "📋 Что в планах на завтра?\n"
            "⚠️ Есть ли проблемы?"
        )

@celery.task
async def generate_ceo_daily_digest():
    """Генерация Daily Digest для CEO в 09:00"""
    yesterday = datetime.now().date() - timedelta(days=1)
    
    # Collect data
    digest_data = {
        "reporting": await get_reporting_stats(yesterday),
        "achievements": await get_top_achievements(yesterday),
        "blockers": await get_active_blockers(),
        "due_today": await get_tasks_due_today(),
        "alerts": await get_alerts()
    }
    
    # Format message
    message = await format_daily_digest(digest_data)
    
    # Send to CEO
    await bot.send_message(settings.CEO_TELEGRAM_ID, message)
```

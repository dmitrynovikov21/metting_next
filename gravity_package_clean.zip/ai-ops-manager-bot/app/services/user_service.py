import logging
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.models import User

logger = logging.getLogger(__name__)

async def get_user_by_telegram_id(session: AsyncSession, telegram_id: int) -> User | None:
    """Get user by Telegram ID"""
    logger.info(f"Service: Getting user by telegram_id: {telegram_id}")
    try:
        result = await session.execute(select(User).where(User.telegram_id == telegram_id))
        user = result.scalars().first()
        logger.info(f"Service: Found user: {user}")
        return user
    except Exception as e:
        logger.error(f"Service: Error getting user: {e}", exc_info=True)
        raise

async def create_user(session: AsyncSession, telegram_id: int, full_name: str, role: str, asana_gid: str = "temp") -> User:
    """Create a new user"""
    user = User(
        telegram_id=telegram_id,
        full_name=full_name,
        role=role,
        asana_gid=asana_gid
    )
    session.add(user)
    await session.commit()
    await session.refresh(user)
    return user

async def get_user_by_name(session: AsyncSession, name_query: str) -> list[User]:
    """Get users by name (fuzzy match)"""
    logger.info(f"Service: Searching users by name: {name_query}")
    try:
        # Simple case-insensitive match for now. 
        # In production, might want more sophisticated fuzzy search.
        stmt = select(User).where(User.full_name.ilike(f"%{name_query}%"))
        result = await session.execute(stmt)
        users = result.scalars().all()
        logger.info(f"Service: Found {len(users)} users for name '{name_query}'")
        return users
    except Exception as e:
        logger.error(f"Service: Error searching users: {e}", exc_info=True)
        return []
    except Exception as e:
        logger.error(f"Service: Error searching user: {e}", exc_info=True)
        return None

async def get_all_users(session: AsyncSession) -> list[User]:
    """Get all users"""
    try:
        result = await session.execute(select(User).order_by(User.id))
        return result.scalars().all()
    except Exception as e:
        logger.error(f"Service: Error getting all users: {e}", exc_info=True)
        return []

async def update_user_status(session: AsyncSession, user_id: int, status: str) -> bool:
    """Update user status"""
    try:
        user = await get_user_by_telegram_id(session, user_id)
        if user:
            user.status = status
            if status == 'banned':
                user.is_active = False
            elif status == 'approved':
                user.is_active = True
            await session.commit()
            return True
        return False
    except Exception as e:
        logger.error(f"Service: Error updating user status: {e}", exc_info=True)
        return False

async def update_user_role(session: AsyncSession, user_id: int, role: str) -> bool:
    """Update user role"""
    try:
        user = await get_user_by_telegram_id(session, user_id)
        if user:
            user.role = role
            await session.commit()
            return True
        return False
    except Exception as e:
        logger.error(f"Service: Error updating user role: {e}", exc_info=True)
        return False

import asana
import os
from app.core.config import settings
import logging
import datetime
from typing import Optional

logger = logging.getLogger(__name__)

class AsanaService:
    def __init__(self):
        configuration = asana.Configuration()
        configuration.access_token = settings.ASANA_ACCESS_TOKEN
        self.api_client = asana.ApiClient(configuration)
        self.users_api = asana.UsersApi(self.api_client)
        self.tasks_api = asana.TasksApi(self.api_client)
        self.attachments_api = asana.AttachmentsApi(self.api_client)
        
        self.workspace_gid = settings.ASANA_WORKSPACE_GID
        self.inbox_project_gid = settings.ASANA_INBOX_PROJECT_GID
        self.unprocessed_section_gid = settings.ASANA_UNPROCESSED_SECTION_GID

    def check_connection(self) -> bool:
        """Check if Asana connection is working"""
        try:
            # v5: get_user("me") returns a dict like {'gid': '...', 'name': '...'}
            me = self.users_api.get_user("me", opts={'opt_fields': 'name'})
            
            name = None
            if isinstance(me, dict):
                name = me.get('name') or me.get('data', {}).get('name')
            elif hasattr(me, 'data'):
                name = me.data.name
            else:
                name = getattr(me, 'name', None)

            if name:
                logger.info(f"Connected to Asana as {name}")
                return True
            return False
        except Exception as e:
            logger.error(f"Asana connection failed: {e}")
            return False

    def get_me_gid(self) -> str:
        """Get the GID of the authenticated user"""
        try:
            me = self.users_api.get_user("me", opts={'opt_fields': 'gid'})
            
            gid = None
            if isinstance(me, dict):
                gid = me.get('gid') or me.get('data', {}).get('gid')
            elif hasattr(me, 'data'):
                gid = me.data.gid
            else:
                gid = getattr(me, 'gid', None)
                
            if not gid:
                raise ValueError(f"Could not extract GID from response: {me}")
                
            return gid
        except Exception as e:
            logger.error(f"Error getting me GID: {e}")
            raise

    def create_task(self, name: str, notes: str = "", assignee_gid: str = None, due_on: str = None, custom_fields: dict = None, projects: list = None, section: str = None) -> dict:
        """Create a task in Asana"""
        try:
            # Default to Inbox project if no projects specified
            target_projects = projects if projects else [self.inbox_project_gid]
            
            body = {
                "data": {
                    "name": name,
                    "notes": notes,
                    "projects": target_projects,
                    "workspace": self.workspace_gid,
                }
            }
            if assignee_gid:
                body["data"]["assignee"] = assignee_gid
            
            if due_on:
                body["data"]["due_on"] = due_on

            if custom_fields:
                body["data"]["custom_fields"] = custom_fields
            
            # If a specific section is provided, use it (overrides unprocessed_section_gid)
            if section:
                 body["data"]["memberships"] = [
                    {
                        "project": target_projects[0],
                        "section": section
                    }
                ]
            # Otherwise, if we are using the default Inbox project, use the unprocessed section
            elif self.unprocessed_section_gid and target_projects == [self.inbox_project_gid]:
                body["data"]["memberships"] = [
                    {
                        "project": self.inbox_project_gid,
                        "section": self.unprocessed_section_gid
                    }
                ]

            result = self.tasks_api.create_task(body, opts={})
            
            # Handle response format (SDK v5 might return object or dict)
            task_data = result
            if hasattr(result, 'to_dict'):
                task_data = result.to_dict()
            elif hasattr(result, 'data'):
                task_data = result.data
            
            # If it's wrapped in 'data' (older API style or raw response)
            if isinstance(task_data, dict) and 'data' in task_data:
                task_data = task_data['data']
                
            logger.info(f"Created Asana task: {task_data.get('gid')}")
            return task_data
        except Exception as e:
            logger.error(f"Error creating Asana task: {e}")
            raise

    def complete_task(self, task_gid: str) -> bool:
        """Mark a task as complete"""
        try:
            body = {
                "data": {
                    "completed": True
                }
            }
            self.tasks_api.update_task(body, task_gid, opts={})
            logger.info(f"Completed task: {task_gid}")
            return True
        except Exception as e:
            logger.error(f"Error completing task {task_gid}: {e}")
            return False

    def add_comment(self, task_gid: str, text: str) -> bool:
        """Add a comment to a task"""
        try:
            body = {
                "data": {
                    "text": text
                }
            }
            self.tasks_api.add_comment_for_task(body, task_gid, opts={})
            logger.info(f"Added comment to task: {task_gid}")
            return True
        except Exception as e:
            logger.error(f"Error adding comment to task {task_gid}: {e}")
            return False

    def get_task_stories(self, task_gid: str) -> list:
        """Get stories (comments) for a task"""
        try:
            opts = {
                'opt_fields': "text,created_at,type",
                'limit': 5
            }
            stories = self.tasks_api.get_stories_for_task(task_gid, opts)
            return list(stories)
        except Exception as e:
            logger.error(f"Error getting stories for task {task_gid}: {e}")
            return []

    def get_user_tasks(self, assignee_gid: str, completed: bool = False) -> list:
        """Get tasks for a specific user"""
        try:
            opts = {
                'assignee': assignee_gid,
                'workspace': self.workspace_gid,
                'completed_since': "now" if not completed else None,
                'opt_fields': "name,notes,due_on,completed,permalink_url",
                'limit': 50
            }
            # v5: get_tasks returns a generator/list wrapped in response
            tasks = self.tasks_api.get_tasks(opts)
            return list(tasks)
        except Exception as e:
            logger.error(f"Error getting user tasks: {e}")
            return []

    def get_project_tasks(self, project_gid: str, completed: bool = False) -> list:
        """Get tasks for a specific project"""
        try:
            opts = {
                'project': project_gid,
                'completed_since': "now" if not completed else None,
                'opt_fields': "name,notes,due_on,completed,permalink_url,assignee.name,custom_fields",
                'limit': 100
            }
            tasks = self.tasks_api.get_tasks(opts)
            return list(tasks)
        except Exception as e:
            logger.error(f"Error getting project tasks: {e}")
            return []

    def get_tasks_by_section(self, section_gid: str, completed: bool = False) -> list:
        """Get tasks for a specific section"""
        try:
            opts = {
                'section': section_gid,
                'completed_since': "now" if not completed else None,
                'opt_fields': "name,notes,due_on,completed,permalink_url,assignee.name,custom_fields",
                'limit': 100
            }
            tasks = self.tasks_api.get_tasks(opts)
            return list(tasks)
        except Exception as e:
            logger.error(f"Error getting section tasks: {e}")
            return []

    def get_team_stats(self, project_gid: str) -> dict:
        """
        Calculates statistics for a project (e.g. Departments).
        Returns: { "assignee_name": {"total": int, "overdue": int} }
        """
        stats = {}
        try:
            tasks = self.tasks_api.get_tasks(
                {'project': project_gid, 'opt_fields': 'name,completed,due_on,assignee.name'}
            )
            
            today = datetime.date.today().isoformat()
            
            for task in tasks:
                if task.get('completed'):
                    continue
                    
                assignee = task.get('assignee')
                name = assignee.get('name', 'Unassigned') if assignee else 'Unassigned'
                
                if name not in stats:
                    stats[name] = {"total": 0, "overdue": 0}
                
                stats[name]["total"] += 1
                
                due_on = task.get('due_on')
                if due_on and due_on < today:
                    stats[name]["overdue"] += 1
                    
            return stats
        except Exception as e:
            logger.error(f"Error getting team stats: {e}")
            return {}

    def find_task_by_name(self, project_gid: str, name: str) -> Optional[dict]:
        """Find a task in a project by exact name match"""
        try:
            tasks = self.tasks_api.get_tasks(
                {'project': project_gid, 'opt_fields': 'name,gid'}
            )
            for task in tasks:
                if task['name'].strip() == name.strip():
                    return task
            return None
        except Exception as e:
            logger.error(f"Error finding task: {e}")
            return None

    def create_registry_task(self, project_gid: str, name: str, description: str, attachment_path: str = None) -> dict:
        """
        Creates or updates a task in the Registry Project.
        If task exists, updates description and adds comment.
        If attachment_path provided, uploads file.
        """
        try:
            # 1. Check if task exists
            existing_task = self.find_task_by_name(project_gid, name)
            
            if existing_task:
                task_gid = existing_task['gid']
                # Update description
                self.tasks_api.update_task({'data': {'notes': description}}, task_gid, opts={})
                logger.info(f"Updated existing registry task: {task_gid}")
            else:
                # Create new task
                result = self.tasks_api.create_task({'data': {
                    'name': name,
                    'notes': description,
                    'projects': [project_gid]
                }}, opts={})
                # Handle response wrapper
                new_task = result if isinstance(result, dict) else result.data
                if hasattr(new_task, 'to_dict'):
                     new_task = new_task.to_dict()
                
                task_gid = new_task['gid']
                logger.info(f"Created new registry task: {task_gid}")
            
            #  2. Upload Attachment
            # TODO: Fix attachment upload - the Asana SDK v5 signature is unclear
            # For now, skip attachment to get core functionality working
            if attachment_path and os.path.exists(attachment_path):
                logger.warning(f"Attachment upload temporarily disabled for: {attachment_path}")
                # with open(attachment_path, 'rb') as file_handle:
                #     self.attachments_api.create_attachment_for_object(
                #         task_gid,
                #         {},
                #         file=file_handle,
                #         file_name=os.path.basename(attachment_path)
                #     )
                # logger.info(f"Uploaded attachment to task: {task_gid}")
                
            return {"gid": task_gid, "name": name}
            
        except Exception as e:
            logger.error(f"Error creating registry task: {e}")
            raise e

asana_service = AsanaService()

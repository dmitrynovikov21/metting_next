import logging
from anthropic import AsyncAnthropic
from app.core.config import settings

logger = logging.getLogger(__name__)

class AnthropicService:
    def __init__(self):
        self.client = AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)
        self.model = "claude-3-5-sonnet-20240620"

    async def generate_protocol(self, transcript: str, example_format: str) -> str:
        """
        Generates a meeting protocol based on the transcript and an example format.
        """
        logger.info("Generating protocol with Claude...")
        
        system_prompt = f"""
        You are an expert Meeting Secretary. Your task is to create a professional meeting protocol based on the provided transcript.
        
        You MUST follow the style, structure, and tone of the EXAMPLE PROTOCOL provided below.
        
        EXAMPLE PROTOCOL START:
        {example_format}
        EXAMPLE PROTOCOL END
        
        Instructions:
        1. Analyze the transcript to extract key topics, decisions, and action items.
        2. Format the output EXACTLY like the example.
        3. Use Russian language (unless the example is in English).
        4. Be concise but comprehensive.
        """
        
        try:
            message = await self.client.messages.create(
                model=self.model,
                max_tokens=4000,
                temperature=0,
                system=system_prompt,
                messages=[
                    {"role": "user", "content": f"Here is the meeting transcript:\n\n{transcript}"}
                ]
            )
            return message.content[0].text
        except Exception as e:
            logger.error(f"Error generating protocol with Claude: {e}")
            raise

anthropic_service = AnthropicService()

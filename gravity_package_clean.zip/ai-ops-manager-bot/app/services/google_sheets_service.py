import logging
from googleapiclient.discovery import build
from app.services.google_calendar_service import google_calendar_service

logger = logging.getLogger(__name__)

class GoogleSheetsService:
    def __init__(self):
        self.service = None

    def get_service(self):
        if not self.service:
            if google_calendar_service.creds:
                self.service = build('sheets', 'v4', credentials=google_calendar_service.creds)
            else:
                logger.warning("Google Sheets Service: No credentials available")
        return self.service

    def append_row(self, spreadsheet_id: str, row_data: list):
        """
        Appends a row to the spreadsheet.
        row_data: List of values (strings, numbers)
        """
        service = self.get_service()
        if not service:
            return None

        try:
            body = {
                'values': [row_data]
            }
            result = service.spreadsheets().values().append(
                spreadsheetId=spreadsheet_id,
                range="A1", # Append to the first sheet
                valueInputOption="USER_ENTERED",
                body=body
            ).execute()
            
            logger.info(f"{result.get('updates').get('updatedCells')} cells appended to Sheets")
            return True
            
        except Exception as e:
            logger.error(f"Error appending to Sheets: {e}")
            return False

    def insert_row_at_top(self, spreadsheet_id: str, row_data: list, sheet_id: int = 0):
        """
        Inserts a row at the top of the sheet (index 1, below header).
        row_data: List of values
        sheet_id: ID of the specific sheet (tab), usually 0 for the first one.
        """
        service = self.get_service()
        if not service:
            return None

        try:
            # 1. Insert blank row at index 1
            requests = [
                {
                    "insertDimension": {
                        "range": {
                            "sheetId": sheet_id,
                            "dimension": "ROWS",
                            "startIndex": 1,
                            "endIndex": 2
                        },
                        "inheritFromBefore": False
                    }
                }
            ]
            
            service.spreadsheets().batchUpdate(
                spreadsheetId=spreadsheet_id,
                body={"requests": requests}
            ).execute()
            
            # 2. Update the new row with data
            body = {
                'values': [row_data]
            }
            service.spreadsheets().values().update(
                spreadsheetId=spreadsheet_id,
                range="A2", # Update the newly created row (assuming header is A1)
                valueInputOption="USER_ENTERED",
                body=body
            ).execute()
            
            logger.info("Row inserted at top of Sheets")
            return True
            
        except Exception as e:
            logger.error(f"Error inserting row to Sheets: {e}")
            return False

    def log_meeting(self, spreadsheet_id: str, data: dict):
        """
        Logs a meeting to the registry with the Professional Schema v2 (12 columns).
        data: Dictionary containing keys matching the headers.
        """
        service = self.get_service()
        if not service:
            return False

        try:
            # Map dictionary to row list based on schema v2
            # Headers: ["Дата", "Название (тема)", "Участники", "Протокол (Doc)", "Запись (Drive)", 
            #           "Транскрибация", "Саммари", "Решения", "Задачи (Asana)", "Статус", 
            #           "Следующие шаги", "Ответственный"]
            row = [
                data.get('date', ''),
                data.get('topic', ''),
                data.get('attendees', ''),
                data.get('protocol_link', ''),
                data.get('recording_link', ''),
                data.get('transcript_link', ''),
                data.get('summary', ''),
                data.get('decisions', ''),
                data.get('tasks_count', ''), # Or link if we have it
                data.get('status', 'Done'),
                data.get('next_steps', ''),
                data.get('owner', 'AI Bot')
            ]

            # Insert at top (Row 2, pushing others down)
            return self.insert_row_at_top(spreadsheet_id, row)

        except Exception as e:
            logger.error(f"Error logging meeting to Sheets: {e}")
            return False

    def update_protocol_link(self, spreadsheet_id: str, topic: str, link: str):
        """
        Finds a row by Topic (Column D) and updates the Protocol Link (Column L).
        Scans top 50 rows.
        """
        service = self.get_service()
        if not service:
            return False

        try:
            # 1. Read top 50 rows (Topic is Col D -> Index 3)
            result = service.spreadsheets().values().get(
                spreadsheetId=spreadsheet_id,
                range="A2:D51" # Read Date...Topic
            ).execute()
            rows = result.get('values', [])
            
            row_index = -1
            for i, row in enumerate(rows):
                # Row index in sheet = i + 2 (Header is 1, data starts at 2)
                if len(row) > 3 and row[3] == topic:
                    row_index = i + 2 
                    break
            
            if row_index != -1:
                # 2. Update Column L (Protocol Link)
                range_name = f"L{row_index}"
                body = {
                    'values': [[link]]
                }
                service.spreadsheets().values().update(
                    spreadsheetId=spreadsheet_id,
                    range=range_name,
                    valueInputOption="USER_ENTERED",
                    body=body
                ).execute()
                logger.info(f"Updated Protocol Link for topic '{topic}' at row {row_index}")
                return True
            else:
                logger.warning(f"Topic '{topic}' not found in top 50 rows")
                return False
                
        except Exception as e:
            logger.error(f"Error updating Protocol Link in Sheets: {e}")
            return False

google_sheets_service = GoogleSheetsService()

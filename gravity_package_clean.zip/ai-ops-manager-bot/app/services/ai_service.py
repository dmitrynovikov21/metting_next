import json
import logging
from openai import AsyncOpenAI
from app.core.config import settings

logger = logging.getLogger(__name__)

class AIService:
    def __init__(self):
        self.client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
        self.model = "gpt-4o" # Or gpt-4-turbo

    async def classify_intent(self, text: str) -> dict:
        """
        Classifies the user's intent based on the message text.
        Returns JSON: { "intent": "TASK_CREATION" | "REPORT" | "KNOWLEDGE_BASE" | "FINANCE" | "HR" | "OTHER", "confidence": float }
        """
        # Legacy method, keeping for backward compatibility if needed, 
        # but analyze_conversation is preferred.
        return await self.analyze_conversation(text, [])

    async def analyze_conversation(self, text: str, history: list) -> dict:
        """
        Analyzes the conversation context to determine intent and extract entities.
        History format: [{"role": "user", "content": "..."}, {"role": "assistant", "content": "..."}]
        """
        system_prompt = """
        You are an AI Operations Manager for a corporate OS. Your goal is to understand the user's intent, CONSIDERING THE CONVERSATION HISTORY.
        
        You must classify the intent into one of these categories:
        1. TASK_CREATION: User wants to create a task, assign work, or remind someone.
           - Example: "Create a task to update the website"
           - Contextual Example: User: "We need to fix the bug." Bot: "Ok." User: "Do it now." -> TASK_CREATION (fix the bug)
        2. REPORT: User is submitting a daily report or status update.
        3. KNOWLEDGE_BASE: User is asking a question about company rules, documents, how-to, or internal procedures.
           - INCLUDES: "How to go on vacation?", "Where is the contract template?", "Sick leave policy".
           - NOTE: Even if it relates to HR topics (like vacation), if it's a "how-to" question, it is KNOWLEDGE_BASE.
        4. FINANCE: Questions about money, invoices, P&L.
        5. HR: Questions SPECIFICALLY about RECRUITING, CANDIDATES, or HIRING.
           - EXCLUDES: Vacation, Sick Leave, Salaries (use KNOWLEDGE_BASE or FINANCE).
        6. OTHER: General chit-chat, greetings, thanks, or if the user is just replying to a bot's question.
           - Example: "Hello", "Thanks", "Ok", "Good morning".

        Output JSON ONLY:
        {
            "intent": "CATEGORY",
            "confidence": 0.0-1.0,
            "reasoning": "Brief explanation of why this intent was chosen based on history",
            "suggested_reply": "Required if intent is OTHER. Generate a friendly, natural response in Russian."
        }
        """
        
        messages = [{"role": "system", "content": system_prompt}]
        
        # Add history (limit to last 5-10 to save tokens if needed, but ContextManager handles this)
        for msg in history:
            messages.append({"role": msg["role"], "content": msg["content"]})
            
        messages.append({"role": "user", "content": text})
        
        try:
            response = await self.client.chat.completions.create(
                model="gpt-4o",
                messages=messages,
                response_format={"type": "json_object"},
                temperature=0.1
            )
            content = response.choices[0].message.content
            return json.loads(content)
        except Exception as e:
            logger.error(f"Conversation analysis failed: {e}")
            return {"intent": "OTHER", "confidence": 0.0, "reasoning": "Error"}

    async def analyze_task_request(self, text: str, user_context: dict = None) -> dict:
        """
        Analyzes natural language text and extracts task details.
        Returns a JSON dict with: name, notes, due_date, assignee_name (optional)
        """
        system_prompt = """
        You are an AI Operations Manager. Your goal is to extract structured task information from natural language requests.
        
        IMPORTANT: Always output the 'name' and 'notes' in RUSSIAN language, regardless of the input language.
        
        Output JSON ONLY with the following keys:
        - name: A concise, action-oriented task name in Russian.
        - notes: A detailed description of the task in Russian.
        - due_date: The due date in YYYY-MM-DD format if mentioned (today is {current_date}).
        - assignee_guess: If a person is mentioned to do the task, extract their name.
        - project_enum: Choose the most relevant project from this list: ["Общая группа", "Бухгалтерия/кадры внутри", "Бухгалтерия Аутсорс", "Консалтинг", "Бизнес-центр", "Клиринг", "Закупки и логистика", "Акселератор", "Платформа"]. Default to "Общая группа".
        
        If the request is unclear, set "name" to the raw text (translated to Russian if needed) and "notes" to empty.
        """
        
        # TODO: Inject current date
        import datetime
        current_date = datetime.date.today().isoformat()
        formatted_system_prompt = system_prompt.replace("{current_date}", current_date)

        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": formatted_system_prompt},
                    {"role": "user", "content": text}
                ],
                response_format={"type": "json_object"},
                temperature=0.3
            )
            
            content = response.choices[0].message.content
            return json.loads(content)
            
        except Exception as e:
            logger.error(f"AI Analysis failed: {e}")
            # Fallback: use text as name
            return {"name": text, "notes": "", "due_date": None}

    async def analyze_report(self, text: str, active_tasks: list = None) -> dict:
        """
        Analyzes a daily report text and extracts structured data.
        If active_tasks provided, tries to match completed items to task GIDs.
        Returns JSON with: completed_tasks, plans, blockers, sentiment, completed_task_gids.
        """
        tasks_context = ""
        if active_tasks:
            tasks_list = "\n".join([f"- [{t['gid']}] {t['name']}" for t in active_tasks])
            tasks_context = f"\n\nUser's Active Tasks in Asana:\n{tasks_list}\n\nIf the user mentions working on any of these tasks, include them in 'task_updates' with a specific description of what was done."

        system_prompt = f"""
        You are an AI Operations Manager. Your goal is to analyze a daily report from an employee.
        
        Extract the following structured information in JSON format:
        - completed_tasks: List of strings (what was done).
        - plans: List of strings (what is planned for tomorrow).
        - blockers: List of strings (problems, issues, blockers).
        - sentiment: "Positive", "Neutral", or "Negative" based on the tone.
        - task_updates: List of objects {{ 
            "gid": "task_gid", 
            "update_text": "what was done (INCLUDE ALL LINKS/URLs provided by user)", 
            "status": "completed" or "in_progress",
            "quality": "good" or "vague" (if text is too short like "in progress", "working on it"),
            "needs_proof": "video" (if development task completed) or "document" (if other task completed/in_progress but vague) or null
          }}. Only for tasks from the provided list.
        - new_tasks: List of strings (items from 'completed_tasks' that do NOT match any active task provided in the list).
        
        {tasks_context}
        
        Output strictly JSON.
        """
        
        try:
            response = await self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": text}
                ],
                response_format={"type": "json_object"}
            )
            
            content = response.choices[0].message.content
            return json.loads(content)
            
        except Exception as e:
            logger.error(f"Error analyzing report: {e}")
            return {}

    async def generate_digest(self, reports: list) -> str:
        """
        Generates a daily digest from a list of report objects/dicts.
        Each report should have: user_name, text (or completed_tasks/blockers).
        Returns a markdown string.
        """
        if not reports:
            return "Нет отчетов за этот период."

        reports_text = ""
        for r in reports:
            # Handle both dicts and SQLAlchemy objects
            name = r.get('user_name', 'Unknown') if isinstance(r, dict) else r.user.full_name
            text = r.get('raw_text', '') if isinstance(r, dict) else r.raw_text
            reports_text += f"User: {name}\nReport: {text}\n---\n"

        system_prompt = """
        You are an AI Operations Manager. Your goal is to create a Daily Digest for the CEO based on employee reports.
        
        Output a clean, professional Markdown summary in Russian.
        Structure:
        
        # 📅 Сводка за [Date]
        
        ## 🏆 Главные достижения
        (Highlight the most important completed tasks across all departments. Group by department if obvious.)
        
        ## 🚩 Проблемы и Блокеры
        (List any blockers or issues mentioned. If none, say "Блокеров нет".)
        
        ## 📊 Настроение команды
        (Briefly summarize the overall sentiment.)
        
        ## 📝 Детали по сотрудникам
        (Bullet points for each person: Name - Key 1-2 things done).
        
        Keep it concise but informative.
        """

        try:
            response = await self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": reports_text}
                ]
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"Error generating digest: {e}")
            return "Ошибка генерации сводки."

    async def generate_morning_brief(self, user_name: str, tasks: list, meetings: list, team_reports: list) -> str:
        """
        Generates a personalized morning briefing.
        """
        import datetime
        today = datetime.date.today().strftime("%d.%m.%Y")
        
        # Format inputs
        tasks_text = "\n".join([f"- {t['name']} (Due: {t.get('due_on', 'Today')})" for t in tasks]) if tasks else "Нет задач на сегодня."
        
        meetings_text = ""
        if meetings:
            for m in meetings:
                start = m.get('start', '').split('T')[1][:5] if 'T' in m.get('start', '') else m.get('start', '')
                meetings_text += f"- {start} {m.get('summary', 'Meeting')}\n"
        else:
            meetings_text = "Нет встреч на сегодня."

        reports_text = ""
        if team_reports:
            for r in team_reports:
                name = r.user.full_name
                # Simple extraction of blockers or key updates if available, otherwise raw text
                # For brevity, we pass raw text and let AI summarize
                reports_text += f"User: {name}\nReport: {r.raw_text}\n---\n"
        else:
            reports_text = "Нет отчетов за вчера."

        system_prompt = f"""
        You are an AI Executive Assistant. Your goal is to prepare a "Morning Brief" for {user_name}.
        
        Date: {today}
        
        Input Data:
        1. User's Tasks (Due Today/Overdue)
        2. User's Meetings (Today)
        3. Team Reports (Yesterday)
        
        Output a concise, motivating Markdown message in Russian.
        Structure:
        
        ☀️ **Доброе утро, {user_name}!**
        
        📋 **Твои задачи на сегодня:**
        (List top 3-5 most important tasks. Mark overdue with ⚠️)
        
        📅 **Встречи сегодня:**
        (List meetings chronologically with times)
        
        👥 **Новости команды:**
        (Briefly highlight 1-2 key achievements from yesterday and ANY blockers/problems that need attention. If everything is fine, say "Команда работает штатно".)
        
        🚀 **Фокус дня:**
        (Suggest a focus based on tasks/meetings, e.g. "Сегодня день встреч" or "Нужно закрыть долги")
        
        Keep it short (max 20 lines). Use emojis.
        """
        
        user_content = f"""
        TASKS:
        {tasks_text}
        
        MEETINGS:
        {meetings_text}
        
        TEAM REPORTS (Yesterday):
        {reports_text}
        """

        try:
            response = await self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_content}
                ]
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"Error generating morning brief: {e}")
            return f"Доброе утро! Ошибка генерации брифинга: {e}"

    async def analyze_meeting(self, transcript: str) -> dict:
        """
        Analyzes a meeting transcript and extracts structured information.
        Returns: {summary, topics, decisions, action_items}
        action_items: [{task, assignee, deadline}]
        """
        system_prompt = """
        You are an elite Executive Assistant and Meeting Analyst. Your goal is to produce a HIGHLY DETAILED, COMPREHENSIVE protocol of this meeting in Russian.
        
        Do NOT summarize briefly. The user wants MAXIMUM DETAIL and VALUE.
        
        Extract structured information in JSON format:
        {
            "title": "A short, professional, semantic title (e.g. 'Стратегия Q4', 'Обсуждение дизайна').",
            "summary": "A comprehensive executive summary (3-4 paragraphs) covering the context, main debates, and outcomes.",
            "topics": ["Topic 1", "Topic 2", ...],
            "decisions": ["Decision 1", "Decision 2", ...],
            "action_items": [
                {
                    "task": "Detailed description of the task",
                    "assignee": "Name (or 'Не указан')",
                    "deadline": "DD.MM.YYYY (or null)",
                    "priority": "high" | "medium" | "low"
                }
            ],
            "protocol": [
                {
                    "speaker": "Name of the speaker",
                    "text": "A detailed, almost verbatim account of their contribution. Capture their arguments, data points, and specific phrasing. Do not just say 'discussed X', say 'Argued that X because Y and Z'.",
                    "sentiment": "positive" | "neutral" | "negative" | "constructive"
                }
            ]
        }
        
        CRITICAL INSTRUCTIONS:
        1. **Detail Level**: The 'protocol' section must be extensive. Group consecutive thoughts by the same speaker, but keep the detail.
        2. **Attribution**: Be very careful to attribute correctly.
        3. **Context**: In the summary, explain WHY this meeting happened if clear from context.
        4. **Action Items**: Extract every single commitment, no matter how small.
        
        Output strictly JSON in Russian.
        """

        try:
            response = await self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"Meeting transcript:\n\n{transcript}"}
                ],
                response_format={"type": "json_object"}
            )
            content = response.choices[0].message.content
            return json.loads(content)
        except Exception as e:
            logger.error(f"Error analyzing meeting: {e}")
            return {
                "summary": "Ошибка анализа встречи",
                "topics": [],
                "decisions": [],
                "action_items": []
            }
    
    async def transcribe_audio(self, file_path: str) -> str:
        """Transcribes audio file using OpenAI Whisper"""
        try:
            with open(file_path, "rb") as audio_file:
                transcript = await self.client.audio.transcriptions.create(
                    model="whisper-1", 
                    file=audio_file
                )
            return transcript.text
        except Exception as e:
            logger.error(f"Transcription failed: {e}")
            raise

    async def extract_meeting_details(self, text: str) -> dict:
        """
        Extracts meeting details from natural language text.
        Returns JSON: { "summary": "...", "start_time": "ISO", "duration": int, "attendees": ["name"], "is_online": bool/null }
        """
        import datetime
        current_time = datetime.datetime.now().isoformat()
        
        system_prompt = f"""
        You are an AI Assistant. Extract meeting details from the user's request.
        Current time: {current_time}
        
        Output JSON:
        - summary: Short meeting title/topic (in Russian).
        - start_time: ISO 8601 datetime (YYYY-MM-DDTHH:MM:SS). Infer date/time relative to current time. RETURN NULL IF NOT EXPLICITLY MENTIONED.
        - duration: Duration in minutes (default 60 if not specified).
        - attendees: List of names mentioned (excluding the user).
        - is_online: true if online/zoom mentioned, false if offline/office mentioned, null if unknown.
        
        If information is missing, make a best guess or leave null. Specifically for start_time, if the user didn't specify when, return null.
        """
        
        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": text}
                ],
                response_format={"type": "json_object"},
                temperature=0.1
            )
            content = response.choices[0].message.content
            return json.loads(content)
        except Exception as e:
            logger.error(f"Error extracting meeting details: {e}")
            return {}

ai_service = AIService()

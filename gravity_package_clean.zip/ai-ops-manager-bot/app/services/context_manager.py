import json
import logging
from typing import List, Dict, Optional
import redis.asyncio as redis
from app.core.config import settings

logger = logging.getLogger(__name__)

class ContextManager:
    def __init__(self):
        self.redis = redis.from_url(settings.REDIS_URL, decode_responses=True)
        self.history_limit = 10  # Keep last 10 interactions
        self.buffer_ttl = 3600   # Buffer expires in 1 hour if not processed

    async def add_to_buffer(self, user_id: int, text: str):
        """Add a user message to the temporary buffer."""
        key = f"buffer:{user_id}"
        await self.redis.rpush(key, text)
        await self.redis.expire(key, self.buffer_ttl)

    async def get_and_clear_buffer(self, user_id: int) -> str:
        """Retrieve all messages from buffer and clear it."""
        key = f"buffer:{user_id}"
        messages = await self.redis.lrange(key, 0, -1)
        if messages:
            await self.redis.delete(key)
            return "\n".join(messages)
        return ""

    async def add_to_history(self, user_id: int, role: str, content: str):
        """Add a message to the conversation history."""
        key = f"history:{user_id}"
        message = json.dumps({"role": role, "content": content})
        await self.redis.rpush(key, message)
        # Trim history to keep only the last N items
        await self.redis.ltrim(key, -self.history_limit, -1)
        # Set expiry for history (e.g., 24 hours)
        await self.redis.expire(key, 86400)

    async def get_history(self, user_id: int) -> List[Dict[str, str]]:
        """Retrieve conversation history."""
        key = f"history:{user_id}"
        raw_history = await self.redis.lrange(key, 0, -1)
        return [json.loads(msg) for msg in raw_history]

    async def clear_history(self, user_id: int):
        """Clear conversation history."""
        key = f"history:{user_id}"
        await self.redis.delete(key)

context_manager = ContextManager()

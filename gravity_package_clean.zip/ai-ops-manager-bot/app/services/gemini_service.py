import logging
import google.generativeai as genai
from app.core.config import settings

logger = logging.getLogger(__name__)

class GeminiService:
    def __init__(self):
        if settings.GEMINI_API_KEY:
            genai.configure(api_key=settings.GEMINI_API_KEY)
            self.model = genai.GenerativeModel('gemini-flash-latest')
        else:
            logger.warning("Gemini API Key not found")
            self.model = None

    async def generate_protocol(self, transcript: str, example_format: str) -> str:
        """
        Generates a meeting protocol based on the transcript and the strict v2 template.
        """
        if not self.model:
            raise ValueError("Gemini API is not configured")

        logger.info("Generating protocol with Gemini...")
        
        prompt = f"""
        You are an expert Meeting Secretary. Your task is to create a professional meeting protocol based on the provided transcript.
        
        You MUST follow this STRICT TEMPLATE structure:

        # 🔹 1. Название встречи
        **Дата:** [Date]
        **Время:** [Time]
        **Цель:** [Goal of the meeting]

        # 🔹 2. Участники
        | Имя | Роль | Присутствовал / нет |
        | --- | --- | --- |
        [List participants]

        # 🔹 3. Повестка встречи
        [List of agenda items]

        # 🔹 4. Транскрибация (AI)
        [Link to transcript if available, or "См. приложение"]

        # 🔹 5. Ключевые инсайты / Саммари
        [One paragraph summary. If a person reads only this, they understand the meeting.]

        # 🔹 6. Принятые решения
        | Решение | Причина | Срок | Кто отвечает |
        | --- | --- | --- | --- |
        [List decisions]

        # 🔹 7. Задачи (будут перенесены в Asana)
        | Задача | Ответственный | Дедлайн | Тип задачи | Статус |
        | --- | --- | --- | --- | --- |
        [List tasks]

        # 🔹 8. Риски / Препятствия
        [List risks or obstacles]

        # 🔹 9. Next Steps (дата следующей точки)
        [Next steps and date]

        TRANSCRIPT START:
        {transcript[:50000]} 
        TRANSCRIPT END
        
        Instructions:
        1. Analyze the transcript to extract key topics, decisions, and action items.
        2. Format the output EXACTLY as shown above using Markdown.
        3. Use Russian language.
        4. Be concise but comprehensive.
        """
        
        try:
            response = await self.model.generate_content_async(prompt)
            return response.text
        except Exception as e:
            logger.error(f"Error generating protocol with Gemini: {e}")
            raise

    async def transcribe_video(self, video_url: str) -> str:
        """
        Downloads video from URL, uploads to Gemini, and generates transcript.
        """
        if not self.model:
            raise ValueError("Gemini API is not configured")
            
        import httpx
        import os
        import asyncio
        import time
        
        temp_filename = "temp_video.mp4"
        
        try:
            # 1. Download Video
            logger.info(f"Downloading video from {video_url}...")
            async with httpx.AsyncClient() as client:
                response = await client.get(video_url, follow_redirects=True, timeout=300.0)
                if response.status_code != 200:
                    raise Exception(f"Failed to download video: {response.status_code}")
                
                with open(temp_filename, "wb") as f:
                    f.write(response.content)
            
            # 2. Upload to Gemini
            logger.info("Uploading video to Gemini...")
            video_file = genai.upload_file(path=temp_filename)
            logger.info(f"Uploaded file: {video_file.name}")
            
            # 3. Wait for processing
            while video_file.state.name == "PROCESSING":
                logger.info("Waiting for video processing...")
                await asyncio.sleep(5)
                video_file = genai.get_file(video_file.name)
                
            if video_file.state.name == "FAILED":
                raise Exception("Video processing failed in Gemini")
                
            # 4. Generate Transcript
            logger.info("Generating transcript...")
            prompt = "Transcribe this meeting in detail. Identify speakers if possible. Output ONLY the transcript text."
            
            response = await self.model.generate_content_async([video_file, prompt])
            
            # Cleanup
            try:
                os.remove(temp_filename)
                # genai.delete_file(video_file.name) # Optional: delete from cloud
            except:
                pass
                
            return response.text
            
        except Exception as e:
            logger.error(f"Error transcribing video with Gemini: {e}")
            if os.path.exists(temp_filename):
                os.remove(temp_filename)
            raise
            
    async def extract_meeting_metadata(self, transcript_text: str) -> dict:
        """
        Analyzes transcript to extract structured metadata for the Registry v2.
        Returns JSON: {summary, decisions, next_steps, tasks_count}
        """
        if not self.model:
             return {
                "summary": "Gemini not configured",
                "decisions": "None",
                "next_steps": "None",
                "tasks_count": 0
            }

        prompt = """
        Analyze the following meeting transcript and extract structured metadata for a business registry.
        Return ONLY a valid JSON object with the following keys:
        - summary: A concise 1-paragraph summary (max 300 chars).
        - decisions: A string list of key decisions (e.g. "1. Approved budget. 2. Hired dev.").
        - next_steps: A string describing the immediate next steps.
        - tasks_count: The integer number of distinct action items found.

        Transcript:
        {transcript}
        """
        
        try:
            # Use a cheaper/faster model if possible, but flash is good.
            response = await self.model.generate_content_async(prompt.format(transcript=transcript_text[:30000])) # Limit context
            
            # Clean response to ensure valid JSON
            text = response.text.strip()
            if text.startswith("```json"):
                text = text[7:]
            if text.endswith("```"):
                text = text[:-3]
            
            import json
            return json.loads(text.strip())
            
        except Exception as e:
            logger.error(f"Error extracting metadata with Gemini: {e}")
            return {
                "summary": "Error analyzing meeting",
                "decisions": "Unknown",
                "next_steps": "Unknown",
                "tasks_count": 0
            }
gemini_service = GeminiService()

import logging
import httpx
import asyncio
from app.core.config import settings

logger = logging.getLogger(__name__)

class SonixService:
    BASE_URL = "https://api.sonix.ai/v1"

    def __init__(self):
        self.api_key = settings.SONIX_API_KEY
        if not self.api_key:
            logger.warning("Sonix API Key not found")

    async def transcribe_video(self, video_url: str, language: str = 'ru') -> str:
        """
        Orchestrates the transcription process:
        1. Submit media URL
        2. Poll for completion
        3. Fetch transcript
        """
        if not self.api_key:
            raise ValueError("Sonix API Key is not configured")

        try:
            # 1. Submit Media
            media_id = await self.submit_media(video_url, language)
            if not media_id:
                raise Exception("Failed to submit media to Sonix")

            # 2. Poll for Completion
            status = "preparing"
            while status in ["preparing", "transcribing"]:
                await asyncio.sleep(10) # Wait 10s between checks
                status = await self.check_status(media_id)
                logger.info(f"Sonix Media {media_id} status: {status}")
                
                if status == "failed":
                    raise Exception("Sonix transcription failed")

            # 3. Get Transcript
            transcript = await self.get_transcript(media_id)
            return transcript

        except Exception as e:
            logger.error(f"Error in Sonix transcription flow: {e}")
            raise

    async def submit_media(self, video_url: str, language: str) -> str:
        """Submits a video URL for transcription. Returns media_id."""
        url = f"{self.BASE_URL}/media"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        data = {
            "file_url": video_url,
            "language": language
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.post(url, headers=headers, data=data)
            
            if response.status_code == 200:
                return response.json().get('id')
            else:
                logger.error(f"Sonix Submit Error: {response.text}")
                return None

    async def check_status(self, media_id: str) -> str:
        """Checks the status of the media file."""
        url = f"{self.BASE_URL}/media/{media_id}"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        
        async with httpx.AsyncClient() as client:
            response = await client.get(url, headers=headers)
            
            if response.status_code == 200:
                return response.json().get('status')
            else:
                logger.error(f"Sonix Status Error: {response.text}")
                return "unknown"

    async def get_transcript(self, media_id: str) -> str:
        """Fetches the full transcript as text."""
        url = f"{self.BASE_URL}/media/{media_id}/transcript"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        params = {"format": "text"}
        
        async with httpx.AsyncClient() as client:
            response = await client.get(url, headers=headers, params=params)
            
            if response.status_code == 200:
                return response.text
            else:
                logger.error(f"Sonix Transcript Error: {response.text}")
                raise Exception(f"Failed to get transcript: {response.status_code}")

sonix_service = SonixService()

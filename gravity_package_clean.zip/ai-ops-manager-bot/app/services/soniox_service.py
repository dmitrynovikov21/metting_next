import logging
import httpx
import asyncio
import os
from typing import Optional, Dict, Any
from app.core.config import settings

logger = logging.getLogger(__name__)

class SonioxService:
    BASE_URL = "https://api.soniox.com/v1"

    def __init__(self):
        self.api_key = settings.SONIOX_API_KEY
        if not self.api_key:
            logger.warning("Soniox API Key not found")

    async def transcribe_file(self, file_path: str, language: str = 'en') -> Dict[str, Any]:
        """
        Orchestrates the full transcription flow for a local file.
        Uses async upload + poll flow.
        """
        if not self.api_key:
            raise ValueError("Soniox API Key is not configured")

        try:
            # 1. Upload File
            file_id = await self.upload_file(file_path)
            logger.info(f"File uploaded to Soniox. File ID: {file_id}")

            # 2. Start Transcription
            transcription_id = await self.start_transcription(file_id, language)
            logger.info(f"Transcription started. ID: {transcription_id}")

            # 3. Poll for Completion (with timeout)
            status = "queued"
            start_time = asyncio.get_event_loop().time()
            max_wait_time = 600  # 10 minutes max
            
            while status in ["queued", "transcribing", "processing"]:
                elapsed = asyncio.get_event_loop().time() - start_time
                
                # Timeout protection
                if elapsed > max_wait_time:
                    raise Exception(f"Soniox transcription timed out after {max_wait_time}s. Last status: {status}")
                
                # Fast polling: 1s intervals
                await asyncio.sleep(1.0)
                status = await self.get_transcription_status(transcription_id)
                logger.info(f"Transcription {transcription_id} status: {status} ({elapsed:.0f}s)")

                if status in ["failed", "error"]:
                    raise Exception(f"Soniox transcription failed with status: {status}")

            # 4. Get Transcript
            transcript = await self.get_transcript(transcription_id)
            return transcript

        except Exception as e:
            import traceback
            logger.error(f"Error in Soniox transcription: {e}")
            logger.error(traceback.format_exc())
            raise
    
    async def transcribe_sync(self, file_path: str, language: str = 'en') -> Dict[str, Any]:
        """
        Synchronous transcription - uploads file and gets result in one call.
        Much faster for short/medium files (up to 150MB).
        """
        url = f"{self.BASE_URL}/transcribe"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        file_size = os.path.getsize(file_path)
        logger.info(f"Sync transcription: {file_path} ({file_size / 1024:.1f} KB)")
        
        # Longer timeout for sync endpoint (it processes and returns result)
        # 10 minutes for large files
        async with httpx.AsyncClient(timeout=600.0) as client:
            with open(file_path, "rb") as f:
                files = {"file": (os.path.basename(file_path), f)}
                data = {"model": "stt-async-v3"}
                response = await client.post(url, headers=headers, files=files, data=data)
            
            if response.status_code in [200, 201]:
                result = response.json()
                logger.info(f"Sync transcription completed successfully")
                return result
            else:
                logger.error(f"Soniox Sync Error: {response.status_code} - {response.text}")
                raise Exception(f"Sync transcription failed: {response.status_code} - {response.text}")

    # Legacy async methods kept for fallback if needed
    async def transcribe_file_async(self, file_path: str, language: str = 'en') -> Dict[str, Any]:
        """
        Async transcription flow (slower, for backup).
        1. Upload file
        2. Start transcription
        3. Poll for completion
        4. Return full transcript object
        """
        if not self.api_key:
            raise ValueError("Soniox API Key is not configured")

        try:
            # 1. Upload File
            file_id = await self.upload_file(file_path)
            logger.info(f"File uploaded to Soniox. File ID: {file_id}")

            # 2. Start Transcription
            transcription_id = await self.start_transcription(file_id, language)
            logger.info(f"Transcription started. ID: {transcription_id}")

            # 3. Poll for Completion (with timeout)
            status = "queued"
            start_time = asyncio.get_event_loop().time()
            max_wait_time = 180  # 3 minutes max
            
            while status in ["queued", "transcribing", "processing"]:
                elapsed = asyncio.get_event_loop().time() - start_time
                
                # Timeout protection
                if elapsed > max_wait_time:
                    raise Exception(f"Soniox transcription timed out after {max_wait_time}s. Last status: {status}")
                
                # Adaptive polling:
                # First 10 seconds: poll every 0.5s (for short files)
                # After 10 seconds: poll every 2s
                sleep_time = 0.5 if elapsed < 10 else 2.0
                
                await asyncio.sleep(sleep_time)
                status = await self.get_transcription_status(transcription_id)
                logger.info(f"Transcription {transcription_id} status: {status} (elapsed: {elapsed:.1f}s)")

                if status in ["failed", "error"]:
                    raise Exception(f"Soniox transcription failed with status: {status}")

            # 4. Get Transcript
            transcript = await self.get_transcript(transcription_id)
            return transcript

        except Exception as e:
            import traceback
            logger.error(f"Error in Soniox transcription flow: {e}")
            logger.error(traceback.format_exc())
            raise

    async def upload_file(self, file_path: str) -> str:
        """Uploads a local file to Soniox and returns file_id."""
        logger.info(f"Uploading file to Soniox: {file_path}")
        url = f"{self.BASE_URL}/files"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        file_size = os.path.getsize(file_path)
        logger.info(f"File size: {file_size / (1024*1024):.1f} MB")

        # Longer timeout for large files (10 minutes)
        async with httpx.AsyncClient(timeout=600.0) as client:
            with open(file_path, "rb") as f:
                files = {"file": (os.path.basename(file_path), f)}
                response = await client.post(url, headers=headers, files=files)
            
            if response.status_code in [200, 201]:
                return response.json().get("id")
            else:
                logger.error(f"Soniox Upload Error: {response.text}")
                raise Exception(f"Failed to upload file: {response.status_code} - {response.text}")

    async def start_transcription(self, file_id: str, language: str) -> str:
        """Starts transcription for a file_id. Returns transcription_id."""
        url = f"{self.BASE_URL}/transcriptions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        # stt-async-v3 supports all languages with auto-detection
        model = "stt-async-v3"
            
        data = {
            "file_id": file_id,
            "model": model
        }
        
        logger.info(f"Starting transcription for file {file_id} with language {language}")

        async with httpx.AsyncClient() as client:
            response = await client.post(url, headers=headers, json=data)
            
            logger.info(f"Start Transcription Response: {response.status_code} - {response.text}")
            
            if response.status_code in [200, 201]:
                return response.json().get("id")  # API returns 'id', not 'transcription_id'
            else:
                logger.error(f"Soniox Start Transcription Error: {response.text}")
                raise Exception(f"Failed to start transcription: {response.status_code} - {response.text}")

    async def get_transcription_status(self, transcription_id: str) -> str:
        """Checks the status of the transcription."""
        url = f"{self.BASE_URL}/transcriptions/{transcription_id}"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        
        async with httpx.AsyncClient() as client:
            response = await client.get(url, headers=headers)
            
            if response.status_code == 200:
                return response.json().get("status")
            else:
                logger.error(f"Soniox Status Error: {response.text}")
                return "unknown"

    async def get_transcript(self, transcription_id: str) -> Dict[str, Any]:
        """Fetches the full transcript with text from /transcript endpoint."""
        url = f"{self.BASE_URL}/transcriptions/{transcription_id}/transcript"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        
        async with httpx.AsyncClient() as client:
            response = await client.get(url, headers=headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Soniox Transcript Error: {response.text}")
                raise Exception(f"Failed to get transcript: {response.status_code}")

soniox_service = SonioxService()

import os
import datetime
import logging
from typing import List, Optional
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from app.core.config import settings

logger = logging.getLogger(__name__)

SCOPES = [
    'https://www.googleapis.com/auth/calendar',
    'https://www.googleapis.com/auth/drive.file',
    'https://www.googleapis.com/auth/spreadsheets'
]

class GoogleCalendarService:
    """Service for interacting with Google Calendar API"""
    
    def __init__(self):
        self.creds = None
        # We will store credentials in a file for now (simple persistence)
        # In production, this should be in the database per user
        self.token_path = 'token.json'
        self.load_credentials()

    def load_credentials(self):
        """Load credentials from file if exists"""
        if os.path.exists(self.token_path):
            try:
                self.creds = Credentials.from_authorized_user_file(self.token_path, SCOPES)
            except Exception as e:
                logger.error(f"Error loading credentials: {e}")
                self.creds = None

    def get_auth_url(self):
        """Generate authorization URL for user"""
        if not settings.GOOGLE_CLIENT_ID or not settings.GOOGLE_CLIENT_SECRET:
            raise ValueError("Google Client ID/Secret not configured")
            
        # Create client config dictionary manually to avoid file dependency
        client_config = {
            "web": {
                "client_id": settings.GOOGLE_CLIENT_ID,
                "client_secret": settings.GOOGLE_CLIENT_SECRET,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "redirect_uris": [settings.GOOGLE_REDIRECT_URI]
            }
        }
        
        flow = Flow.from_client_config(
            client_config,
            scopes=SCOPES,
            redirect_uri=settings.GOOGLE_REDIRECT_URI
        )
        
        auth_url, _ = flow.authorization_url(prompt='consent')
        return auth_url

    def save_credentials_from_code(self, code: str):
        """Exchange auth code for credentials and save"""
        client_config = {
            "web": {
                "client_id": settings.GOOGLE_CLIENT_ID,
                "client_secret": settings.GOOGLE_CLIENT_SECRET,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "redirect_uris": [settings.GOOGLE_REDIRECT_URI]
            }
        }
        
        flow = Flow.from_client_config(
            client_config,
            scopes=SCOPES,
            redirect_uri=settings.GOOGLE_REDIRECT_URI
        )
        
        flow.fetch_token(code=code)
        self.creds = flow.credentials
        
        # Save to file
        with open(self.token_path, 'w') as token:
            token.write(self.creds.to_json())
            
        return True

    def get_upcoming_meetings(self, limit=10) -> List[dict]:
        """Fetch upcoming meetings with video links"""
        if not self.creds or not self.creds.valid:
            if self.creds and self.creds.expired and self.creds.refresh_token:
                try:
                    self.creds.refresh(Request())
                    # Save refreshed token
                    with open(self.token_path, 'w') as token:
                        token.write(self.creds.to_json())
                except Exception as e:
                    logger.error(f"Error refreshing token: {e}")
                    return []
            else:
                logger.warning("No valid credentials")
                return []

        try:
            service = build('calendar', 'v3', credentials=self.creds)

            now = datetime.datetime.utcnow().isoformat() + 'Z'  # 'Z' indicates UTC time
            
            events_result = service.events().list(
                calendarId='primary', 
                timeMin=now,
                maxResults=limit, 
                singleEvents=True,
                orderBy='startTime'
            ).execute()
            
            events = events_result.get('items', [])
            meetings = []
            
            for event in events:
                # Check for video links in location, description, or conferenceData
                meeting_url = self._extract_meeting_url(event)
                
                # We want to return events even if they don't have a video link for the Prep Card feature
                # But for the "upcoming meetings" list we might want to filter?
                # Let's keep it broad and let the caller filter if needed, OR add a flag.
                # For now, let's include all events but mark if they have a link.
                
                meetings.append({
                    "id": event['id'],
                    "summary": event.get('summary', 'No Title'),
                    "start": event['start'].get('dateTime', event['start'].get('date')),
                    "end": event['end'].get('dateTime', event['end'].get('date')),
                    "meeting_url": meeting_url,
                    "description": event.get('description', ''),
                    "attendees": [
                        {"email": a.get('email'), "name": a.get('displayName', a.get('email'))} 
                        for a in event.get('attendees', [])
                    ]
                })
            
            return meetings
            
        except Exception as e:
            logger.error(f"Error fetching calendar events: {e}")
            return []

    def get_events_for_today(self) -> List[dict]:
        """Fetch all events for today"""
        if not self.creds or not self.creds.valid:
            if self.creds and self.creds.expired and self.creds.refresh_token:
                try:
                    self.creds.refresh(Request())
                    with open(self.token_path, 'w') as token:
                        token.write(self.creds.to_json())
                except Exception as e:
                    logger.error(f"Error refreshing token: {e}")
                    return []
            else:
                logger.warning("No valid credentials")
                return []

        try:
            service = build('calendar', 'v3', credentials=self.creds)

            # Today start and end
            today = datetime.date.today()
            time_min = datetime.datetime.combine(today, datetime.time.min).isoformat() + 'Z'
            time_max = datetime.datetime.combine(today, datetime.time.max).isoformat() + 'Z'
            
            events_result = service.events().list(
                calendarId='primary', 
                timeMin=time_min,
                timeMax=time_max,
                singleEvents=True,
                orderBy='startTime'
            ).execute()
            
            events = events_result.get('items', [])
            result = []
            
            for event in events:
                # Skip cancelled
                if event.get('status') == 'cancelled':
                    continue
                    
                result.append({
                    "id": event['id'],
                    "summary": event.get('summary', 'No Title'),
                    "start": event['start'].get('dateTime', event['start'].get('date')),
                    "end": event['end'].get('dateTime', event['end'].get('date')),
                    "meeting_url": self._extract_meeting_url(event) # Optional
                })
            
            return result
            
        except Exception as e:
            logger.error(f"Error fetching today's events: {e}")
            return []

    def _extract_meeting_url(self, event) -> Optional[str]:
        """Extract Zoom/Meet/Teams URL from event"""
        # 1. Check conferenceData (Google Meet)
        if 'conferenceData' in event:
            for entry_point in event['conferenceData'].get('entryPoints', []):
                if entry_point.get('entryPointType') == 'video':
                    return entry_point.get('uri')
        
        # 2. Check location
        location = event.get('location', '')
        if location:
            url = self._find_url_in_text(location)
            if url: return url
            
        # 3. Check description
        description = event.get('description', '')
        if description:
            url = self._find_url_in_text(description)
            if url: return url
            
        return None

    def _find_url_in_text(self, text: str) -> Optional[str]:
        """Find meeting URL in text"""
        import re
        # Regex for Zoom, Meet, Teams
        patterns = [
            r'https://[\w-]*\.zoom\.us/j/\d+',
            r'https://meet\.google\.com/[a-z]{3}-[a-z]{4}-[a-z]{3}',
            r'https://teams\.microsoft\.com/l/meetup-join/[^"\s]+'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(0)
        return None

    def create_event(self, summary: str, start_time: datetime.datetime, end_time: datetime.datetime, 
                    attendees: List[str] = None, description: str = "", conference_data_version=1) -> Optional[dict]:
        """Create a new calendar event"""
        if not self.creds or not self.creds.valid:
            # Try to refresh
            if self.creds and self.creds.expired and self.creds.refresh_token:
                try:
                    self.creds.refresh(Request())
                    with open(self.token_path, 'w') as token:
                        token.write(self.creds.to_json())
                except Exception as e:
                    logger.error(f"Error refreshing token: {e}")
                    return None
            else:
                logger.warning("No valid credentials")
                return None

        try:
            service = build('calendar', 'v3', credentials=self.creds)
            
            event = {
                'summary': summary,
                'description': description,
                'start': {
                    'dateTime': start_time.isoformat(),
                    'timeZone': 'UTC', # Assuming input is UTC or offset-aware
                },
                'end': {
                    'dateTime': end_time.isoformat(),
                    'timeZone': 'UTC',
                },
                'attendees': [{'email': email} for email in (attendees or [])],
                'conferenceData': {
                    'createRequest': {
                        'requestId': f"req-{int(datetime.datetime.now().timestamp())}",
                        'conferenceSolutionKey': {'type': 'hangoutsMeet'}
                    }
                }
            }
            
            event = service.events().insert(
                calendarId='primary',
                body=event,
                conferenceDataVersion=conference_data_version
            ).execute()
            
            logger.info(f"Created event: {event.get('htmlLink')}")
            return event
            
        except Exception as e:
            logger.error(f"Error creating event: {e}")
            return None

google_calendar_service = GoogleCalendarService()

import os
import logging
from typing import List, Optional
from llama_index.core import VectorStoreIndex, Document, StorageContext, load_index_from_storage
from llama_index.core.node_parser import SentenceSplitter
from llama_index.llms.openai import OpenAI
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core import Settings
from app.core.config import settings

logger = logging.getLogger(__name__)

class LlamaIndexService:
    """Service for RAG (Retrieval-Augmented Generation) using LlamaIndex"""
    
    def __init__(self):
        self.storage_dir = "./storage"
        self.indices = {}
        
        # Configure Global Settings
        Settings.llm = OpenAI(model="gpt-4o", temperature=0.1, api_key=settings.OPENAI_API_KEY)
        Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-small", api_key=settings.OPENAI_API_KEY)
        Settings.node_parser = SentenceSplitter(chunk_size=512, chunk_overlap=20)
        
        # Ensure storage directory exists
        if not os.path.exists(self.storage_dir):
            os.makedirs(self.storage_dir)
            
        self._load_indices()

    def _load_indices(self):
        """Load all persisted indices from storage"""
        try:
            # Check if storage context exists
            if os.path.exists(os.path.join(self.storage_dir, "docstore.json")):
                storage_context = StorageContext.from_defaults(persist_dir=self.storage_dir)
                # Load main index (we can have multiple, but let's start with one global for now)
                self.index = load_index_from_storage(storage_context)
                logger.info("LlamaIndex loaded from storage.")
            else:
                self.index = None
                logger.info("No existing LlamaIndex found. Waiting for data.")
        except Exception as e:
            logger.error(f"Error loading LlamaIndex: {e}")
            self.index = None

    def index_file(self, file_path: str, doc_id: str = None):
        """
        Index a file (PDF or Text) into the vector store.
        """
        try:
            text = ""
            if file_path.lower().endswith(".pdf"):
                from pypdf import PdfReader
                reader = PdfReader(file_path)
                for page in reader.pages:
                    text += page.extract_text() + "\n"
            elif file_path.lower().endswith(".docx"):
                import docx
                doc = docx.Document(file_path)
                text = "\n".join([para.text for para in doc.paragraphs])
            else:
                # Assume text file
                with open(file_path, "r", encoding="utf-8") as f:
                    text = f.read()
            
            if not text.strip():
                logger.warning(f"File {file_path} is empty or unreadable.")
                return

            # If doc_id is provided, try to delete existing document first to avoid duplicates
            if doc_id:
                self.delete_document(doc_id)

            # Use existing method to update index
            self.create_or_update_index([text], [doc_id] if doc_id else None)
            logger.info(f"Successfully indexed file: {file_path}")
            
        except Exception as e:
            logger.error(f"Error indexing file {file_path}: {e}")
            raise e

    def delete_document(self, doc_id: str):
        """Delete a document from the index by its doc_id"""
        if self.index is None:
            return
            
        try:
            # delete_ref_doc removes all nodes associated with the document
            self.index.delete_ref_doc(doc_id, delete_from_docstore=True)
            self.index.storage_context.persist(persist_dir=self.storage_dir)
            logger.info(f"Deleted document {doc_id} from index.")
        except KeyError:
            # Document might not exist yet, which is fine
            pass
        except Exception as e:
            logger.error(f"Error deleting document {doc_id}: {e}")

    def create_or_update_index(self, documents: List[str], doc_ids: List[str] = None):
        """Create or update the vector index with new documents"""
        try:
            docs = []
            for i, text in enumerate(documents):
                doc_id = doc_ids[i] if doc_ids else None
                docs.append(Document(text=text, doc_id=doc_id))
            
            if self.index is None:
                # Create new index
                self.index = VectorStoreIndex.from_documents(docs)
                logger.info("Created new LlamaIndex.")
            else:
                # Update existing index (insert documents)
                for doc in docs:
                    self.index.insert(doc)
                logger.info("Updated existing LlamaIndex.")
            
            # Persist
            self.index.storage_context.persist(persist_dir=self.storage_dir)
            
        except Exception as e:
            logger.error(f"Error updating index: {e}")
            raise e

    def query(self, query_text: str) -> str:
        """Query the index"""
        if self.index is None:
            return "База знаний пока пуста. Загрузите документы."
            
        try:
            query_engine = self.index.as_query_engine(similarity_top_k=3)
            response = query_engine.query(query_text)
            return str(response)
        except Exception as e:
            logger.error(f"Error querying index: {e}")
            return "Произошла ошибка при поиске в базе знаний."

llama_service = LlamaIndexService()

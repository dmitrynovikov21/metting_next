import logging
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseUpload, MediaIoBaseDownload
from app.services.google_calendar_service import google_calendar_service
import io

logger = logging.getLogger(__name__)

class GoogleDriveService:
    def __init__(self):
        self.service = None

    def get_service(self):
        if not self.service:
            if google_calendar_service.creds:
                self.service = build('drive', 'v3', credentials=google_calendar_service.creds)
            else:
                logger.warning("Google Drive Service: No credentials available")
        return self.service

    def upload_text_file(self, filename: str, content: str, folder_id: str) -> str:
        """
        Uploads a text file to Google Drive.
        Returns the webViewLink of the uploaded file.
        """
        service = self.get_service()
        if not service:
            return None

        try:
            file_metadata = {
                'name': filename,
                'parents': [folder_id]
            }
            media = MediaIoBaseUpload(io.BytesIO(content.encode('utf-8')), mimetype='text/plain')
            
            file = service.files().create(
                body=file_metadata,
                media_body=media,
                fields='id, webViewLink'
            ).execute()
            
            logger.info(f"File ID: {file.get('id')} uploaded to Drive")
            return file.get('webViewLink')
            
        except Exception as e:
            logger.error(f"Error uploading to Drive: {e}")
            return None

    def read_file(self, file_id: str) -> str:
        """
        Reads the content of a text/google doc file from Drive.
        Returns the text content.
        """
        service = self.get_service()
        if not service:
            return None

        try:
            # Check file mimeType
            file = service.files().get(fileId=file_id).execute()
            mime_type = file.get('mimeType')
            
            if mime_type == 'application/vnd.google-apps.document':
                # Export Google Doc as text
                request = service.files().export_media(fileId=file_id, mimeType='text/plain')
            else:
                # Download binary/text file
                request = service.files().get_media(fileId=file_id)
                
            file_content = io.BytesIO()
            downloader = MediaIoBaseDownload(file_content, request)
            done = False
            while done is False:
                status, done = downloader.next_chunk()
                
            return file_content.getvalue().decode('utf-8')
            
        except Exception as e:
            logger.error(f"Error reading from Drive: {e}")
            return None

google_drive_service = GoogleDriveService()

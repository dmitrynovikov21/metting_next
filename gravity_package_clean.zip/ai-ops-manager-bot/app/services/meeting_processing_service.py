import logging
import datetime
import httpx
import json
import redis.asyncio as redis
from app.core.config import settings
from app.services.recall_service import recall_service
from app.services.gemini_service import gemini_service
from app.services.ai_service import ai_service
from app.services.google_drive_service import google_drive_service
from app.services.google_sheets_service import google_sheets_service
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

logger = logging.getLogger(__name__)

class MeetingProcessingService:
    async def process_meeting(self, bot_id: str, data: dict = None):
        """
        Processes a meeting: fetches transcript (or handles missing), 
        archives to Drive, logs to Sheets, and notifies user.
        """
        logger.info(f"Starting processing for bot {bot_id}")
        
        # If data is not provided (e.g. from polling), fetch it? 
        # Actually, get_transcript needs bot_id. data is mostly for video_url and duration.
        # If data is missing, we might need to fetch bot info again to get video_url.
        
        video_url = None
        duration = 0
        
        if data:
            video_url = data.get('video_url')
            duration = data.get('duration', 0)
        else:
            # Fetch bot info to get video_url and duration if not provided
            try:
                bot_info = await recall_service.get_bot(bot_id)
                # Extract video url from recordings
                recordings = bot_info.get('recordings', [])
                if recordings:
                    last_recording = recordings[-1]
                    video_mixed = last_recording.get('media_shortcuts', {}).get('video_mixed', {})
                    video_url = video_mixed.get('data', {}).get('download_url')
                    
                    # Calculate duration
                    start = last_recording.get('started_at')
                    end = last_recording.get('completed_at')
                    if start and end:
                        from dateutil import parser
                        s = parser.parse(start)
                        e = parser.parse(end)
                        duration = (e - s).total_seconds()
            except Exception as e:
                logger.error(f"Failed to fetch bot info for {bot_id}: {e}")

        # Fetch transcript
        transcript = None
        try:
            transcript = await recall_service.get_transcript(bot_id)
        except Exception as e:
            logger.warning(f"Transcript not available for bot {bot_id}: {e}")
            
        # Fallback: Try Gemini Video Transcription if no transcript but video exists
        if not transcript and video_url:
            try:
                logger.info("Attempting fallback transcription with Gemini...")
                transcript = await gemini_service.transcribe_video(video_url)
                logger.info("Gemini fallback transcription successful")
            except Exception as e:
                logger.error(f"Gemini fallback failed: {e}")
        
        # Prepare Metadata
        date_obj = datetime.datetime.now()
        date_str = date_obj.strftime("%Y-%m-%d")
        time_str = date_obj.strftime("%H:%M")
        
        # Default values
        topic = "Meeting (No Transcript)"
        attendees = "Unknown"
        meeting_data = {}
        
        if transcript:
            # Analyze meeting
            try:
                meeting_data = await ai_service.analyze_meeting(transcript)
                meeting_data['transcript'] = transcript
                topic = meeting_data.get('title', meeting_data.get('summary', 'Meeting')).replace('/', '-').replace('\\', '-')
                attendees = ", ".join(meeting_data.get('attendees', []))
            except Exception as e:
                logger.error(f"Failed to analyze meeting: {e}")
        
        # 1. Archive Transcript (if available)
        transcript_filename = f"{date_str}_Transcript_{topic}.txt"
        transcript_link = None
        if transcript and settings.DRIVE_TRANSCRIPTS_ID:
            try:
                transcript_link = google_drive_service.upload_text_file(
                    transcript_filename, 
                    transcript, 
                    settings.DRIVE_TRANSCRIPTS_ID
                )
            except Exception as e:
                logger.error(f"Failed to upload transcript: {e}")
        
        # 2. Archive Recording (if available)
        recording_link = None
        if video_url:
            recording_link = video_url 
        
        # 3. Log to Google Sheets (Registry)
        if settings.GOOGLE_SHEETS_ID:
            try:
                duration_str = str(int(duration // 60)) + " min"
                
                row = [
                    date_str,
                    time_str,
                    topic,
                    duration_str,
                    attendees,
                    transcript_link or "No Link",
                    "Pending", # Protocol Link (Pending)
                    recording_link or "No Link",
                    "Processed" if transcript else "Processed (No Transcript)"
                ]
                if google_sheets_service.insert_row_at_top(settings.GOOGLE_SHEETS_ID, row):
                    logger.info(f"Logged meeting to Sheets: {row}")
                else:
                    logger.error("Failed to insert row in Sheets (check logs)")
            except Exception as e:
                logger.error(f"Failed to log to Sheets: {e}")
        
        # Save to Redis
        redis_client = redis.from_url(settings.REDIS_URL)
        if meeting_data:
            await redis_client.set(f"meeting_data_{bot_id}", json.dumps(meeting_data), ex=86400)
        
        # Ensure Example Protocol is loaded
        example_protocol = await redis_client.get("protocol_example")
        if not example_protocol and settings.EXAMPLE_PROTOCOL_DRIVE_ID:
            try:
                content = google_drive_service.read_file(settings.EXAMPLE_PROTOCOL_DRIVE_ID)
                if content:
                    await redis_client.set("protocol_example", content)
            except Exception as e:
                logger.error(f"Failed to load example protocol: {e}")
        
        await redis_client.close()
        
        # Send interactive message to CEO
        keyboard = []
        if transcript:
            keyboard = [
                [InlineKeyboardButton("📜 Сделать протокол", callback_data=f"meeting_protocol_{bot_id}")],
                [InlineKeyboardButton("✅ Сделать задачи", callback_data=f"meeting_tasks_{bot_id}")]
            ]
        else:
            keyboard = [[InlineKeyboardButton("⚠️ Нет транскрипта", callback_data="noop")]]
        
        msg_text = f"🎬 **Встреча обработана!**\n\n📝 **Тема:** {topic}\n"
        if transcript_link:
            msg_text += f"📂 [Транскрипт в Drive]({transcript_link})\n"
        if video_url:
            msg_text += f"📹 [Видео записи]({video_url})\n"
            
        if not transcript:
            msg_text += "\n⚠️ **Внимание:** Транскрипт не получен (ограничение тарифа Recall). Видео доступно по ссылке выше (если не открывается — проверьте дашборд Recall)."
        else:
            msg_text += "\nЧто делаем?"
        
        async with httpx.AsyncClient() as client:
            await client.post(
                f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}/sendMessage",
                json={
                    "chat_id": settings.CEO_TELEGRAM_ID,
                    "text": msg_text,
                    "parse_mode": "Markdown",
                    "reply_markup": {"inline_keyboard": [[{"text": b.text, "callback_data": b.callback_data} for b in row] for row in keyboard]}
                }
            )
        
        logger.info(f"Processed meeting from bot {bot_id}")
        return True

meeting_processing_service = MeetingProcessingService()

import httpx
import logging
from app.core.config import settings

logger = logging.getLogger(__name__)

class RecallService:
    """Service for interacting with Recall.ai Meeting Bot API"""
    
    def __init__(self):
        self.api_key = settings.RECALL_API_KEY
        # Use us-west-2 region (check your Recall.ai dashboard for region)
        self.base_url = "https://us-west-2.recall.ai/api/v1"
        # Recall.ai uses "Token <key>" format, not "Bearer"
        self.headers = {
            "Authorization": f"Token {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
    
    async def create_bot(self, meeting_url: str, bot_name: str = "AI Ops Manager", webhook_url: str = None) -> dict:
        """
        Create a bot that will join the meeting.
        
        Args:
            meeting_url: Zoom/Google Meet/Teams meeting URL
            bot_name: Display name for the bot
            webhook_url: Optional URL for Recall webhooks
            
        Returns:
            Bot information including bot_id
        """
        async with httpx.AsyncClient() as client:
            try:
                # Minimal payload - Recall.ai API v1
                payload = {
                    "meeting_url": meeting_url,
                    "bot_name": bot_name
                }
                
                if webhook_url:
                    payload["webhook_url"] = webhook_url
                
                response = await client.post(
                    f"{self.base_url}/bot",
                    json=payload,
                    headers=self.headers,
                    timeout=30.0
                )
                response.raise_for_status()
                bot_data = response.json()
                
                logger.info(f"Created Recall bot: {bot_data.get('id')}")
                return bot_data
                
            except httpx.HTTPError as e:
                logger.error(f"Error creating Recall bot: {e}")
                if hasattr(e, 'response') and e.response is not None:
                     logger.error(f"Recall API Error Response: {e.response.text}")
                raise
    
    async def get_bot(self, bot_id: str) -> dict:
        """Get bot information and status"""
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/bot/{bot_id}",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPError as e:
                logger.error(f"Error getting bot {bot_id}: {e}")
                raise
    
    async def get_transcript(self, bot_id: str) -> str:
        """
        Get the transcript for a completed meeting.
        
        Returns:
            Full transcript text with speaker labels
        """
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/bot/{bot_id}/transcript",
                    headers=self.headers,
                    timeout=30.0
                )
                response.raise_for_status()
                transcript_data = response.json()
                
                # Format transcript with speaker labels
                formatted_transcript = ""
                for utterance in transcript_data.get("transcript", []):
                    speaker = utterance.get("speaker", "Unknown")
                    text = utterance.get("words", "")
                    formatted_transcript += f"{speaker}: {text}\n"
                
                return formatted_transcript
                
            except httpx.HTTPError as e:
                logger.error(f"Error getting transcript for bot {bot_id}: {e}")
                raise

    async def leave_meeting(self, bot_id: str) -> bool:
        """Instruct the bot to leave the meeting (triggering processing)"""
        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    f"{self.base_url}/bot/{bot_id}/leave_call",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                logger.info(f"Bot {bot_id} left the meeting")
                return True
            except httpx.HTTPError as e:
                logger.error(f"Error making bot {bot_id} leave: {e}")
                return False
    
    async def delete_bot(self, bot_id: str) -> bool:
        """Delete a bot and its recordings"""
        async with httpx.AsyncClient() as client:
            try:
                response = await client.delete(
                    f"{self.base_url}/bot/{bot_id}",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                logger.info(f"Deleted bot {bot_id}")
                return True
            except httpx.HTTPError as e:
                logger.error(f"Error deleting bot {bot_id}: {e}")
                return False

recall_service = RecallService()

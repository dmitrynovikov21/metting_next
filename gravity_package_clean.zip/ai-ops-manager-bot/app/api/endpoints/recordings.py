from fastapi import APIRouter, UploadFile, File, Form, HTTPException, BackgroundTasks
from app.services.soniox_service import soniox_service
from app.core.config import settings
import shutil
import os
import uuid
import json
import logging
import subprocess
import traceback
from datetime import datetime
from typing import Optional, List

router = APIRouter()
logger = logging.getLogger(__name__)

UPLOAD_DIR = "storage/uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Simple in-memory status tracking
recording_status = {}

def convert_to_mp3(input_path: str, output_path: str) -> bool:
    """Convert audio file to mp3 using ffmpeg"""
    try:
        result = subprocess.run([
            "ffmpeg", "-y", "-i", input_path,
            "-acodec", "libmp3lame", "-ar", "16000", "-ac", "1",
            output_path
        ], capture_output=True, text=True, timeout=60)
        
        if result.returncode == 0:
            logger.info(f"Converted {input_path} to {output_path}")
            return True
        else:
            logger.error(f"FFmpeg error: {result.stderr}")
            return False
    except FileNotFoundError:
        logger.warning("FFmpeg not found, using original file")
        return False
    except Exception as e:
        logger.error(f"Conversion error: {e}")
        return False


@router.post("/recordings", status_code=202)
async def upload_recording(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    language: str = Form("en"),
    duration: Optional[float] = Form(None)
):
    """
    Uploads a file and starts transcription.
    """
    try:
        recording_id = str(uuid.uuid4())
        file_extension = file.filename.split(".")[-1] if "." in file.filename else "webm"
        file_path = f"{UPLOAD_DIR}/{recording_id}.{file_extension}"
        
        # Save file
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        file_size = os.path.getsize(file_path)
        logger.info(f"File saved to {file_path} (size: {file_size} bytes)")
        
        # Check if file is too small (less than 1KB probably means no audio)
        if file_size < 1024:
            raise ValueError("Recording is too short or empty")

        # Initialize status
        recording_status[recording_id] = {
            "status": "processing",
            "filename": file.filename,
            "created_at": datetime.utcnow().isoformat(),
            "error": None,
            "duration": duration,
            "language": language
        }

        # Start transcription in background
        background_tasks.add_task(process_recording, recording_id, file_path, file.filename, language, duration)

        return {
            "recording_id": recording_id,
            "status": "queued",
            "message": "File uploaded and transcription queued."
        }

    except Exception as e:
        logger.error(f"Upload failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


from pydantic import BaseModel

class ProcessRequest(BaseModel):
    recording_id: str
    file_path: str
    filename: str
    language: str = "ru"


@router.post("/recordings/process", status_code=202)
async def process_external_upload(
    request: ProcessRequest,
    background_tasks: BackgroundTasks
):
    """
    Process a file that was uploaded via the upload server (port 8001).
    """
    try:
        if not os.path.exists(request.file_path):
            raise HTTPException(status_code=404, detail=f"File not found: {request.file_path}")
        
        # Initialize status
        recording_status[request.recording_id] = {
            "status": "processing",
            "filename": request.filename,
            "created_at": datetime.utcnow().isoformat(),
            "error": None
        }
        
        # Start transcription in background
        background_tasks.add_task(
            process_recording, 
            request.recording_id, 
            request.file_path, 
            request.filename, 
            request.language,
            None # Duration not available for external uploads yet
        )
        
        return {
            "recording_id": request.recording_id,
            "status": "processing",
            "message": "Transcription started."
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Process request failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


async def process_recording(recording_id: str, file_path: str, original_filename: str, language: str, duration: Optional[float] = None):
    """
    Background task to handle transcription.
    """
    try:
        logger.info(f"Processing recording {recording_id}...")
        
        # Update status: Starting
        recording_status[recording_id] = {
            "status": "processing",
            "stage": "uploading",
            "progress": 10,
            "filename": original_filename,
            "created_at": recording_status.get(recording_id, {}).get("created_at", datetime.utcnow().isoformat()),
            "error": None,
            "duration": duration,
            "language": language
        }
        
        # Skip conversion - Soniox supports webm/ogg natively and it saves time
        processing_path = file_path
        
        # Check if Soniox is configured
        if not settings.SONIOX_API_KEY:
            logger.warning("Soniox API Key not configured. Creating mock transcript.")
            transcript = {
                "id": recording_id,
                "text": "Расшифровка недоступна. API ключ Soniox не настроен.",
                "tokens": [],
                "filename": original_filename,
                "created_at": datetime.utcnow().isoformat(),
                "duration_seconds": duration,
                "language": language
            }
        else:
            # Real transcription
            logger.info(f"Starting Soniox transcription for {processing_path}")
            
            # Update status: Transcribing
            recording_status[recording_id]["stage"] = "transcribing"
            recording_status[recording_id]["progress"] = 30
            
            result = await soniox_service.transcribe_file(processing_path, language)
            
            # Update status: Finalizing
            recording_status[recording_id]["stage"] = "finalizing"
            recording_status[recording_id]["progress"] = 85
            
            # Extract text from result
            text = result.get("text", "")
            if not text and "tokens" in result:
                # Build text from tokens if needed
                text = "".join([t.get("text", "") for t in result.get("tokens", [])])
            
            transcript = {
                "id": recording_id,
                "text": text,
                "tokens": result.get("tokens", []),
                "filename": original_filename,
                "created_at": datetime.utcnow().isoformat(),
                "duration_seconds": duration,
                "language": language
            }
            
            logger.info(f"Transcription completed: {len(text)} chars")
        
        # Save transcript to storage
        transcript_path = f"{UPLOAD_DIR}/{recording_id}_transcript.json"
        with open(transcript_path, "w", encoding="utf-8") as f:
            json.dump(transcript, f, indent=2, ensure_ascii=False)
            
        # Update status
        recording_status[recording_id] = {
            "status": "completed",
            "filename": original_filename,
            "created_at": recording_status.get(recording_id, {}).get("created_at"),
            "error": None
        }
            
        logger.info(f"Recording {recording_id} processed successfully.")
        
    except Exception as e:
        error_msg = str(e) if str(e) else "Unknown error occurred"
        full_error = f"{error_msg}\n{traceback.format_exc()}"
        logger.error(f"Processing failed for {recording_id}: {full_error}")
        
        # Update status with error
        recording_status[recording_id] = {
            "status": "error",
            "filename": original_filename,
            "created_at": recording_status.get(recording_id, {}).get("created_at"),
            "error": error_msg
        }
        
        # Create error transcript file
        error_transcript = {
            "id": recording_id,
            "text": f"Ошибка обработки: {error_msg}",
            "tokens": [],
            "filename": original_filename,
            "error": True,
            "error_details": full_error
        }
        transcript_path = f"{UPLOAD_DIR}/{recording_id}_transcript.json"
        with open(transcript_path, "w", encoding="utf-8") as f:
            json.dump(error_transcript, f, indent=2, ensure_ascii=False)


@router.get("/recordings/{recording_id}")
async def get_recording(recording_id: str):
    """
    Gets the status/result of a recording.
    """
    transcript_path = f"{UPLOAD_DIR}/{recording_id}_transcript.json"
    
    if os.path.exists(transcript_path):
        with open(transcript_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        return {
            "id": recording_id,
            "status": "error" if data.get("error") else "completed",
            "transcript": data,
            "error": data.get("error_details") if data.get("error") else None
        }
    
    # Check in-memory status
    if recording_id in recording_status:
        status_info = recording_status[recording_id]
        return {
            "id": recording_id,
            "status": status_info["status"],
            "error": status_info.get("error")
        }
    
    # Check if original file exists
    for filename in os.listdir(UPLOAD_DIR):
        if filename.startswith(recording_id) and not filename.endswith("_transcript.json"):
            return {
                "id": recording_id,
                "status": "processing"
            }
    
    raise HTTPException(status_code=404, detail="Recording not found")


@router.post("/recordings/{recording_id}/analyze")
async def analyze_recording(recording_id: str):
    """
    Analyzes the transcript using AI and returns summary, decisions, action items.
    Uses Google Gemini API.
    """
    import google.generativeai as genai
    
    transcript_path = f"{UPLOAD_DIR}/{recording_id}_transcript.json"
    
    if not os.path.exists(transcript_path):
        raise HTTPException(status_code=404, detail="Transcript not found")
    
    with open(transcript_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    transcript_text = data.get("text", "")
    if not transcript_text or len(transcript_text) < 50:
        raise HTTPException(status_code=400, detail="Transcript is too short for analysis")
    
class ReAnalyzeRequest(BaseModel):
    blocks: List[dict]
    language: str = "ru"

@router.post("/recordings/{recording_id}/analyze")
async def reanalyze_recording(
    recording_id: str,
    request: ReAnalyzeRequest,
    background_tasks: BackgroundTasks
):
    """
    Re-analyze an existing recording with a custom protocol structure.
    """
    transcript_path = f"{UPLOAD_DIR}/{recording_id}_transcript.json"
    if not os.path.exists(transcript_path):
        raise HTTPException(status_code=404, detail="Recording not found")

    # Update status
    recording_status[recording_id] = {
        "status": "processing",
        "stage": "analyzing",
        "progress": 0,
        "filename": "Re-analysis",
        "created_at": datetime.utcnow().isoformat(),
        "error": None
    }

    # Start analysis in background
    background_tasks.add_task(analyze_recording, recording_id, request.blocks)

    return {"status": "processing", "message": "Re-analysis started"}


async def analyze_recording(recording_id: str, blocks: Optional[List[dict]] = None):
    """
    Analyzes the transcript using Gemini with a dynamic protocol structure.
    """
    try:
        # Configure Gemini
        genai.configure(api_key=settings.GEMINI_API_KEY)
        model = genai.GenerativeModel('models/gemini-2.0-flash')
        
        transcript_path = f"{UPLOAD_DIR}/{recording_id}_transcript.json"
        
        if not os.path.exists(transcript_path):
            raise HTTPException(status_code=404, detail="Transcript not found")
        
        with open(transcript_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        transcript_text = data.get("text", "")
        if not transcript_text or len(transcript_text) < 50:
            raise HTTPException(status_code=400, detail="Transcript is too short for analysis")

        # Construct Dynamic Blocks JSON for Prompt
        if not blocks:
            # Default blocks (Legacy support)
            blocks_structure = [
                {
                    "title": "STRATEGIC GOALS",
                    "level1_management": {
                        "status": "normal / risk / critical",
                        "key_results": ["Result 1", "Result 2"],
                        "decisions": ["Decision 1", "Decision 2"]
                    }
                },
                {
                    "title": "OPERATIONAL UPDATES",
                    "level2_operations": {
                        "done": ["What was done"],
                        "blockers": ["What is blocking progress"],
                        "dependencies": ["Dependencies"]
                    }
                },
                {
                    "title": "RISKS & ISSUES",
                    "risks": [
                        {
                            "text": "CAUSE -> SOLUTION (Must include solution)",
                            "probability": "low/medium/high",
                            "owner": "Who is responsible"
                        }
                    ]
                },
                {
                    "title": "ACTION PLAN",
                    "tasks": [
                        {
                            "text": "Task description",
                            "owner": "Name",
                            "deadline": "Date/Timeframe",
                            "priority": "high/medium/low"
                        }
                    ]
                }
            ]
        else:
            # Build structure based on requested blocks
            blocks_structure = []
            for block in blocks:
                if block['type'] == 'decisions':
                    blocks_structure.append({
                        "title": block['title'].upper(),
                        "level1_management": {
                            "decisions": ["Decision 1", "Decision 2"],
                            "agreements": ["Agreement 1"]
                        }
                    })
                elif block['type'] == 'risks':
                    blocks_structure.append({
                        "title": block['title'].upper(),
                        "risks": [{"text": "CAUSE -> SOLUTION", "probability": "level", "owner": "Name"}]
                    })
                elif block['type'] == 'tasks':
                    blocks_structure.append({
                        "title": block['title'].upper(),
                        "tasks": [{"text": "Task", "owner": "Name", "deadline": "Date", "priority": "Level"}]
                    })
                elif block['type'] == 'growth':
                    blocks_structure.append({
                        "title": block['title'].upper(),
                        "growth_points": ["Opportunity 1", "Insight 2"]
                    })
                elif block['type'] == 'blockers':
                    blocks_structure.append({
                        "title": block['title'].upper(),
                        "level2_operations": {"blockers": ["Blocker 1"], "bottlenecks": ["Bottleneck 1"]}
                    })
                elif block['type'] == 'mood':
                    blocks_structure.append({
                        "title": block['title'].upper(),
                        "mood_analysis": {"tone": "Positive/Negative", "engagement": "High/Low", "conflicts": ["Conflict 1"]}
                    })
                elif block['type'] == 'agenda':
                    blocks_structure.append({
                        "title": block['title'].upper(),
                        "topics": [{"title": "Topic 1", "details": "Summary"}]
                    })
                elif block['type'] == 'custom':
                    blocks_structure.append({
                        "title": block['title'].upper(),
                        "custom_analysis": block.get('instruction', 'Analyze this section based on the title.')
                    })

        
        prompt = f"""You are a CEO-level AI Secretary.
        
Your task is to analyze the following meeting transcript and generate a STRICT EXECUTIVE PROTOCOL based on the requested structure.

TRANSCRIPT:
{transcript_text[:50000]}

OUTPUT FORMAT (JSON ONLY):
{{
    "meeting_header": {{
        "number": "001",
        "date": "DD.MM.YYYY",
        "participants": ["List of names"],
        "duration": "Approx duration",
        "goal": "Clear meeting goal"
    }},
    "summary": "Executive summary (2-3 paragraphs). Focus on facts, money, dates, and outcomes.",
    "blocks": {json.dumps(blocks_structure, indent=4)},
    "final_summary": {{
        "top_decisions": ["Decision 1", "Decision 2"],
        "growth_points": ["Insight 1 (Window of Opportunity)", "Insight 2"],
        "next_steps": ["Immediate next steps"]
    }}
}}

STYLE GUIDELINES:
- Strict, executive tone.
- No fluff, no "discussed", no "mentioned".
- Focus on outcomes and responsibilities.
- If data is missing, omit the field or write "N/A".
"""

        response = model.generate_content(prompt)
        result_text = response.text
        
        # Clean up markdown
        if "```json" in result_text:
            lines = result_text.split("\n")
            if lines[0].startswith("```"):
                result_text = "\n".join(lines[1:-1] if lines[-1] == "```" else lines[1:])
            result_text = result_text.strip()
        if result_text.startswith("json"):
            result_text = result_text[4:].strip()
        
        analysis = json.loads(result_text)
        
        # Save analysis alongside transcript
        analysis_path = f"{UPLOAD_DIR}/{recording_id}_analysis.json"
        with open(analysis_path, "w", encoding="utf-8") as f:
            json.dump(analysis, f, indent=2, ensure_ascii=False)
            
        # Update status to completed
        recording_status[recording_id] = {
            "status": "completed",
            "stage": "done",
            "progress": 100,
            "filename": data.get("filename", "recording"),
            "created_at": datetime.utcnow().isoformat(),
            "error": None
        }
        
        logger.info(f"Analysis completed for {recording_id}")
        return analysis
        
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse AI response: {e}")
        logger.error(f"Raw response: {result_text[:500]}")
        # Update status to error
        recording_status[recording_id] = {
            "status": "error",
            "error": "Failed to parse AI analysis"
        }
        raise HTTPException(status_code=500, detail="Failed to parse AI analysis")
    except Exception as e:
        logger.error(f"AI analysis failed: {e}")
        # Update status to error
        recording_status[recording_id] = {
            "status": "error",
            "error": str(e)
        }
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/recordings/{recording_id}/analysis")
async def get_analysis(recording_id: str):
    """
    Gets cached analysis for a recording.
    """
    analysis_path = f"{UPLOAD_DIR}/{recording_id}_analysis.json"
    
    if os.path.exists(analysis_path):
        with open(analysis_path, "r", encoding="utf-8") as f:
            return json.load(f)
    
    raise HTTPException(status_code=404, detail="Analysis not found. Call POST /analyze first.")


@router.get("/recordings")
async def list_recordings():
    """
    Lists all recordings with their status.
    """
    recordings = []
    
    # Get all files to identify recordings (both processed and unprocessed)
    all_files = os.listdir(UPLOAD_DIR)
    recording_ids = set()
    
    # First pass: collect all recording IDs from filenames
    for filename in all_files:
        # Skip system files
        if filename.startswith("."): continue
        
        # Extract ID (assuming UUID format at start of filename)
        # Simple heuristic: take the part before the first dot or underscore
        # But our format is {uuid}.ext or {uuid}_transcript.json
        
        parts = filename.split("_")
        if len(parts) > 1 and parts[-1] == "transcript.json":
            rid = filename.replace("_transcript.json", "")
            recording_ids.add(rid)
        else:
            # It's likely an audio file
            # Check if it looks like a UUID (36 chars)
            base_name = filename.split(".")[0]
            if len(base_name) == 36 and "-" in base_name:
                recording_ids.add(base_name)

    # Build list
    for rid in recording_ids:
        transcript_path = f"{UPLOAD_DIR}/{rid}_transcript.json"
        
        if os.path.exists(transcript_path):
            # We have a transcript
            try:
                with open(transcript_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                
                display_name = data.get("filename")
                created_at_str = data.get("created_at", datetime.utcnow().isoformat())
                
                # Fallback for display name
                if not display_name or "_transcript.json" in display_name or (len(display_name) > 30 and "-" in display_name and " " not in display_name):
                    try:
                        dt = datetime.fromisoformat(created_at_str)
                        display_name = dt.strftime("Meeting %d.%m.%Y %H:%M")
                    except:
                        display_name = "Meeting"

                # Calculate metrics
                text = data.get("text", "") or ""
                char_count = len(text)
                word_count = len(text.split())
                language = data.get("language", "en").upper()
                
                # Use stored duration if available, otherwise estimate
                duration_seconds = data.get("duration_seconds")
                if not duration_seconds:
                    duration_seconds = int(char_count / 15)

                recordings.append({
                    "id": rid,
                    "filename": display_name,
                    "status": "error" if data.get("error") else "completed",
                    "created_at": created_at_str,
                    "text_preview": (text[:100] + "...") if len(text) > 100 else text,
                    "char_count": char_count,
                    "word_count": word_count,
                    "duration_seconds": duration_seconds,
                    "language": language
                })
            except Exception as e:
                logger.error(f"Error reading transcript for {rid}: {e}")
        else:
            # No transcript - check in-memory status or assume processing/stuck
            status_info = recording_status.get(rid)
            
            if status_info:
                # It's actively processing
                recordings.append({
                    "id": rid,
                    "filename": status_info.get("filename", "Processing..."),
                    "status": status_info.get("status", "processing"),
                    "created_at": status_info.get("created_at", datetime.utcnow().isoformat()),
                    "duration_seconds": status_info.get("duration"),
                    "language": status_info.get("language", "en").upper()
                })
            else:
                # Not in memory, no transcript -> Orphaned / Interrupted
                # Try to find the audio file to get creation time
                audio_file = None
                for f in all_files:
                    if f.startswith(rid) and not f.endswith("json"):
                        audio_file = f
                        break
                
                created_at = datetime.utcnow().isoformat()
                if audio_file:
                    try:
                        # Use file modification time
                        mtime = os.path.getmtime(f"{UPLOAD_DIR}/{audio_file}")
                        created_at = datetime.fromtimestamp(mtime).isoformat()
                    except:
                        pass
                
                recordings.append({
                    "id": rid,
                    "filename": "Processing (Interrupted)",
                    "status": "processing", # Show as processing so user can try to re-analyze or wait
                    "created_at": created_at
                })

    # Sort by created_at descending
    recordings.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    
    return recordings


@router.get("/recordings/{recording_id}/audio")
async def get_recording_audio(recording_id: str):
    """
    Streams the audio file for a recording.
    """
    from fastapi.responses import FileResponse
    
    # Find the audio file (could be webm, mp3, etc)
    for filename in os.listdir(UPLOAD_DIR):
        if filename.startswith(recording_id) and not filename.endswith("_transcript.json"):
            file_path = f"{UPLOAD_DIR}/{filename}"
            
            # Determine media type
            if filename.endswith(".webm"):
                media_type = "audio/webm"
            elif filename.endswith(".mp3"):
                media_type = "audio/mpeg"
            elif filename.endswith(".wav"):
                media_type = "audio/wav"
            elif filename.endswith(".ogg"):
                media_type = "audio/ogg"
            elif filename.endswith(".m4a"):
                media_type = "audio/mp4"
            elif filename.endswith(".aac"):
                media_type = "audio/aac"
            else:
                media_type = "application/octet-stream"
            
            return FileResponse(
                path=file_path,
                media_type=media_type,
                filename=filename
            )
    
    raise HTTPException(status_code=404, detail="Audio file not found")


# ============================================================
# Meeting Bot Endpoints (Recall.ai Integration)
# ============================================================

from pydantic import BaseModel
from app.services.recall_service import recall_service
from app.core.config import settings


class JoinMeetingRequest(BaseModel):
    meeting_url: str
    platform: str  # "zoom", "google_meet", "teams"
    bot_name: Optional[str] = "Futurist AI Notetaker"


# Store active bots for status tracking
active_bots = {}


@router.post("/recordings/join-meeting")
async def join_meeting(request: JoinMeetingRequest):
    """
    Send an AI agent to join a meeting and record it.
    
    Supported platforms:
    - Zoom
    - Google Meet
    - Microsoft Teams
    """
    # Validate API key is configured
    if not settings.RECALL_API_KEY:
        raise HTTPException(
            status_code=503,
            detail="Meeting bot service not configured. Please set RECALL_API_KEY."
        )
    
    # Validate platform
    valid_platforms = ["zoom", "google_meet", "teams"]
    if request.platform not in valid_platforms:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid platform. Supported: {', '.join(valid_platforms)}"
        )
    
    try:
        # Create bot via Recall.ai
        bot_data = await recall_service.create_bot(
            meeting_url=request.meeting_url,
            bot_name=request.bot_name or "Futurist AI Notetaker"
        )
        
        bot_id = bot_data.get("id")
        
        # Store bot info for tracking
        active_bots[bot_id] = {
            "id": bot_id,
            "meeting_url": request.meeting_url,
            "platform": request.platform,
            "status": "joining",
            "created_at": datetime.utcnow().isoformat()
        }
        
        logger.info(f"Created meeting bot: {bot_id} for {request.platform}")
        
        return {
            "success": True,
            "bot_id": bot_id,
            "status": "joining",
            "message": f"AI agent is joining the {request.platform} meeting"
        }
        
    except Exception as e:
        logger.error(f"Failed to create meeting bot: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to send agent: {str(e)}"
        )


@router.get("/recordings/bots/{bot_id}")
async def get_bot_status(bot_id: str):
    """Get the status of a meeting bot."""
    try:
        bot_data = await recall_service.get_bot(bot_id)
        
        # Map Recall.ai status to our status
        status_map = {
            "ready": "waiting",
            "joining_call": "joining",
            "in_call_not_recording": "in_meeting",
            "in_call_recording": "recording",
            "call_ended": "processing",
            "done": "completed",
            "fatal": "error"
        }
        
        recall_status = bot_data.get("status", "unknown")
        our_status = status_map.get(recall_status, recall_status)
        
        return {
            "bot_id": bot_id,
            "status": our_status,
            "recall_status": recall_status,
            "meeting_url": bot_data.get("meeting_url"),
            "video_url": bot_data.get("video_url"),
            "recording_id": bot_data.get("recording_id")
        }
        
    except Exception as e:
        logger.error(f"Failed to get bot status: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get bot status: {str(e)}"
        )


@router.post("/recordings/bots/{bot_id}/leave")
async def leave_meeting(bot_id: str):
    """Instruct the bot to leave the meeting."""
    try:
        success = await recall_service.leave_meeting(bot_id)
        
        if success:
            return {"success": True, "message": "Bot is leaving the meeting"}
        else:
            raise HTTPException(status_code=500, detail="Failed to leave meeting")
            
    except Exception as e:
        logger.error(f"Failed to leave meeting: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to leave meeting: {str(e)}"
        )


@router.get("/recordings/bots")
async def list_active_bots():
    """List all active meeting bots."""
    return list(active_bots.values())


from fastapi import APIRouter, Request, Response, HTTPException
from telegram import Update
from app.bot.loader import create_bot_app
from app.core.config import settings
from app.services.recall_service import recall_service
from app.services.ai_service import ai_service
from app.services.asana_client import asana_service
import httpx
import logging

logger = logging.getLogger(__name__)

router = APIRouter()
bot_app = create_bot_app()

@router.post("/bot/webhook")
async def telegram_webhook(request: Request):
    """
    Handle incoming Telegram updates via webhook
    """
    try:
        data = await request.json()
        logger.info(f"Received webhook data: {data}")
        update = Update.de_json(data, bot_app.bot)
        
        # Process update
        # Process update
        await bot_app.process_update(update)
        
        return Response(status_code=200)
    except Exception as e:
        print(f"Error processing webhook: {e}")
        return Response(status_code=500)

@router.get("/health")
async def health_check():
    return {"status": "healthy"}

@router.post("/webhook/recall")
async def recall_webhook(request: Request):
    """
    Webhook endpoint for Recall.ai events.
    Handles: bot.status_change, recording.ready
    """
    try:
        payload = await request.json()
        event_type = payload.get("event", {}).get("type")
        data = payload.get("data", {})
        
        logger.info(f"Received Recall webhook: {event_type}")
        
        if event_type == "bot.status_change":
            bot_id = data.get("bot_id")
            status = data.get("status")
            logger.info(f"Bot {bot_id} status: {status}")
            
        elif event_type == "recording.ready":
            bot_id = data.get("bot_id")
            logger.info(f"Recording ready for bot {bot_id}")
            
            # Delegate to MeetingProcessingService
            from app.services.meeting_processing_service import meeting_processing_service
            await meeting_processing_service.process_meeting(bot_id, data)
    
        return {"status": "success"}
        
    except Exception as e:
        logger.error(f"Error processing Recall webhook: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/bot/set-webhook")
async def set_webhook():
    """
    Manually set webhook (for testing/setup)
    """
    if not settings.TELEGRAM_WEBHOOK_URL:
        return {"error": "TELEGRAM_WEBHOOK_URL not set in .env"}
    
    webhook_url = settings.TELEGRAM_WEBHOOK_URL
    success = await bot_app.bot.set_webhook(webhook_url)
    
    return {
        "success": success,
        "webhook_url": webhook_url
    }

from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    APP_NAME: str = "AI-Ops Manager Bot"
    DEBUG: bool = True
    API_V1_STR: str = "/api/v1"
    SECRET_KEY: str

    POSTGRES_USER: str
    POSTGRES_PASSWORD: str
    POSTGRES_SERVER: str
    POSTGRES_DB: str
    DATABASE_URL: str

    REDIS_URL: str

    TELEGRAM_BOT_TOKEN: str
    TELEGRAM_WEBHOOK_URL: Optional[str] = None
    CEO_TELEGRAM_ID: int
    ASSISTANT_TELEGRAM_ID: int

    OPENAI_API_KEY: str

    ASANA_ACCESS_TOKEN: str
    ASANA_WORKSPACE_GID: str
    ASANA_INBOX_PROJECT_GID: str
    ASANA_UNPROCESSED_SECTION_GID: str
    ASANA_PROJECT_FIELD_GID: Optional[str] = None
    ASANA_DEPARTMENTS_PROJECT_GID: Optional[str] = None
    ASANA_DEFAULT_ASSIGNEE_GID: Optional[str] = None
    ASANA_DEPARTMENTS_UNPROCESSED_SECTION_GID: Optional[str] = None
    
    # Recall.ai
    RECALL_API_KEY: str = ""
    RECALL_WEBHOOK_SECRET: str = ""
    
    # Google Calendar & Drive & Sheets
    GOOGLE_CLIENT_ID: str = ""
    GOOGLE_CLIENT_SECRET: str = ""
    GOOGLE_REDIRECT_URI: Optional[str] = None
    GOOGLE_DRIVE_FOLDER_ID: str = "" # Deprecated
    DRIVE_RECORDINGS_ID: str = ""
    DRIVE_TRANSCRIPTS_ID: str = ""
    DRIVE_PROTOCOLS_ID: str = ""
    DRIVE_TASKS_ID: str = ""
    EXAMPLE_PROTOCOL_DRIVE_ID: str = "1EDfml1TuqAyASlXXwNuJrIVpN6vWk6qb" # From user provided URL
    GOOGLE_SHEETS_ID: str = ""
    
    # Zoom
    ZOOM_PERSONAL_LINK: str = ""
    
    # Anthropic
    # ANTHROPIC_API_KEY: str = "" # Deprecated
    
    # Gemini
    GEMINI_API_KEY: str = ""

    # Soniox
    SONIOX_API_KEY: str = ""

    class Config:
        env_file = ".env"
        extra = "ignore"

settings = Settings()

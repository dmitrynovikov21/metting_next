from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from app.api.main_router import router as api_router, bot_app

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    print("Starting up AI-Ops Manager Bot...")
    await bot_app.initialize()
    await bot_app.start()
    yield
    # Shutdown
    print("Shutting down AI-Ops Manager Bot...")
    await bot_app.stop()
    await bot_app.shutdown()

app = FastAPI(
    title="AI-Ops Manager Bot",
    description="API for AI-Ops Manager Bot",
    version="0.1.0",
    lifespan=lifespan
)

# Add CORS for direct frontend uploads
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from fastapi.staticfiles import StaticFiles
import os

app.include_router(api_router, prefix="/api/v1")
from app.api.endpoints import recordings
app.include_router(recordings.router, prefix="/api/v1", tags=["recordings"])

# Mount frontend static files
frontend_dist = os.path.join(os.path.dirname(os.path.dirname(__file__)), "frontend", "dist")
if os.path.exists(frontend_dist):
    app.mount("/app", StaticFiles(directory=frontend_dist, html=True), name="frontend")
else:
    print(f"Frontend dist not found at {frontend_dist}")

@app.get("/health")
async def health_check():
    return {"status": "ok", "service": "ai-ops-manager-bot"}

@app.get("/")
async def root():
    return {"message": "AI-Ops Manager Bot is running"}

@app.get("/auth/google/callback")
async def google_auth_callback(code: str):
    """
    Handle Google OAuth callback.
    Display the code to the user so they can copy-paste it to the bot.
    """
    html_content = f"""
    <html>
        <head>
            <title>Google Auth Successful</title>
            <style>
                body {{ font-family: sans-serif; text-align: center; padding: 50px; }}
                .code {{ background: #f0f0f0; padding: 20px; font-size: 24px; border-radius: 10px; margin: 20px auto; max-width: 600px; word-break: break-all; }}
                button {{ padding: 10px 20px; font-size: 18px; cursor: pointer; background: #007bff; color: white; border: none; border-radius: 5px; }}
            </style>
        </head>
        <body>
            <h1>✅ Authorization Successful!</h1>
            <p>Please copy the code below and send it to the bot:</p>
            <div class="code" id="auth-code">{code}</div>
            <button onclick="copyCode()">Copy Code</button>
            
            <script>
                function copyCode() {{
                    var code = document.getElementById("auth-code").innerText;
                    navigator.clipboard.writeText(code).then(function() {{
                        alert("Copied to clipboard!");
                    }});
                }}
            </script>
        </body>
    </html>
    """
    from fastapi.responses import HTMLResponse
    return HTMLResponse(content=html_content, status_code=200)

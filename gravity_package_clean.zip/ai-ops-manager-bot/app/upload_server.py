"""
Dedicated Upload Server for Large Files
Runs on port 8001 with CORS enabled for direct browser uploads
"""
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import shutil
import os
import uuid
import json
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Upload Server", description="Large file upload endpoint")

# CORS for direct frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Storage configuration
UPLOAD_DIR = "storage/uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Shared status tracking (in-memory for now)
recording_status = {}


@app.post("/upload")
async def upload_large_file(
    file: UploadFile = File(...),
    language: str = "ru"
):
    """
    Upload endpoint for large files.
    Saves file and triggers processing via main API.
    """
    try:
        recording_id = str(uuid.uuid4())
        file_extension = file.filename.split(".")[-1] if "." in file.filename else "m4a"
        file_path = f"{UPLOAD_DIR}/{recording_id}.{file_extension}"
        
        # Save file with progress logging
        file_size = 0
        with open(file_path, "wb") as buffer:
            while chunk := await file.read(1024 * 1024):  # 1MB chunks
                buffer.write(chunk)
                file_size += len(chunk)
                if file_size % (10 * 1024 * 1024) == 0:  # Log every 10MB
                    logger.info(f"Received {file_size / (1024*1024):.1f} MB...")
        
        logger.info(f"File saved: {file_path} ({file_size / (1024*1024):.1f} MB)")
        
        # Check if file is too small
        if file_size < 1024:
            os.remove(file_path)
            raise HTTPException(status_code=400, detail="Recording is too short or empty")
        
        # Initialize status
        recording_status[recording_id] = {
            "status": "processing",
            "filename": file.filename,
            "created_at": datetime.utcnow().isoformat(),
            "file_path": file_path,
            "language": language
        }
        
        # Trigger processing via main API (async)
        import httpx
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                # Notify main API to process this recording
                await client.post(
                    "http://127.0.0.1:8000/api/v1/recordings/process",
                    json={
                        "recording_id": recording_id,
                        "file_path": file_path,
                        "filename": file.filename,
                        "language": language
                    }
                )
        except Exception as e:
            logger.warning(f"Could not notify main API: {e}")
            # Processing will be handled by the main API when it polls for new files
        
        return {
            "recording_id": recording_id,
            "status": "queued",
            "message": "File uploaded successfully. Processing started.",
            "file_size_mb": round(file_size / (1024 * 1024), 2)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Upload failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/status/{recording_id}")
async def get_status(recording_id: str):
    """Check processing status"""
    if recording_id in recording_status:
        return recording_status[recording_id]
    
    # Check if transcript exists
    transcript_path = f"{UPLOAD_DIR}/{recording_id}_transcript.json"
    if os.path.exists(transcript_path):
        return {"status": "completed", "recording_id": recording_id}
    
    return {"status": "unknown", "recording_id": recording_id}


@app.get("/health")
async def health():
    return {"status": "ok", "service": "upload-server", "port": 8001}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)

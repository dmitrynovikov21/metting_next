from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes, JobQueue
from app.core.config import settings
from app.services.asana_client import asana_service
from app.services.ai_service import ai_service
from app.services.context_manager import context_manager
from app.services.google_calendar_service import google_calendar_service
import logging
import os
from app.db.base import AsyncSessionLocal
from app.services.user_service import get_user_by_telegram_id, get_user_by_name
from app.services.recall_service import recall_service
from app.db.models import DailyReport
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload
import datetime
import json
import asyncio
import random

import logging

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

from telegram.ext import ConversationHandler

# Registration States
REGISTER_NAME, REGISTER_POSITION = range(2)

async def check_bot_status_job(context: ContextTypes.DEFAULT_TYPE):
    """Job to poll bot status and trigger processing"""
    job = context.job
    bot_id = job.data.get('bot_id')
    chat_id = job.data.get('chat_id')
    message_id = job.data.get('message_id')
    
    logger.info(f"Polling status for bot {bot_id}...")
    
    try:
        # Check status
        bot_info = await recall_service.get_bot(bot_id)
        # Get latest status code
        status_changes = bot_info.get('status_changes', [])
        current_status = status_changes[-1].get('code') if status_changes else None
        
        logger.info(f"Bot {bot_id} status: {current_status}")
        
        if current_status in ['done', 'recording_done']:
             from app.services.meeting_processing_service import meeting_processing_service
             # Pass bot_info as data to avoid re-fetching
             # Extract video_url and duration
             data = {}
             recordings = bot_info.get('recordings', [])
             if recordings:
                 last_rec = recordings[-1]
                 video_mixed = last_rec.get('media_shortcuts', {}).get('video_mixed', {})
                 data['video_url'] = video_mixed.get('data', {}).get('download_url')
                 
                 # Duration
                 start = last_rec.get('started_at')
                 end = last_rec.get('completed_at')
                 if start and end:
                     from dateutil import parser
                     s = parser.parse(start)
                     e = parser.parse(end)
                     data['duration'] = (e - s).total_seconds()
             
             success = await meeting_processing_service.process_meeting(bot_id, data)
             if success:
                 logger.info(f"Polling successful for {bot_id}. Removing job.")
                 job.schedule_removal()
                 # Update the "Waiting..." message
                 try:
                     await context.bot.edit_message_text(
                         chat_id=chat_id, 
                         message_id=message_id, 
                         text="✅ **Обработка завершена!**\n(См. новое сообщение)",
                         parse_mode="Markdown"
                     )
                 except Exception as e:
                     logger.warning(f"Failed to edit message: {e}")
                     
    except Exception as e:
        logger.error(f"Polling error for {bot_id}: {e}")

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    
    # Check if user exists in DB
    async with AsyncSessionLocal() as session:
        db_user = await get_user_by_telegram_id(session, user.id)
        
    # If user exists and is approved, show main menu
    if db_user and db_user.status == 'approved':
        # Animated typing indicator
        await context.bot.send_chat_action(chat_id=update.effective_chat.id, action="typing")
        await asyncio.sleep(0.5)
        
        # Get Web App URL
        if settings.TELEGRAM_WEBHOOK_URL and "your-domain.com" not in settings.TELEGRAM_WEBHOOK_URL:
            from urllib.parse import urlparse
            parsed = urlparse(settings.TELEGRAM_WEBHOOK_URL)
            base_url = f"{parsed.scheme}://{parsed.netloc}"
            web_app_url = f"{base_url}/app"
        else:
            web_app_url = "https://google.com" # Placeholder

        from telegram import WebAppInfo

            # Persistent Reply Keyboard
        keyboard = [
            [KeyboardButton("📝 Отчет"), KeyboardButton("📞 Задачи")],
            [KeyboardButton("📊 Меню"), KeyboardButton("📋 Дайджест")],
            [KeyboardButton("⚙️ Настройки")]
        ]
        
        # Add Admin Button
        if db_user.role in ['admin', 'ceo'] or user.id == settings.CEO_TELEGRAM_ID:
            keyboard.append([KeyboardButton("👥 Сотрудники")])
            
        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
        
        # Animated welcome message
        greetings = [
            f"👋 Привет, {user.first_name}!",
            "✨ Загружаю интерфейс...",
            "🚀 Готово!"
        ]
        
        msg = await update.message.reply_text(greetings[0])
        await asyncio.sleep(0.4)
        await msg.edit_text(greetings[1])
        await asyncio.sleep(0.6)
        
        # Final message with menu
        await msg.delete() # Delete loading message to clean up
        await update.message.reply_text(
            f"👋 Привет, {user.first_name}!\n\n"
            "Я твой **AI-Ops Manager**. Я помогаю управлять задачами, встречами и отчетами.\n"
            "━━━━━━━━━━━━━━━\n\n"
            "👇 **Используйте меню внизу экрана:**",
            reply_markup=reply_markup,
            parse_mode="Markdown"
        )
        return ConversationHandler.END

    # If user exists but pending
    if db_user and db_user.status == 'pending':
        await update.message.reply_text("⏳ Ваша заявка на рассмотрении администратора.")
        return ConversationHandler.END
        
    # If user exists but rejected
    if db_user and db_user.status == 'rejected':
        await update.message.reply_text("⛔ Ваша заявка была отклонена.")
        return ConversationHandler.END

    # New User -> Start Registration
    await update.message.reply_text(
        f"👋 Привет, {user.first_name}!\n\n"
        "Я не нашел вас в базе сотрудников.\n"
        "Давайте зарегистрируемся.\n\n"
        "✍️ **Введите ваши Имя и Фамилию:**"
    )
    return REGISTER_NAME

async def handle_register_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle name input"""
    name = update.message.text
    context.user_data['reg_name'] = name
    
    await update.message.reply_text(
        f"Приятно познакомиться, {name}!\n\n"
        "💼 **Теперь укажите вашу должность:**"
    )
    return REGISTER_POSITION

async def handle_register_position(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle position input and notify admin"""
    position = update.message.text
    name = context.user_data.get('reg_name')
    user = update.effective_user
    
    # Create User in DB (Pending)
    async with AsyncSessionLocal() as session:
        from app.db.models import User
        new_user = User(
            telegram_id=user.id,
            full_name=name,
            position=position,
            role="employee", # Default
            status="pending",
            asana_gid="temp", # Placeholder
            language="ru"
        )
        session.add(new_user)
        await session.commit()
        
    await update.message.reply_text(
        "✅ **Заявка отправлена!**\n\n"
        "Администратор рассмотрит её в ближайшее время.\n"
        "Я пришлю уведомление, когда доступ будет открыт."
    )
    
    # Notify Admin (CEO)
    if settings.CEO_TELEGRAM_ID:
        keyboard = [
            [InlineKeyboardButton("✅ Одобрить", callback_data=f"admin_approve_{user.id}"),
             InlineKeyboardButton("❌ Отклонить", callback_data=f"admin_reject_{user.id}")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await context.bot.send_message(
            chat_id=settings.CEO_TELEGRAM_ID,
            text=f"🔔 **Новая заявка на регистрацию**\n\n"
                 f"👤 **Имя:** {name}\n"
                 f"💼 **Должность:** {position}\n"
                 f"🆔 Telegram ID: `{user.id}`",
            reply_markup=reply_markup,
            parse_mode="Markdown"
        )
        
    return ConversationHandler.END

async def admin_decision_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle Admin Approve/Reject"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    action, user_id = data.split('_')[1], int(data.split('_')[2])
    
    if action == "reject":
        # Update DB
        async with AsyncSessionLocal() as session:
            db_user = await get_user_by_telegram_id(session, user_id)
            if db_user:
                db_user.status = 'rejected'
                await session.commit()
                
        await query.edit_message_text(f"❌ Заявка отклонена.")
        
        # Notify User
        try:
            await context.bot.send_message(chat_id=user_id, text="⛔ Ваша заявка на регистрацию была отклонена.")
        except:
            pass
            
    elif action == "approve":
        # Show Department Selection
        keyboard = []
        for name, gid in SECTION_MAPPING.items():
            # Use a shorter callback data to avoid limit
            # admin_dept_{user_id}_{short_name}
            short_name = name.split()[0]
            keyboard.append([InlineKeyboardButton(name, callback_data=f"adm_dept_{user_id}_{short_name}")])
            
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(f"✅ Заявка одобрена.\n📂 **Выберите отдел для сотрудника:**", reply_markup=reply_markup, parse_mode="Markdown")

async def admin_dept_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle Department Selection"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    # adm_dept_{user_id}_{short_name}
    parts = data.split('_')
    user_id = int(parts[2])
    dept_short = parts[3]
    
    # Find full department name/GID
    dept_name = dept_short
    dept_gid = None
    for name, gid in SECTION_MAPPING.items():
        if name.startswith(dept_short):
            dept_name = name
            dept_gid = gid
            break
            
    # Update DB with Department
    async with AsyncSessionLocal() as session:
        db_user = await get_user_by_telegram_id(session, user_id)
        if db_user:
            db_user.department = dept_name
            # We might want to store the GID too if we had a column, but mapping is in code
            await session.commit()
            
    # Ask for Role
    keyboard = [
        [InlineKeyboardButton("Сотрудник", callback_data=f"adm_role_{user_id}_employee")],
        [InlineKeyboardButton("Менеджер", callback_data=f"adm_role_{user_id}_manager")],
        [InlineKeyboardButton("Админ", callback_data=f"adm_role_{user_id}_admin")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(f"📂 Отдел: **{dept_name}**\n👤 **Выберите роль:**", reply_markup=reply_markup, parse_mode="Markdown")

async def admin_role_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle Role Selection and Finalize"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    # adm_role_{user_id}_{role}
    parts = data.split('_')
    user_id = int(parts[2])
    role = parts[3]
    
    # Finalize User
    async with AsyncSessionLocal() as session:
        db_user = await get_user_by_telegram_id(session, user_id)
        if db_user:
            db_user.role = role
            db_user.status = 'approved'
            
            # Try to find Asana GID by name (auto-link)
            # This is a best-effort attempt
            # In a real scenario, we might ask for email or use Asana search
            # For now, keep "temp" or try to search
            try:
                found_user = asana_service.find_user_by_name(db_user.full_name)
                if found_user:
                     db_user.asana_gid = found_user['gid']
            except:
                pass
                
            await session.commit()
            
            user_name = db_user.full_name
            dept = db_user.department

    await query.edit_message_text(
        f"✅ **Сотрудник добавлен!**\n\n"
        f"👤 {user_name}\n"
        f"📂 {dept}\n"
        f"🔑 {role}\n"
        f"✅ Статус: Approved"
    )
    
    # Notify User
    try:
        await context.bot.send_message(
            chat_id=user_id, 
            text="🎉 **Поздравляем!**\n\n"
                 "Ваша учетная запись подтверждена.\n"
                 "Нажмите /start чтобы начать работу."
        )
    except:
        pass
    
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /help command"""
    await update.message.reply_text(
        "🤖 **Команды бота:**\n\n"
        "/start - Перезапустить бота\n"
        "/tasks - Мои задачи\n"
        "/report - Отправить отчет\n"
        "/help - Показать это сообщение"
    )

async def report_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /report command"""
    await update.message.reply_text(
        "📝 **Ежедневный отчет**\n\n"
        "Просто отправьте мне **голосовое сообщение**, начав со слова **'Отчет'**.\n"
        "Или напишите текст: 'Отчет: сделал то-то...'"
    )

from app.services.asana_client import asana_service
from app.services.ai_service import ai_service
import os

# Project Field Options Mapping
PROJECT_OPTIONS = {
    "Общая группа": "1212001658029870",
    "Бухгалтерия/кадры внутри": "1212001658029871",
    "Бухгалтерия Аутсорс": "1212001658029872",
    "Консалтинг": "1212001658029873",
    "Бизнес-центр": "1212001658029874",
    "Клиринг": "1212001658029875",
    "Закупки и логистика": "1212001658029876",
    "Акселератор": "1212001658029877",
    "Платформа": "1212001658029878"
}

# Mapping of names/keywords to Section GIDs in "Задачи отделов"
SECTION_MAPPING = {
    "Кирилл А": "1212001568871795",
    "Радмир": "1212001568871802",
    "Кирилл Карпенко": "1212001568871805",
    "Мейрас": "1212001568871831",
    "Амалия": "1212001568871834",
    "Александр": "1212001568871835",
    "Константин": "1212001568871839",
    "Екатерина": "1212001568871820",
    "Елена": "1212001568871792",
    "Виолетта": "1212001566672438",
    "Violetta": "1212001566672438"
}

async def handle_button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle button presses with smooth animations"""
    query = update.callback_query
    await query.answer()
    
    action = query.data
    
    # Animated loading
    loading_frames = ["⏳", "⌛️", "✨"]
    
    if action == "action_report":
        # Smooth transition
        for frame in loading_frames:
            await query.edit_message_text(f"{frame} Загрузка...")
            await asyncio.sleep(0.2)
        
        await query.edit_message_text(
            "📝 **Отправить отчет**\n"
            "━━━━━━━━━━━━━━━\n\n"
            "🎤 **Голосовое сообщение**\n"
            "Начните со слова 'Отчет'\n\n"
            "⌨️ **Текстом**\n"
            "Используйте команду `/report`\n\n"
            "💡 *Совет: Голосовые отчеты обрабатываются быстрее*",
            parse_mode="Markdown"
        )
        
    elif action == "action_zoom":
        for frame in loading_frames:
            await query.edit_message_text(f"{frame} Подготовка...")
            await asyncio.sleep(0.2)
            
        await query.edit_message_text(
            "🎬 **Записать Zoom встречу**\n"
            "━━━━━━━━━━━━━━━\n\n"
            "📎 Отправьте ссылку:\n"
            "`/zoom https://zoom.us/j/123`\n\n"
            "🤖 Бот автоматически:\n"
            "  ✓ Присоединится к встрече\n"
            "  ✓ Запишет и расшифрует\n"
            "  ✓ Создаст задачи\n\n"
            "💎 *Стоимость: $0.70/час*",
            parse_mode="Markdown"
        )
        
    elif action == "action_tasks":
        # Animated loading bar
        progress_msg = await query.edit_message_text("🔄 Загружаю задачи из Asana...")
        
        # Constants for Denis Zaitsev Project
        SECTION_IN_PROGRESS = "1212001568871816"
        CUSTOM_FIELD_PRIORITY = "1212086276484640"
        
        # Fetch tasks from "In Progress" section
        tasks = asana_service.get_tasks_by_section(SECTION_IN_PROGRESS)
        
        if not tasks:
            await progress_msg.edit_text("📭 **В работе пусто!**\nОтличная работа. 🌴")
        else:
            # Sort by Priority N (Custom Field)
            def get_priority(task):
                for cf in task.get('custom_fields', []):
                    if cf['gid'] == CUSTOM_FIELD_PRIORITY:
                        return cf.get('number_value') or 0
                return 0
                
            # Sort descending (10 -> 1)
            tasks.sort(key=get_priority, reverse=True)
            
            # Format response
            response = ["📋 **В работе:**\n"]
            
            priority_emojis = {
                10: "🔟", 9: "9️⃣", 8: "8️⃣", 7: "7️⃣", 6: "6️⃣",
                5: "5️⃣", 4: "4️⃣", 3: "3️⃣", 2: "2️⃣", 1: "1️⃣"
            }
            
            for task in tasks[:15]: # Limit to 15
                priority = get_priority(task)
                emoji = priority_emojis.get(int(priority), "🔹") if priority else "🔹"
                
                name = task.get('name', 'Без названия')
                url = task.get('permalink_url', '')
                response.append(f"{emoji} [{name}]({url})")
                
            keyboard = [
                [InlineKeyboardButton("📥 Входящие", callback_data="tasks_inbox"),
                 InlineKeyboardButton("⏳ Ожидание", callback_data="tasks_waiting")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
                
            await progress_msg.edit_text("\n".join(response), parse_mode="Markdown", reply_markup=reply_markup)
        
    elif action == "action_stats":
        # Animated stats loading
        stats_frames = [
            "📊 Собираю данные...",
            "📈 Анализирую метрики...",
            "🎯 Готово!"
        ]
        
        for frame in stats_frames:
            await query.edit_message_text(frame)
            await asyncio.sleep(0.4)
        
        await query.edit_message_text(
            "📊 **Персональная статистика**\n"
            "━━━━━━━━━━━━━━━\n\n"
            "📝 Отчетов за неделю: `12`\n"
            "✅ Задач выполнено: `47`\n"
            "⚡️ Продуктивность: `+23%`\n"
            "🔥 Текущая серия: `5 дней`\n\n"
            "💎 *Mini App с графиками в разработке*",
            parse_mode="Markdown"
        )
        
    elif action == "action_digest":
        # Smooth transition
        await query.edit_message_text("✨ Генерирую дайджест...")
        await asyncio.sleep(0.5)
        
        await query.edit_message_text(
            "📋 **Дайджест за сегодня**\n"
            "━━━━━━━━━━━━━━━\n\n"
            "👥 Отчеты получены: `8/10`\n"
            "✅ Задач завершено: `23`\n"
            "🚩 Блокеров: `2`\n\n"
            "🎯 Используйте `/digest` для полной сводки",
            parse_mode="Markdown"
        )
        
    elif action == "action_settings":
        await query.edit_message_text("⚙️ Загрузка настроек...")
        await asyncio.sleep(0.4)
        
        settings_keyboard = [
            [InlineKeyboardButton("🔔 Уведомления: ✅", callback_data="toggle_notifications")],
            [InlineKeyboardButton("🌍 Часовой пояс: Dubai", callback_data="change_timezone")],
            [InlineKeyboardButton("🗣️ Язык: Русский", callback_data="change_language")],
            [InlineKeyboardButton("« Назад в меню", callback_data="back_to_menu")]
        ]
        settings_markup = InlineKeyboardMarkup(settings_keyboard)
        
        await query.edit_message_text(
            "⚙️ **Настройки**\n"
            "━━━━━━━━━━━━━━━\n\n"
            "Выберите параметр для изменения:",
            reply_markup=settings_markup,
            parse_mode="Markdown"
        )
    
    elif action == "back_to_menu":
        # Recreate main menu
        keyboard = [
            [InlineKeyboardButton("📝 Отправить отчет", callback_data="action_report")],
            [InlineKeyboardButton("🎬 Записать Zoom встречу", callback_data="action_zoom")],
            [InlineKeyboardButton("📞 Мои задачи", callback_data="action_tasks"),
             InlineKeyboardButton("📊 Статистика", callback_data="action_stats")],
            [InlineKeyboardButton("📋 Дайджест", callback_data="action_digest"),
             InlineKeyboardButton("⚙️ Настройки", callback_data="action_settings")],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "✨ **AI-Ops Manager Bot**\n"
            "━━━━━━━━━━━━━━━\n"
            "🎯 Помогаю управлять задачами\n"
            "📊 Отслеживаю прогресс\n"
            "🤖 Автоматизирую рутину\n\n"
            "💎 **Выберите действие:**",
            reply_markup=reply_markup,
            parse_mode="Markdown"
        )

async def check_asana_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /check_asana command"""
    await update.message.reply_text("⏳ Проверяю подключение к Asana...")
    
    is_connected = asana_service.check_connection()
    
    if is_connected:
        await update.message.reply_text("✅ **Asana подключена успешно!**\nЯ вижу ваше рабочее пространство.")
    else:
        await update.message.reply_text("❌ **Ошибка подключения к Asana**\nПроверьте токен и настройки.")

async def tasks_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /tasks command - Enhanced for Denis Zaitsev"""
    user = update.effective_user
    
    # Constants for Denis Zaitsev Project
    SECTION_IN_PROGRESS = "1212001568871816"
    SECTION_INBOX = "1212001568871810"
    SECTION_WAITING = "1212001568871813"
    CUSTOM_FIELD_PRIORITY = "1212086276484640"
    
    await update.message.reply_text("⏳ Загружаю задачи (В работе)...")
    
    # Fetch tasks from "In Progress" section
    tasks = asana_service.get_tasks_by_section(SECTION_IN_PROGRESS)
    
    if not tasks:
        await update.message.reply_text("📭 **В работе пусто!**\nОтличная работа. 🌴")
    else:
        # Sort by Priority N (Custom Field)
        def get_priority(task):
            for cf in task.get('custom_fields', []):
                if cf['gid'] == CUSTOM_FIELD_PRIORITY:
                    return cf.get('number_value') or 0
            return 0
            
        # Sort descending (10 -> 1)
        tasks.sort(key=get_priority, reverse=True)
        
        # Format response
        response = ["📋 **В работе:**\n"]
        
        priority_emojis = {
            10: "🔟", 9: "9️⃣", 8: "8️⃣", 7: "7️⃣", 6: "6️⃣",
            5: "5️⃣", 4: "4️⃣", 3: "3️⃣", 2: "2️⃣", 1: "1️⃣"
        }
        
        for task in tasks[:15]: # Limit to 15
            priority = get_priority(task)
            emoji = priority_emojis.get(int(priority), "🔹") if priority else "🔹"
            
            name = task.get('name', 'Без названия')
            url = task.get('permalink_url', '')
            response.append(f"{emoji} [{name}]({url})")
            
        keyboard = [
            [InlineKeyboardButton("📥 Входящие", callback_data="tasks_inbox"),
             InlineKeyboardButton("⏳ Ожидание", callback_data="tasks_waiting")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
            
        await update.message.reply_text("\n".join(response), parse_mode="Markdown", reply_markup=reply_markup)

async def tasks_inbox_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle Inbox button"""
    query = update.callback_query
    await query.answer()
    
    SECTION_INBOX = "1212001568871810"
    
    await query.edit_message_text("⏳ Загружаю Входящие...")
    tasks = asana_service.get_tasks_by_section(SECTION_INBOX)
    
    if not tasks:
        msg = "📭 **Входящие пусты!**"
    else:
        response = ["📥 **Входящие:**\n"]
        for task in tasks[:15]:
            name = task.get('name', 'Без названия')
            url = task.get('permalink_url', '')
            response.append(f"🔹 [{name}]({url})")
        msg = "\n".join(response)
    
    keyboard = [
        [InlineKeyboardButton("⚡️ В работе", callback_data="action_tasks"), # Re-uses action_tasks which calls tasks_command logic via button
         InlineKeyboardButton("⏳ Ожидание", callback_data="tasks_waiting")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=reply_markup)

async def tasks_waiting_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle Waiting button"""
    query = update.callback_query
    await query.answer()
    
    SECTION_WAITING = "1212001568871813"
    
    await query.edit_message_text("⏳ Загружаю Ожидание...")
    tasks = asana_service.get_tasks_by_section(SECTION_WAITING)
    
    if not tasks:
        msg = "📭 **Ожидание пусто!**"
    else:
        response = ["⏳ **Ожидание:**\n"]
        for task in tasks[:15]:
            name = task.get('name', 'Без названия')
            url = task.get('permalink_url', '')
            response.append(f"🔸 [{name}]({url})")
        msg = "\n".join(response)
        
    keyboard = [
        [InlineKeyboardButton("📥 Входящие", callback_data="tasks_inbox"),
         InlineKeyboardButton("⚡️ В работе", callback_data="action_tasks")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=reply_markup)

async def handle_voice_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle voice messages"""
    user = update.effective_user
    logger.info(f"Received voice message from {user.id}")
    
    status_msg = await update.message.reply_text("🎙️ Слушаю и обрабатываю...")
    
    try:
        # 1. Download voice file
        voice_file = await context.bot.get_file(update.message.voice.file_id)
        file_path = f"voice_{user.id}_{update.message.message_id}.ogg"
        await voice_file.download_to_drive(file_path)
        
        # 2. Transcribe
        await status_msg.edit_text("📝 Транскрибирую...")
        text = await ai_service.transcribe_audio(file_path)
        logger.info(f"Transcribed text: {text}")
        
        # Clean up file
        if os.path.exists(file_path):
            os.remove(file_path)
            
            
        # 3. Analyze text
        # Check if it is a report
        if text.lower().strip().startswith("отчет") or "отчет за сегодня" in text.lower():
            await status_msg.edit_text("📊 Анализирую отчет и ищу задачи...")
            
            # Fetch active tasks for context
            active_tasks = []
            async with AsyncSessionLocal() as session:
                db_user = await get_user_by_telegram_id(session, user.id)
                if db_user and db_user.asana_gid and db_user.asana_gid != "temp":
                    active_tasks = asana_service.get_user_tasks(db_user.asana_gid)

            report_data = await ai_service.analyze_report(text, active_tasks)
            
            # Update matched tasks with comments
            updated_count = 0
            updated_names = []
            matched_task_gids = set()
            current_date_str = datetime.date.today().strftime("%d.%m.%Y")
            feedback_items = []
            
            for update_item in report_data.get('task_updates', []):
                task_gid = update_item.get('gid')
                update_text = update_item.get('update_text')
                quality = update_item.get('quality')
                needs_proof = update_item.get('needs_proof')
                
                if task_gid and update_text:
                    matched_task_gids.add(task_gid)
                    comment_text = f"{current_date_str} - {update_text}"
                    if asana_service.add_comment(task_gid, comment_text):
                        updated_count += 1
                        # Find name for reply
                        t_name = next((t['name'] for t in active_tasks if t['gid'] == task_gid), task_gid)
                        updated_names.append(t_name)
                        
                        # Check quality/proof
                        if quality == "vague":
                            feedback_items.append(f"- {t_name}: Слишком коротко. Распишите подробнее или пришлите документ.")
                        elif needs_proof == "video":
                            feedback_items.append(f"- {t_name}: Задача завершена. Пришлите видео-демонстрацию.")
                        elif needs_proof == "document":
                            feedback_items.append(f"- {t_name}: Пришлите ссылку на документ/результат.")

            # Handle MISSING tasks (No progress)
            missing_tasks = [t for t in active_tasks if t['gid'] not in matched_task_gids]
            stale_tasks = []
            
            for task in missing_tasks:
                # Check stories to see if it was already "no progress" recently
                stories = asana_service.get_task_stories(task['gid'])
                # Look for last comment from bot/system with "нет прогресса"
                # Simple check: look at last few stories text
                is_stale = False
                if stories:
                    # Stories are usually returned oldest to newest, so check last
                    last_story = stories[-1]
                    if "нет прогресса" in last_story.get('text', ''):
                        is_stale = True
                
                if is_stale:
                    stale_tasks.append(task['name'])
                
                # Add "No progress" comment
                asana_service.add_comment(task['gid'], f"{current_date_str} - нет прогресса")

            # Create NEW tasks for unmatched items

            # Create NEW tasks for unmatched items
            created_names = []
            user_section_gid = None
            
            # Try to find user's section
            if db_user:
                for name_key, s_gid in SECTION_MAPPING.items():
                    if name_key.lower() in db_user.full_name.lower():
                        user_section_gid = s_gid
                        break
            
            # Fallback to "Unprocessed" if no personal section found
            if not user_section_gid:
                user_section_gid = settings.ASANA_DEPARTMENTS_UNPROCESSED_SECTION_GID

            for new_task_text in report_data.get('new_tasks', []):
                task_name = f"{new_task_text} (уточнить)"
                
                # Determine projects (Departments project)
                target_projects = [settings.ASANA_DEPARTMENTS_PROJECT_GID] if settings.ASANA_DEPARTMENTS_PROJECT_GID else None
                
                new_task = asana_service.create_task(
                    name=task_name,
                    notes=f"Создано автоматически из отчета: {text}",
                    assignee_gid=db_user.asana_gid if db_user else None,
                    projects=target_projects,
                    section=user_section_gid
                )
                if new_task:
                    created_names.append(task_name)

            # Save to DB
            async with AsyncSessionLocal() as session:
                db_user = await get_user_by_telegram_id(session, user.id)
                if db_user:
                    new_report = DailyReport(
                        user_id=db_user.id,
                        report_date=datetime.date.today(),
                        completed_tasks=report_data.get('completed_tasks', []),
                        tomorrow_plans=report_data.get('plans', []),
                        blockers=report_data.get('blockers', []),
                        raw_text=text,
                        sentiment=report_data.get('sentiment', 'Neutral')
                    )
                    session.add(new_report)
                    await session.commit()
            
            completion_msg = ""
            if updated_names:
                completion_msg += "\n📝 **Обновлены задачи:**\n" + "\n".join([f"- {n}" for n in updated_names])
            
            if created_names:
                completion_msg += "\n🆕 **Созданы новые задачи:**\n" + "\n".join([f"- {n}" for n in created_names])

            stale_msg = ""
            if stale_tasks:
                stale_msg = "\n\n❓ **Нет прогресса 2 дня подряд:**\n" + "\n".join([f"- {n} — как дела по этой задаче?" for n in stale_tasks])

            feedback_msg = ""
            if feedback_items:
                feedback_msg = "\n\n⚠️ **Уточнения:**\n" + "\n".join(feedback_items)

            await status_msg.edit_text(
                f"✅ **Отчет принят!**\n\n"
                f"✅ Сделано: {len(report_data.get('completed_tasks', []))}\n"
                f"📅 Планы: {len(report_data.get('plans', []))}\n"
                f"🚩 Блокеры: {len(report_data.get('blockers', []))}\n"
                f"{completion_msg}"
                f"{stale_msg}"
                f"{feedback_msg}\n\n"
                "Спасибо! Отдыхайте. 🌙"
            )
            return

        await status_msg.edit_text("🧠 Анализирую задачу...")
        task_data = await ai_service.analyze_task_request(text)
        
        # 4. Create task in Asana
        # Get user GID from DB
        async with AsyncSessionLocal() as session:
            db_user = await get_user_by_telegram_id(session, user.id)
            
            assignee_gid = None
            assignee_name = "Me"
            
            # Try to find assignee from AI guess
            ai_assignee_guess = task_data.get('assignee_guess')
            is_self_assigned = False
            
            if ai_assignee_guess:
                # Check for self-assignment keywords
                self_keywords = ["я", "мне", "себе", "меня"]
                if any(k in ai_assignee_guess.lower() for k in self_keywords):
                    is_self_assigned = True
                    if db_user and db_user.asana_gid and db_user.asana_gid != "temp":
                        assignee_gid = db_user.asana_gid
                        assignee_name = db_user.full_name
                    else:
                        assignee_gid = asana_service.get_me_gid()
                        assignee_name = "Me (Sender)"
                else:
                    from app.services.user_service import get_user_by_name
                    found_user = await get_user_by_name(session, ai_assignee_guess)
                    if found_user and found_user.asana_gid and found_user.asana_gid != "temp":
                        assignee_gid = found_user.asana_gid
                        assignee_name = found_user.full_name
            
            # Fallback to sender if no specific assignee found
            if not assignee_gid:
                if db_user and db_user.asana_gid and db_user.asana_gid != "temp":
                    assignee_gid = db_user.asana_gid
                    assignee_name = db_user.full_name
                else:
                     # Fallback to Default Assignee (Ekaterina) or Me
                     if settings.ASANA_DEFAULT_ASSIGNEE_GID:
                         assignee_gid = settings.ASANA_DEFAULT_ASSIGNEE_GID
                         assignee_name = "Default (Ekaterina)"
                     else:
                         assignee_gid = asana_service.get_me_gid()
                         assignee_name = "Default (Me)"

        # Determine Project Custom Field
        project_enum = task_data.get('project_enum', 'Общая группа')
        project_gid = PROJECT_OPTIONS.get(project_enum)
        
        custom_fields = {}
        if project_gid and settings.ASANA_PROJECT_FIELD_GID:
            custom_fields[settings.ASANA_PROJECT_FIELD_GID] = project_gid

        # Determine Target Project and Section (Routing)
        target_projects = None
        target_section = None
        
        # Check if assignee maps to a specific section
        if ai_assignee_guess and not is_self_assigned:
            for name_key, section_gid in SECTION_MAPPING.items():
                if name_key.lower() in ai_assignee_guess.lower():
                    # Found a match! Route to "Задачи отделов"
                    if settings.ASANA_DEPARTMENTS_PROJECT_GID:
                        target_projects = [settings.ASANA_DEPARTMENTS_PROJECT_GID]
                        target_section = section_gid
                        project_enum = f"Задачи отделов ({name_key})" # Update display name
                    break
        
        # If self-assigned, force Inbox -> Unprocessed
        if is_self_assigned:
            target_projects = [settings.ASANA_INBOX_PROJECT_GID]
            target_section = settings.ASANA_UNPROCESSED_SECTION_GID
            project_enum = "Входящие (Не разобрано)"
        
        # If no assignee mentioned (and thus no routing yet), route to Departments -> Unprocessed
        elif not ai_assignee_guess and not target_projects:
             if settings.ASANA_DEPARTMENTS_PROJECT_GID and settings.ASANA_DEPARTMENTS_UNPROCESSED_SECTION_GID:
                 target_projects = [settings.ASANA_DEPARTMENTS_PROJECT_GID]
                 target_section = settings.ASANA_DEPARTMENTS_UNPROCESSED_SECTION_GID
                 project_enum = "Задачи отделов (Неразобранное)"

        await status_msg.edit_text(f"🚀 Создаю задачу в Asana...\n👤 Ответственный: {assignee_name}\n📂 Проект: {project_enum}")
        
        new_task = asana_service.create_task(
            name=task_data.get('name'),
            notes=task_data.get('notes', '') + f"\n\nOriginal Voice: {text}",
            assignee_gid=assignee_gid,
            due_on=task_data.get('due_date'),
            custom_fields=custom_fields,
            projects=target_projects,
            section=target_section
        )
        
        # 5. Reply to User
        await status_msg.edit_text(
            f"✅ **Задача создана!**\n\n"
            f"📌 **{new_task['name']}**\n"
            f"📂 **Проект:** {project_enum}\n"
            f"👤 **Ответственный:** {assignee_name}\n"
            f"📅 **Срок:** {task_data.get('due_date') or 'Не указан'}\n"
            f"🔗 [Открыть в Asana]({new_task['permalink_url']})",
            parse_mode="Markdown"
        )

        # 6. Notify Assistant
        if settings.ASSISTANT_TELEGRAM_ID:
            try:
                assistant_msg = (
                    f"🔔 **Новая задача от CEO**\n\n"
                    f"📌 **{new_task['name']}**\n"
                    f"📂 **Проект:** {project_enum}\n"
                    f"👤 **Ответственный:** {assignee_name}\n"
                    f"🔗 [Открыть в Asana]({new_task['permalink_url']})"
                )
                await context.bot.send_message(chat_id=settings.ASSISTANT_TELEGRAM_ID, text=assistant_msg, parse_mode="Markdown")
                logger.info(f"Notification sent to assistant {settings.ASSISTANT_TELEGRAM_ID}")
            except Exception as e:
                logger.error(f"Failed to notify assistant: {e}")

    except Exception as e:
        logger.error(f"Error handling voice message: {e}")
        await update.message.reply_text("❌ Ошибка при обработке голосового сообщения.")

async def handle_audio_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle audio file uploads for meeting transcription"""
    user = update.effective_user
    audio = update.message.audio
    
    status_msg = await update.message.reply_text("🎤 Обрабатываю аудио встречи...")
    
    try:
        # Download audio file
        file = await context.bot.get_file(audio.file_id)
        file_path = f"/tmp/meeting_{user.id}_{audio.file_unique_id}.mp3"
        await file.download_to_drive(file_path)
        
        # Transcribe
        await status_msg.edit_text("📝 Расшифровываю аудио (это может занять время)...")
        transcript = await ai_service.transcribe_audio(file_path)
        
        if not transcript:
            await status_msg.edit_text("❌ Не удалось расшифровать аудио.")
            return
        
        # Analyze meeting
        await status_msg.edit_text("🧠 Анализирую встречу и создаю задачи...")
        meeting_data = await ai_service.analyze_meeting(transcript)
        
        # Create tasks from action items
        created_tasks = []
        async with AsyncSessionLocal() as session:
            for item in meeting_data.get('action_items', []):
                task_name = item.get('task', '')
                assignee_name = item.get('assignee', 'Не указан')
                deadline = item.get('deadline')
                
                if not task_name:
                    continue
                
                # Find assignee
                assignee_gid = None
                if assignee_name and assignee_name != "Не указан":
                    assignee_user = await get_user_by_name(session, assignee_name)
                    if assignee_user:
                        assignee_gid = assignee_user.asana_gid
                
                # Fallback to CEO
                if not assignee_gid:
                    assignee_gid = settings.CEO_TELEGRAM_ID
                
                # Create task
                try:
                    task = asana_service.create_task(
                        name=task_name,
                        notes=f"Задача из встречи\n\nИсполнитель: {assignee_name}\n\nКонтекст:\n{meeting_data.get('summary', '')}",
                        assignee_gid=assignee_gid,
                        due_on=deadline
                    )
                    created_tasks.append(f"✅ {task_name} → {assignee_name}")
                except Exception as e:
                    logger.error(f"Error creating task from meeting: {e}")
        
        # Format protocol
        protocol = f"""📋 **Протокол встречи**

**Краткое содержание:**
{meeting_data.get('summary', 'Нет данных')}

**Обсуждённые темы:**
"""
        for topic in meeting_data.get('topics', []):
            protocol += f"• {topic}\n"
        
        if meeting_data.get('decisions'):
            protocol += "\n**Принятые решения:**\n"
            for decision in meeting_data['decisions']:
                protocol += f"• {decision}\n"
        
        if created_tasks:
            protocol += f"\n**Созданные задачи ({len(created_tasks)}):**\n"
            for task_line in created_tasks:
                protocol += f"{task_line}\n"
        
        await status_msg.edit_text(protocol, parse_mode="Markdown")
        
        # Clean up
        if os.path.exists(file_path):
            os.remove(file_path)
            
    except Exception as e:
        logger.error(f"Error handling audio message: {e}")
        await status_msg.edit_text("❌ Ошибка при обработке аудио встречи.")

async def meeting_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Explain how to use meeting assistant"""
    help_text = """🎤 **Ассистент встреч**

Отправьте мне аудио-файл встречи, и я:
1. Расшифрую содержание
2. Создам протокол (темы, решения)
3. Автоматически создам задачи в Asana

**Как использовать:**
• Запишите встречу на телефон/диктофон
• Отправьте аудио файл в этот чат
• Получите готовый протокол + задачи

**Лимиты:**
• Макс. размер файла: 25 MB
• Формат: MP3, M4A, WAV и др.
"""
    await update.message.reply_text(help_text, parse_mode="Markdown")

async def zoom_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle Zoom meeting link and send Recall bot"""
    user = update.effective_user
    
    # Check if user provided a meeting URL
    if not context.args:
        await update.message.reply_text(
            "🎬 **Отправить бота на встречу**\n\n"
            "Пример: `/zoom https://zoom.us/j/123456789`\n\n"
            "Бот присоединится к встрече, запишет и расшифрует её.\n"
            "После встречи вы получите протокол и задачи.",
            parse_mode="Markdown"
        )
        return
    
    meeting_url = context.args[0]
    
    # Validate URL
    if not any(domain in meeting_url for domain in ["zoom.us", "meet.google.com", "teams.microsoft.com"]):
        await update.message.reply_text(
            "❌ Неверный формат ссылки.\n"
            "Поддерживаются: Zoom, Google Meet, Microsoft Teams"
        )
        return
    
    status_msg = await update.message.reply_text("🔄 Отправляю бота на встречу...")
    
    try:
        # Create Recall bot
        bot_data = await recall_service.create_bot(meeting_url, bot_name="AI Ops Manager Bot")
        bot_id = bot_data.get("id")
        
        await status_msg.edit_text(
            f"✅ **Бот отправлен!**\n\n"
            f"🎬 Bot ID: `{bot_id}`\n\n"
            "Бот присоединится к встрече и начнёт запись.\n"
            "После встречи я отправлю вам протокол.",
            parse_mode="Markdown"
        )
        
        # TODO: Store bot_id with user_id in database for later reference
        
    except Exception as e:
        logger.error(f"Error creating Recall bot: {e}")
        await status_msg.edit_text(
            f"❌ **Ошибка**\n\n"
            f"Не удалось отправить бота.\n"
            f"Проверьте ссылку и API ключ."
        )

async def digest_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Generate and send daily digest (Admin only)"""
    user = update.effective_user
    
    # Check permissions (simple check for now, can be expanded)
    # Allow CEO and Assistant
    allowed_ids = [settings.CEO_TELEGRAM_ID, settings.ASSISTANT_TELEGRAM_ID, 293254961] # + Violetta for testing
    if user.id not in allowed_ids and str(user.id) not in [str(i) for i in allowed_ids]:
         await update.message.reply_text("⛔ У вас нет прав на просмотр сводки.")
         return

    status_msg = await update.message.reply_text("🔄 Собираю отчеты и генерирую сводку...")
    
    try:
        async with AsyncSessionLocal() as session:
            # Fetch reports for today
            today = datetime.date.today()
            # If it's morning (before 12:00), maybe fetch yesterday's reports? 
            # Let's default to TODAY for manual command, or allow /digest yesterday
            
            query = select(DailyReport).options(selectinload(DailyReport.user)).where(DailyReport.report_date == today)
            result = await session.execute(query)
            reports = result.scalars().all()
            
            if not reports:
                await status_msg.edit_text("📭 За сегодня отчетов пока нет.")
                return
                
            digest_text = await ai_service.generate_digest(reports)
            await status_msg.edit_text(digest_text, parse_mode="Markdown")
            
    except Exception as e:
        logger.error(f"Error generating digest: {e}")
        await status_msg.edit_text("❌ Ошибка при генерации сводки.")

async def connect_calendar_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start Google Calendar connection flow"""
    logger.info("Command /connect_calendar received")
    status_msg = await update.message.reply_text("⏳ Инициализация подключения...")
    
    try:
        from app.services.google_calendar_service import google_calendar_service
        logger.info("Service imported")
        
        auth_url = google_calendar_service.get_auth_url()
        logger.info(f"Auth URL generated: {auth_url[:20]}...")
        
        await status_msg.edit_text(
            "🔗 **Подключение Google Calendar**\n\n"
            "Чтобы бот мог видеть ваши встречи и автоматически приходить на них:\n\n"
            f"1. [Нажмите сюда для авторизации]({auth_url})\n"
            "2. Разрешите доступ\n"
            "3. Скопируйте код подтверждения (или перейдите по ссылке)\n\n"
            "⚠️ *Примечание: В режиме разработки может потребоваться ручной ввод кода. Если ссылка не работает, сообщите разработчику.*",
            parse_mode="Markdown"
        )
    except ValueError as e:
        logger.error(f"Configuration error: {e}")
        await status_msg.edit_text(
            "❌ **Ошибка конфигурации**\n\n"
            "Не настроены Google Client ID / Secret.\n"
            "Пожалуйста, обратитесь к администратору."
        )
    except Exception as e:
        logger.error(f"Error connecting calendar: {e}", exc_info=True)
        await status_msg.edit_text(f"❌ Произошла ошибка: {e}")

async def dashboard_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show team task dashboard"""
    user = update.effective_user
    
    # Check permissions (CEO/Assistant only)
    allowed_ids = [settings.CEO_TELEGRAM_ID, settings.ASSISTANT_TELEGRAM_ID, 293254961]
    if user.id not in allowed_ids and str(user.id) not in [str(i) for i in allowed_ids]:
         await update.message.reply_text("⛔ У вас нет прав на просмотр дашборда.")
         return

    status_msg = await update.message.reply_text("📊 Собираю статистику по команде...")
    
    try:
        stats = asana_service.get_team_stats()
        
        if not stats:
            await status_msg.edit_text("📭 Нет данных или ошибка получения задач.")
            return
            
        # Format as a simple list/table
        msg = "📊 **Team Dashboard**\n\n"
        msg += "`Name             | Total | Overdue`\n"
        msg += "`-----------------|-------|--------`\n"
        
        total_tasks = 0
        total_overdue = 0
        
        for name, data in stats.items():
            # Truncate name for table
            clean_name = name.split()[0][:15].ljust(15)
            t = str(data['total']).center(5)
            o = str(data['overdue']).center(7)
            
            # Add alert icon if overdue > 0
            alert = "⚠️" if data['overdue'] > 0 else ""
            
            msg += f"`{clean_name} | {t} | {o}` {alert}\n"
            
            total_tasks += data['total']
            total_overdue += data['overdue']
            
        msg += "`-----------------|-------|--------`\n"
        msg += f"`TOTAL           | {str(total_tasks).center(5)} | {str(total_overdue).center(7)}`"
        
        await status_msg.edit_text(msg, parse_mode="Markdown")
        
    except Exception as e:
        logger.error(f"Error showing dashboard: {e}")
        await status_msg.edit_text("❌ Ошибка при формировании дашборда.")

async def users_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /users command - List all users"""
    user = update.effective_user
    
    # Check Admin Rights (CEO or Admin Role)
    async with AsyncSessionLocal() as session:
        db_user = await get_user_by_telegram_id(session, user.id)
        if not db_user or (db_user.role not in ['admin', 'ceo'] and user.id != settings.CEO_TELEGRAM_ID):
            await update.message.reply_text("⛔ У вас нет прав администратора.")
            return
            
        from app.services.user_service import get_all_users
        users = await get_all_users(session)
        
    if not users:
        await update.message.reply_text("📭 База пользователей пуста.")
        return
        
    response = "👥 **Список сотрудников:**\n\n"
    keyboard = []
    
    for u in users:
        status_icon = "🟢" if u.status == 'approved' and u.is_active else "🔴"
        if u.status == 'pending': status_icon = "⏳"
        
        role_icon = "👑" if u.role == 'ceo' else "🛡" if u.role == 'admin' else "👔" if u.role == 'manager' else "👷"
        
        response += f"{status_icon} **{u.full_name}** ({role_icon} {u.role})\n"
        
        # Add button for each user
        keyboard.append([InlineKeyboardButton(f"⚙️ {u.full_name}", callback_data=f"manage_user_{u.telegram_id}")])
        
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(response, reply_markup=reply_markup, parse_mode="Markdown")

async def manage_user_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user details and actions"""
    query = update.callback_query
    await query.answer()
    
    target_id = int(query.data.split('_')[2])
    
    async with AsyncSessionLocal() as session:
        target_user = await get_user_by_telegram_id(session, target_id)
        
    if not target_user:
        await query.edit_message_text("❌ Пользователь не найден.")
        return
        
    status_icon = "🟢" if target_user.status == 'approved' and target_user.is_active else "🔴"
    
    text = (
        f"👤 **Профиль сотрудника**\n\n"
        f"📛 **Имя:** {target_user.full_name}\n"
        f"🆔 **ID:** `{target_user.telegram_id}`\n"
        f"💼 **Должность:** {target_user.position}\n"
        f"📂 **Отдел:** {target_user.department}\n"
        f"🔑 **Роль:** {target_user.role}\n"
        f"📡 **Статус:** {status_icon} {target_user.status}\n"
    )
    
    # Action Buttons
    keyboard = []
    
    # Ban/Unban
    if target_user.is_active:
        keyboard.append([InlineKeyboardButton("⛔ Заблокировать", callback_data=f"ban_user_{target_id}")])
    else:
        keyboard.append([InlineKeyboardButton("✅ Разблокировать", callback_data=f"unban_user_{target_id}")])
        
    # Promote/Demote
    keyboard.append([
        InlineKeyboardButton("⬆️ Менеджер", callback_data=f"promote_user_{target_id}_manager"),
        InlineKeyboardButton("⬆️ Админ", callback_data=f"promote_user_{target_id}_admin")
    ])
    keyboard.append([InlineKeyboardButton("⬇️ Сотрудник", callback_data=f"promote_user_{target_id}_employee")])
    
    keyboard.append([InlineKeyboardButton("🔙 Назад к списку", callback_data="back_users")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")

async def ban_user_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ban/Unban user"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    action, target_id = data.split('_')[0], int(data.split('_')[2])
    
    new_status = 'banned' if action == 'ban' else 'approved'
    
    async with AsyncSessionLocal() as session:
        from app.services.user_service import update_user_status
        await update_user_status(session, target_id, new_status)
        
    # Refresh view
    await manage_user_callback(update, context)
    
    # Notify user
    msg = "⛔ Ваш доступ заблокирован администратором." if action == 'ban' else "✅ Ваш доступ восстановлен."
    try:
        await context.bot.send_message(chat_id=target_id, text=msg)
    except:
        pass

async def promote_user_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Change user role"""
    query = update.callback_query
    await query.answer()
    
    # promote_user_{id}_{role}
    parts = query.data.split('_')
    target_id = int(parts[2])
    new_role = parts[3]
    
    async with AsyncSessionLocal() as session:
        from app.services.user_service import update_user_role
        await update_user_role(session, target_id, new_role)
        
    # Refresh view
    await manage_user_callback(update, context)
    
    # Notify user
    try:
        await context.bot.send_message(chat_id=target_id, text=f"🆙 Ваша роль изменена на: **{new_role}**", parse_mode="Markdown")
    except:
        pass

def create_bot_app() -> Application:
    """Create and configure the bot application"""
    application = Application.builder().token(settings.TELEGRAM_BOT_TOKEN).build()

    # Add handlers
    
    # Registration Conversation Handler
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start_command)],
        states={
            REGISTER_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_register_name)],
            REGISTER_POSITION: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_register_position)],
        },
        fallbacks=[CommandHandler("start", start_command)],
    )
    application.add_handler(conv_handler)

    # Admin Callbacks
    application.add_handler(CallbackQueryHandler(admin_decision_callback, pattern="^admin_"))
    application.add_handler(CallbackQueryHandler(admin_dept_callback, pattern="^adm_dept_"))
    application.add_handler(CallbackQueryHandler(admin_role_callback, pattern="^adm_role_"))
    
    # User Management Callbacks
    application.add_handler(CallbackQueryHandler(manage_user_callback, pattern="^manage_user_"))
    application.add_handler(CallbackQueryHandler(ban_user_callback, pattern="^(ban|unban)_user_"))
    application.add_handler(CallbackQueryHandler(promote_user_callback, pattern="^promote_user_"))

    # Command handlers (must be BEFORE text handler)
    # application.add_handler(CommandHandler("start", start_command)) # Removed in favor of ConversationHandler
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("check_asana", check_asana_command))
    application.add_handler(CommandHandler("tasks", tasks_command))
    application.add_handler(CommandHandler("users", users_command))
    application.add_handler(CommandHandler("report", report_command))
    application.add_handler(CommandHandler("digest", digest_command))
    application.add_handler(CommandHandler("dashboard", dashboard_command))
    application.add_handler(CommandHandler("meeting", meeting_command))
    application.add_handler(CommandHandler("zoom", zoom_command))
    application.add_handler(CommandHandler("connect_calendar", connect_calendar_command))
    
    # Callback query handler for inline buttons
    application.add_handler(CallbackQueryHandler(handle_button_callback, pattern="^action_"))
    application.add_handler(CallbackQueryHandler(tasks_inbox_callback, pattern="^tasks_inbox$"))
    application.add_handler(CallbackQueryHandler(tasks_waiting_callback, pattern="^tasks_waiting$"))
    
    # Voice handler
    application.add_handler(MessageHandler(filters.VOICE, handle_voice_message))
    # Audio file handler for meetings
    application.add_handler(MessageHandler(filters.AUDIO, handle_audio_message))
    
    # Document handler for Knowledge Base uploads
    async def handle_document_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
        document = update.message.document
        caption = update.message.caption or ""
        
        # Check if it's for Knowledge Base
        if any(keyword in caption.lower() for keyword in ["kb", "база", "знания", "регламент"]):
            status_msg = await update.message.reply_text("📥 Получен документ. Загружаю...")
            
            try:
                # 1. Download File
                file = await context.bot.get_file(document.file_id)
                file_name = document.file_name
                file_path = f"temp_{file_name}"
                await file.download_to_drive(file_path)
                
                await status_msg.edit_text("💾 Сохраняю в реестр Asana...")
                
                # 2. Create/Update Asana Task (Registry)
                # Use a default project GID for Knowledge Base if not set
                kb_project_gid = settings.ASANA_DEPARTMENTS_PROJECT_GID # Fallback to Departments for now
                
                # Create Registry Task
                task_data = asana_service.create_registry_task(
                    project_gid=kb_project_gid,
                    name=file_name,
                    description=f"Uploaded by {update.effective_user.full_name} on {datetime.date.today()}",
                    attachment_path=file_path
                )
                
                await status_msg.edit_text("🧠 Индексирую в LlamaIndex...")
                
                # 3. Index in LlamaIndex
                from app.services.llama_service import llama_service
                llama_service.index_file(file_path, doc_id=task_data['gid'])
                
                # Cleanup
                os.remove(file_path)
                
                await status_msg.edit_text(
                    f"✅ **Документ добавлен в Базу Знаний!**\n\n"
                    f"📄 `{file_name}`\n"
                    f"🔗 [Ссылка на реестр Asana](https://app.asana.com/0/{kb_project_gid}/{task_data['gid']})\n\n"
                    f"Теперь я могу отвечать на вопросы по этому документу.",
                    parse_mode="Markdown"
                )
                
            except Exception as e:
                logger.error(f"Error processing document: {e}")
                await status_msg.edit_text("❌ Ошибка при обработке документа.")
                if os.path.exists(file_path):
                    os.remove(file_path)
    async def meeting_protocol_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        bot_id = query.data.split('_')[2]
        
        await query.edit_message_text("⏳ Генерирую протокол с помощью Claude...")
        
        # Fetch data from Redis
        import json
        import redis.asyncio as redis
        redis_client = redis.from_url(settings.REDIS_URL)
        data_json = await redis_client.get(f"meeting_data_{bot_id}")
        example_protocol = await redis_client.get("protocol_example")
        await redis_client.close()
        
        if not data_json:
            await query.edit_message_text("❌ Данные встречи устарели.")
            return
            
        meeting_data = json.loads(data_json)
        transcript = meeting_data.get('transcript', '') # Ensure transcript is saved in Redis
        
        if not transcript:
             await query.edit_message_text("❌ Нет транскрипта для генерации протокола.")
             return

        # Use Gemini for Protocol & Sonix for Transcription
        from app.services.gemini_service import gemini_service
        from app.services.sonix_service import sonix_service
        
        example_text = example_protocol.decode('utf-8') if example_protocol else "No example provided. Use standard format."
        
        try:
            # 0. Transcribe Video (if transcript missing or we want to re-transcribe)
            # Logic: If we have a video URL but no transcript, use Sonix.
            # Currently, we rely on Redis 'transcript' which might be empty or partial.
            # Let's force Sonix transcription if video exists.
            
            video_url = meeting_data.get('video_url')
            if video_url and (not transcript or len(transcript) < 100):
                await query.edit_message_text("⏳ Транскрибирую видео через Sonix.ai (это займет время)...")
                transcript = await sonix_service.transcribe_video(video_url)
                
            if not transcript:
                 await query.edit_message_text("❌ Нет транскрипта и видео для обработки.")
                 return

            # 1. Generate Protocol Text
            protocol = await gemini_service.generate_protocol(transcript, example_text)
            
            # 2. Extract Metadata for Registry
            metadata = await gemini_service.extract_meeting_metadata(transcript)
            
            # Archive Protocol to Drive
            from app.services.google_drive_service import google_drive_service
            from app.services.google_sheets_service import google_sheets_service
            import datetime
            
            date_str = datetime.datetime.now().strftime("%Y-%m-%d")
            time_str = datetime.datetime.now().strftime("%H:%M")
            day_str = datetime.datetime.now().strftime("%A")
            
            topic = meeting_data.get('summary', 'Meeting').replace('/', '-').replace('\\', '-')
            protocol_filename = f"{date_str}_Protocol_{topic}.txt"
            
            protocol_link = None
            if settings.DRIVE_PROTOCOLS_ID:
                protocol_link = google_drive_service.upload_text_file(
                    protocol_filename,
                    protocol,
                    settings.DRIVE_PROTOCOLS_ID
                )
                
            # Log to Registry (Professional Schema v2)
            if settings.GOOGLE_SHEETS_ID:
                registry_data = {
                    'date': date_str,
                    'topic': topic,
                    'attendees': ", ".join([p.get('name', 'Unknown') for p in meeting_data.get('participants', [])]),
                    'protocol_link': protocol_link or "Not uploaded",
                    'recording_link': meeting_data.get('video_url', ''),
                    'transcript_link': "TBD",
                    'summary': metadata.get('summary', ''),
                    'decisions': metadata.get('decisions', ''),
                    'tasks_count': f"{metadata.get('tasks_count', 0)} tasks",
                    'status': 'Done',
                    'next_steps': metadata.get('next_steps', ''),
                    'owner': 'AI Bot'
                }
                google_sheets_service.log_meeting(settings.GOOGLE_SHEETS_ID, registry_data)

            if protocol_link:
                await query.edit_message_text(
                    f"✅ **Протокол готов!**\n\n"
                    f"📄 [Открыть документ]({protocol_link})\n"
                    f"📊 **Реестр обновлен** (12 колонок)\n"
                    f"📝 Саммари: {metadata.get('summary')[:100]}...",
                    parse_mode="Markdown"
                )
            else:
                # Fallback
                await query.edit_message_text(
                    f"⚠️ **Протокол готов, но не сохранен в Drive**.\n\n"
                    f"Вот текст:\n\n{protocol[:3000]}...",
                    parse_mode="Markdown"
                )
                
        except Exception as e:
            logger.error(f"Protocol generation failed: {e}")
            await query.edit_message_text("❌ Ошибка генерации протокола.")

    async def set_protocol_example_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start uploading protocol example"""
        await update.message.reply_text("📤 Пришлите файл с примером протокола (PDF, DOCX, TXT).")
        return 1 # State for upload

    async def handle_protocol_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
        document = update.message.document
        if not document:
            await update.message.reply_text("❌ Это не файл.")
            return ConversationHandler.END
            
        file = await context.bot.get_file(document.file_id)
        # Download and read content
        # For simplicity, let's assume text/markdown for now or try to extract text
        # If binary (PDF/Docx), we need text extraction. 
        # Let's assume the user sends a text/md file for now as requested in the plan.
        
        import io
        f = io.BytesIO()
        await file.download_to_memory(f)
        content = f.getvalue().decode('utf-8', errors='ignore') # Simple decoding
        
        # Save to Redis
        import redis.asyncio as redis
        redis_client = redis.from_url(settings.REDIS_URL)
        await redis_client.set("protocol_example", content)
        await redis_client.close()
        
        await update.message.reply_text("✅ Пример протокола сохранен! Теперь я буду использовать его для новых встреч.")
        return ConversationHandler.END

    async def meeting_tasks_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        bot_id = query.data.split('_')[2]
        
        # Fetch data from Redis
        import json
        import redis.asyncio as redis
        redis_client = redis.from_url(settings.REDIS_URL)
        data_json = await redis_client.get(f"meeting_data_{bot_id}")
        await redis_client.close()
        
        if not data_json:
            await query.edit_message_text("❌ Данные встречи устарели.")
            return
            
        meeting_data = json.loads(data_json)
        action_items = meeting_data.get('action_items', [])
        
        if not action_items:
            await query.edit_message_text("✅ Задач не найдено.")
            return
            
        # Start task review flow
        # Store tasks in user_data to iterate
        context.user_data['review_tasks'] = action_items
        context.user_data['current_task_index'] = 0
        
        await show_next_task_review(update, context)

    async def show_next_task_review(update: Update, context: ContextTypes.DEFAULT_TYPE):
        tasks = context.user_data.get('review_tasks', [])
        index = context.user_data.get('current_task_index', 0)
        
        if index >= len(tasks):
            await update.effective_message.edit_text("✅ **Все задачи обработаны!**", parse_mode="Markdown")
            return
            
        task = tasks[index]
        
        keyboard = [
            [InlineKeyboardButton("✅ Подтвердить", callback_data="confirm_task"),
             InlineKeyboardButton("❌ Пропустить", callback_data="skip_task")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.effective_message.edit_text(
            f"📋 **Задача {index+1}/{len(tasks)}**\n\n"
            f"📌 **{task.get('task')}**\n"
            f"👤 Исполнитель: {task.get('assignee')}\n"
            f"📅 Срок: {task.get('deadline') or 'Не указан'}",
            reply_markup=reply_markup,
            parse_mode="Markdown"
        )

    async def task_action_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        action = query.data
        
        tasks = context.user_data.get('review_tasks', [])
        index = context.user_data.get('current_task_index', 0)
        task = tasks[index]
        
        if action == "confirm_task":
            # Create in Asana
            try:
                # Find assignee GID (simplified logic)
                assignee_gid = None
                # ... (User lookup logic similar to before) ...
                # For now, assign to CEO if unknown
                assignee_gid = settings.CEO_TELEGRAM_ID # Placeholder
                
                asana_service.create_task(
                    name=task.get('task'),
                    notes=f"Created from meeting review.\nAssignee: {task.get('assignee')}",
                    assignee_gid=assignee_gid,
                    due_on=task.get('deadline')
                )
            except Exception as e:
                logger.error(f"Error creating task: {e}")
        
        # Move to next
        context.user_data['current_task_index'] = index + 1
        await show_next_task_review(update, context)

    # Register new callbacks
    application.add_handler(CallbackQueryHandler(meeting_protocol_callback, pattern="^meeting_protocol_"))
    application.add_handler(CallbackQueryHandler(meeting_tasks_callback, pattern="^meeting_tasks_"))
    application.add_handler(CallbackQueryHandler(task_action_callback, pattern="^(confirm|skip)_task$"))

    # Meeting Scheduling States
    MEETING_TYPE = 10
    MEETING_TIME = 11
    RESOLVE_ATTENDEES = 12

    async def cancel_meeting(update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text("❌ Создание встречи отменено.", reply_markup=ReplyKeyboardRemove())
        return ConversationHandler.END

    async def handle_meeting_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Entry point for meeting scheduling"""
        text = update.message.text
        
        # 1. Extract details
        details = await ai_service.extract_meeting_details(text)
        context.user_data['meeting_details'] = details
        
        # 2. Check if time is known
        if not details.get('start_time'):
            await update.message.reply_text(
                f"📅 Планирую встречу: **{details.get('summary')}**\n\n"
                "🕒 **На какое время поставить?**\n"
                "(Напишите дату и время, например: 'завтра в 14:00')",
                parse_mode="Markdown"
            )
            return MEETING_TIME

        # 3. Resolve attendees
        return await resolve_attendees(update, context)

    async def meeting_time_response(update: Update, context: ContextTypes.DEFAULT_TYPE):
        text = update.message.text
        if text.lower() in ["отмена", "cancel"]:
            return await cancel_meeting(update, context)
            
        # Extract time from this new message
        new_details = await ai_service.extract_meeting_details(f"Встреча {text}")
        
        if not new_details.get('start_time'):
             await update.message.reply_text("⚠️ Не понял время. Пожалуйста, напишите точнее (например: 'завтра в 15:00').")
             return MEETING_TIME
             
        # Update details
        context.user_data['meeting_details']['start_time'] = new_details['start_time']
        
        return await resolve_attendees(update, context)

    async def resolve_attendees(update: Update, context: ContextTypes.DEFAULT_TYPE):
        details = context.user_data['meeting_details']
        attendee_names = details.get('attendees', [])
        
        # If no attendees extracted, proceed
        if not attendee_names:
            return await check_meeting_type(update, context)
            
        # Check if we already resolved them
        if 'resolved_emails' not in context.user_data:
            context.user_data['resolved_emails'] = []
            context.user_data['pending_attendees'] = list(attendee_names) # Copy
            
        pending = context.user_data['pending_attendees']
        
        if not pending:
            # All resolved
            return await check_meeting_type(update, context)
            
        # Process next attendee
        current_name = pending[0]
        
        from app.services.user_service import get_user_by_name
        async with AsyncSessionLocal() as session:
            users = await get_user_by_name(session, current_name)
            
        if not users:
            # Not found, ask user
            keyboard = [[KeyboardButton("❌ Пропустить")]]
            await update.message.reply_text(
                f"⚠️ Не нашел сотрудника: **{current_name}**.\n"
                "Введите ФИО или Email вручную, или нажмите 'Пропустить'.",
                reply_markup=ReplyKeyboardMarkup(keyboard, one_time_keyboard=True, resize_keyboard=True),
                parse_mode="Markdown"
            )
            return RESOLVE_ATTENDEES
            
        elif len(users) == 1:
            # Exact match
            user = users[0]
            # Ideally we need email, but we only have telegram_id/asana_gid. 
            # For now let's assume we can't invite by email without it.
            # But we can add to description.
            context.user_data['resolved_emails'].append(f"{user.full_name}") 
            pending.pop(0)
            return await resolve_attendees(update, context)
            
        else:
            # Multiple matches
            keyboard = []
            for u in users:
                keyboard.append([KeyboardButton(f"👤 {u.full_name} ({u.role})")])
            keyboard.append([KeyboardButton("❌ Пропустить")])
            
            await update.message.reply_text(
                f"🔍 Нашел несколько сотрудников по имени **{current_name}**.\n"
                "Кого добавить?",
                reply_markup=ReplyKeyboardMarkup(keyboard, one_time_keyboard=True, resize_keyboard=True),
                parse_mode="Markdown"
            )
            return RESOLVE_ATTENDEES

    async def resolve_attendee_response(update: Update, context: ContextTypes.DEFAULT_TYPE):
        text = update.message.text
        pending = context.user_data.get('pending_attendees', [])
        
        if not pending:
            return await check_meeting_type(update, context)
            
        current_name = pending[0]
        
        if text == "❌ Пропустить":
            await update.message.reply_text(f"⚠️ Пропускаю: {current_name}")
            pending.pop(0)
            return await resolve_attendees(update, context)
            
        elif text.startswith("👤 "):
            # "👤 Name (Role)" -> Extract Name
            selected_name = text.split("👤 ")[1].split(" (")[0]
            context.user_data['resolved_emails'].append(selected_name)
            pending.pop(0)
            return await resolve_attendees(update, context)
            
        else:
            # Manual Input (Email or Name retry)
            # Check if email
            if "@" in text:
                context.user_data['resolved_emails'].append(text)
                await update.message.reply_text(f"✅ Добавил email: {text}")
                pending.pop(0)
                return await resolve_attendees(update, context)
            else:
                # Retry search with new name
                from app.services.user_service import get_user_by_name
                async with AsyncSessionLocal() as session:
                    users = await get_user_by_name(session, text)
                    
                if not users:
                     await update.message.reply_text(f"⚠️ Снова не нашел: **{text}**. Попробуйте еще раз или нажмите 'Пропустить'.", parse_mode="Markdown")
                     return RESOLVE_ATTENDEES # Stay in state
                elif len(users) == 1:
                    user = users[0]
                    context.user_data['resolved_emails'].append(user.full_name)
                    await update.message.reply_text(f"✅ Нашел: {user.full_name}")
                    pending.pop(0)
                    return await resolve_attendees(update, context)
                else:
                    # Multiple matches found for new name
                    # We need to update pending[0] to this new name so resolve_attendees handles the multiple choice
                    pending[0] = text 
                    return await resolve_attendees(update, context)

    async def check_meeting_type(update: Update, context: ContextTypes.DEFAULT_TYPE):
        details = context.user_data['meeting_details']
        
        if details.get('is_online') is None:
            keyboard = [
                [KeyboardButton("🌐 Онлайн"), KeyboardButton("🏢 Оффлайн")],
                [KeyboardButton("❌ Отмена")]
            ]
            await update.message.reply_text(
                f"📅 Планирую встречу: **{details.get('summary')}**\n"
                f"🕒 Время: {details.get('start_time')}\n"
                f"👥 Участники: {', '.join(context.user_data.get('resolved_emails', [])) or 'Нет'}\n\n"
                "Как будем проводить?",
                reply_markup=ReplyKeyboardMarkup(keyboard, one_time_keyboard=True, resize_keyboard=True),
                parse_mode="Markdown"
            )
            return MEETING_TYPE
        else:
            return await finalize_meeting(update, context, details.get('is_online'))

    async def meeting_type_response(update: Update, context: ContextTypes.DEFAULT_TYPE):
        text = update.message.text
        if text == "❌ Отмена":
            return await cancel_meeting(update, context)
            
        is_online = (text == "🌐 Онлайн")
        return await finalize_meeting(update, context, is_online)

    async def finalize_meeting(update: Update, context: ContextTypes.DEFAULT_TYPE, is_online: bool):
        try:
            details = context.user_data.get('meeting_details')
            resolved_attendees = context.user_data.get('resolved_emails', [])
            
            if not details:
                await update.message.reply_text("❌ Ошибка: данные встречи потеряны.")
                return ConversationHandler.END
                
            # Create Calendar Event
            import datetime
            try:
                start_time = datetime.datetime.fromisoformat(details['start_time'])
            except ValueError:
                 await update.message.reply_text("❌ Ошибка формата времени. Попробуйте заново.")
                 return ConversationHandler.END
    
            end_time = start_time + datetime.timedelta(minutes=details.get('duration', 60))
            
            # Use resolved attendees in description
            description = f"Created by AI Ops Manager via Telegram.\n\nAttendees: {', '.join(resolved_attendees)}"
            
            await update.message.reply_text("⏳ Создаю встречу в календаре...", reply_markup=ReplyKeyboardRemove())
            
            event = google_calendar_service.create_event(
                summary=details['summary'],
                start_time=start_time,
                end_time=end_time,
                attendees=[], # Still empty as we don't have emails, but listed in description
                description=description
            )
            
            if not event:
                await update.message.reply_text("❌ Не удалось создать встречу в календаре (ошибка API).")
                return ConversationHandler.END
                
            msg = f"✅ **Встреча создана!**\n\n📅 {details['summary']}\n🕒 {start_time.strftime('%d.%m %H:%M')}\n👥 {', '.join(resolved_attendees)}\n🔗 [Google Calendar]({event.get('htmlLink')})"
            
            if is_online:
                # Check for Zoom Link
                if settings.ZOOM_PERSONAL_LINK:
                     meet_url = settings.ZOOM_PERSONAL_LINK
                     msg += f"\n\n📹 **Ссылка (Zoom):** {meet_url}"
                     
                     # Update Calendar Event with Zoom Link
                     # We created it without location, let's update it or just assume description is enough.
                     # Ideally we should have set location in create_event.
                     # But for now, description has it? No, we didn't add it there yet.
                     # Let's just rely on the message for now, or update the event if possible.
                     # Actually, let's just proceed to Recall.
                else:
                    # Get Meet URL
                    meet_url = event.get('conferenceData', {}).get('entryPoints', [{}])[0].get('uri')
                    if meet_url:
                        msg += f"\n\n📹 **Ссылка (Meet):** {meet_url}"
                    else:
                        msg += "\n⚠️ Ссылка на встречу не найдена."
                        meet_url = None

                if meet_url:
                    # Create Recall Bot
                    try:
                        await update.message.reply_text("🤖 Подключаю AI-секретаря...")
                        
                        # Derive webhook URL
                        webhook_url = None
                        if settings.TELEGRAM_WEBHOOK_URL:
                            webhook_url = settings.TELEGRAM_WEBHOOK_URL.replace("/bot/webhook", "/webhook/recall")
                        
                        bot = await recall_service.create_bot(meet_url, bot_name="AI Secretary", webhook_url=webhook_url)
                        msg += f"\n🤖 **AI-секретарь:** Подключен (ID: `{bot['id']}`)"
                    except Exception as e:
                        logger.error(f"Failed to create Recall bot: {e}")
                        msg += "\n⚠️ Не удалось подключить AI-секретаря (проверьте ссылку)."
                else:
                     msg += "\n⚠️ Не могу подключить секретаря без ссылки."
            
            # Add Stop Button
            keyboard = None
            if is_online and 'bot' in locals() and bot.get('id'):
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("🟥 Остановить запись", callback_data=f"stop_bot_{bot['id']}")]
                ])
            
            await update.message.reply_text(msg, parse_mode="Markdown", reply_markup=keyboard or ReplyKeyboardRemove())
            
            # Restore main menu - REMOVED to avoid spam
            # await start_command(update, context)
            return ConversationHandler.END
            
        except Exception as e:
            logger.error(f"Critical error in finalize_meeting: {e}", exc_info=True)
            await update.message.reply_text(f"❌ Произошла критическая ошибка: {e}")
            return ConversationHandler.END

    async def stop_bot_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        
        bot_id = query.data.split("_")[2]
        
        try:
            # Use leave_meeting instead of delete_bot to ensure transcript is saved
            await recall_service.leave_meeting(bot_id)
            
            msg = await query.edit_message_text(f"{query.message.text}\n\n🛑 **Запись остановлена вручную.**\n⏳ Ожидайте обработки...", parse_mode="Markdown")
            
            # Schedule polling job (run every 30s)
            context.job_queue.run_repeating(
                check_bot_status_job, 
                interval=30, 
                first=10, 
                data={
                    'bot_id': bot_id, 
                    'chat_id': query.message.chat_id, 
                    'message_id': msg.message_id
                }
            )
            logger.info(f"Scheduled polling for bot {bot_id}")
            
        except Exception as e:
            logger.error(f"Failed to stop bot {bot_id}: {e}")
            await query.message.reply_text("❌ Не удалось остановить бота.")

    # Register ConversationHandler
    meeting_conv_handler = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex(r'(?i)(?:поставь|запланируй|назначь|создай|организуй|сделай|забей).*встречу|встречу.*(?:поставь|запланируй|назначь|создай|организуй|сделай|забей)'), handle_meeting_request)],
        states={
            MEETING_TIME: [MessageHandler(filters.TEXT & ~filters.COMMAND, meeting_time_response)],
            RESOLVE_ATTENDEES: [MessageHandler(filters.TEXT & ~filters.COMMAND, resolve_attendee_response)],
            MEETING_TYPE: [MessageHandler(filters.TEXT & ~filters.COMMAND, meeting_type_response)]
        },
        fallbacks=[CommandHandler('cancel', cancel_meeting)]
    )
    application.add_handler(meeting_conv_handler)
    
    # Register Stop Handler
    application.add_handler(CallbackQueryHandler(stop_bot_callback, pattern="^stop_bot_"))
    
    # Protocol Example Upload Handler
    protocol_conv_handler = ConversationHandler(
        entry_points=[CommandHandler('set_protocol_example', set_protocol_example_command)],
        states={
            1: [MessageHandler(filters.Document.ALL, handle_protocol_upload)]
        },
        fallbacks=[CommandHandler('cancel', cancel_meeting)] # Reuse cancel
    )
    application.add_handler(protocol_conv_handler)

    application.add_handler(MessageHandler(filters.Document.ALL, handle_document_message))
    
    # Text message handler for persistent keyboard shortcuts (MUST BE LAST)
    async def handle_text_shortcuts(update: Update, context: ContextTypes.DEFAULT_TYPE):
        text = update.message.text
        
        # Global handler for "Cancel" button to clean up stuck keyboards
        if text == "❌ Отмена":
            await update.message.reply_text("👌", reply_markup=ReplyKeyboardRemove())
            return
            
        # Check for shortcuts
        if text == "📊 Дашборд":
            await update.message.reply_text("📊 **Дашборд**\n\n"
                                            "Здесь будет отображаться сводная информация.",
                                            parse_mode="Markdown")
            return
            
        user = update.effective_user
        
        logger.info(f"Received text from {user.id}: {text[:20]}...")
        
        # Check if it's a keyboard button
        if text == "📝 Отчет":
            await update.message.reply_text(
                "🎯 **Режим отчета активирован**\n\n"
                "🗒️ Напишите ваш отчет или отправьте голосовое.\n\n"
                "📝 **Пример:**\n"
                "Отчет: Сегодня завершил работу над лендингом. Завтра начну настройку рекламы.\n\n"
                "💡 *Или просто начните писать - я пойму!*",
                parse_mode="Markdown"
            )
            return
        elif text == "📞 Задачи":
            await tasks_command(update, context)
            return
        elif text == "🎬 Zoom":
            await update.message.reply_text(
                "Отправьте ссылку на встречу:\n`/zoom https://zoom.us/j/123`",
                parse_mode="Markdown"
            )
            return
        elif text == "📊 Меню":
            await start_command(update, context)
            return
        elif text == "📋 Дайджест":
            await digest_command(update, context)
            return
        elif text == "⚙️ Настройки":
            await update.message.reply_text(
                "⚙️ **Настройки**\n\n"
                "🔔 Уведомления: Включены\n"
                "🌍 Часовой пояс: Asia/Dubai\n"
                "🗣️ Язык: Русский\n\n"
                "💎 *Используйте /start для полного меню*",
                parse_mode="Markdown"
            )
            return
        elif text == "👥 Сотрудники":
            await users_command(update, context)
            return
        
        # If it's regular text, treat as potential report or task creation
        text_lower = text.lower()
        
        # Check for Google Auth Code (usually starts with 4/)
        if text.strip().startswith("4/"):
            from app.services.google_calendar_service import google_calendar_service
            try:
                code = text.strip()
                success = google_calendar_service.save_credentials_from_code(code)
                if success:
                    await update.message.reply_text(
                        "✅ **Календарь успешно подключен!**\n\n"
                        "Теперь я буду проверять ваши встречи каждые 5 минут и предлагать отправить бота.",
                        parse_mode="Markdown"
                    )
                else:
                    await update.message.reply_text("❌ Не удалось сохранить учетные данные.")
            except Exception as e:
                logger.error(f"Error saving credentials: {e}")
                await update.message.reply_text(f"❌ Ошибка при подключении: {e}")
            return

        # BUFFER EVERYTHING ELSE
        # Add to buffer
        await context_manager.add_to_buffer(user.id, text)
        
        # Remove existing job if any
        current_jobs = context.job_queue.get_jobs_by_name(f"buffer_{user.id}")
        for job in current_jobs:
            job.schedule_removal()
            
        # Schedule new job in 7 seconds
        context.job_queue.run_once(process_user_buffer, 7, data={'user_id': user.id, 'chat_id': update.effective_chat.id}, name=f"buffer_{user.id}")

    async def process_user_buffer(context: ContextTypes.DEFAULT_TYPE):
        job = context.job
        user_id = job.data['user_id']
        chat_id = job.data['chat_id']
        
        # Get all messages
        text = await context_manager.get_and_clear_buffer(user_id)
        if not text:
            return

        # Get history
        history = await context_manager.get_history(user_id)
        
        # Analyze
        analysis = await ai_service.analyze_conversation(text, history)
        intent = analysis.get("intent", "OTHER")
        confidence = analysis.get("confidence", 0.0)
        
        logger.info(f"Processed buffer for {user_id}. Intent: {intent} ({confidence})")
        
        # Add User Message to History
        await context_manager.add_to_history(user_id, "user", text)

        reply_text = ""

        if intent == "TASK_CREATION":
            # Extract task details
            task_data = await ai_service.analyze_task_request(text)
            
            # Create Task
            try:
                # Use default project/section logic
                project_gid = settings.ASANA_INBOX_PROJECT_GID
                
                # Create task
                new_task = asana_service.create_task(
                    projects=[project_gid],
                    name=task_data.get('name', text[:50]),
                    notes=task_data.get('notes', text),
                    due_on=task_data.get('due_date')
                )
                
                reply_text = (
                    f"✅ **Задача создана!**\n\n"
                    f"📝 **{new_task['name']}**\n"
                    f"🔗 [Открыть в Asana]({new_task['permalink_url']})"
                )
            except Exception as e:
                logger.error(f"Failed to create task: {e}")
                reply_text = "❌ Не удалось создать задачу. Попробуйте позже."

        elif intent == "REPORT":
            # Handle Report
            # For now, just acknowledge. In future, parse and save.
            reply_text = "✅ Отчет принят. Спасибо!"
            
        elif intent == "KNOWLEDGE_BASE":
            # Handle KB Query
            from app.services.llama_service import llama_service
            try:
                answer = llama_service.query(text)
                reply_text = f"📚 **База Знаний:**\n\n{answer}"
            except Exception as e:
                logger.error(f"KB Query failed: {e}")
                reply_text = "❌ Не удалось найти информацию в базе знаний."
                
        elif intent == "FINANCE":
             reply_text = "💰 Финансовый модуль пока в разработке."
             
        elif intent == "HR":
             reply_text = "👥 HR модуль пока в разработке."
             
        else:
            # OTHER or Unclear
            reply_text = analysis.get("suggested_reply", "Я вас услышал.")

        # Send Reply
        if reply_text:
            await context.bot.send_message(chat_id=chat_id, text=reply_text, parse_mode="Markdown")
            # Add Assistant Reply to History
            await context_manager.add_to_history(user_id, "assistant", reply_text)
            return

        # Auto-detect meeting URLs
        if any(domain in text for domain in ["zoom.us", "meet.google.com", "teams.microsoft.com"]):
            # Found a meeting link - create bot automatically
            meeting_url = text.strip()
            
            status_msg = await update.message.reply_text("🔄 Отправляю бота на встречу...")
            
            try:
                # Create Recall bot
                bot_data = await recall_service.create_bot(meeting_url, bot_name="AI Ops Manager Bot")
                bot_id = bot_data.get("id")
                
                await status_msg.edit_text(
                    f"✅ **Бот отправлен!**\n\n"
                    f"🎬 Bot ID: `{bot_id}`\n\n"
                    "🤖 Бот присоединится к встрече и начнёт запись.\n"
                    "📝 После встречи я отправлю вам протокол.",
                    parse_mode="Markdown"
                )
                return
                
            except Exception as e:
                logger.error(f"Error creating Recall bot: {e}")
                await status_msg.edit_text(
                    f"❌ **Ошибка**\n\n"
                    f"Не удалось отправить бота.\n\n"
                    f"Проверьте:\n"
                    f"• Ссылка корректна\n"
                    f"• API ключ Recall.ai настроен\n\n"
                    f"🐛 Ошибка: {str(e)}"
                )
                return
        
        # ---------------------------------------------------------
        # AI ROUTER: Classify Intent
        # ---------------------------------------------------------
        status_msg = await update.message.reply_text("🧠 Анализирую запрос...")
        
        try:
            intent_data = await ai_service.classify_intent(text)
            intent = intent_data.get("intent", "OTHER")
            confidence = intent_data.get("confidence", 0.0)
            
            logger.info(f"Intent classified: {intent} ({confidence})")
            
            # --- 1. TASK CREATION ---
            if intent == "TASK_CREATION":
                # Use shared AI analysis
                task_data = await ai_service.analyze_task_request(text)
                
                async with AsyncSessionLocal() as session:
                    db_user = await get_user_by_telegram_id(session, user.id)
                    
                    if not db_user:
                        await status_msg.edit_text("❌ Вы не зарегистрированы.")
                        return

                    # Logic copied/adapted from handle_voice_message for consistency
                    assignee_gid = None
                    assignee_name = "Me"
                    
                    # Try to find assignee from AI guess
                    ai_assignee_guess = task_data.get('assignee_guess')
                    is_self_assigned = False
                    
                    if ai_assignee_guess:
                        # Check for self-assignment keywords
                        self_keywords = ["я", "мне", "себе", "меня"]
                        if any(k in ai_assignee_guess.lower() for k in self_keywords):
                            is_self_assigned = True
                            if db_user and db_user.asana_gid and db_user.asana_gid != "temp":
                                assignee_gid = db_user.asana_gid
                                assignee_name = db_user.full_name
                            else:
                                assignee_gid = asana_service.get_me_gid()
                                assignee_name = "Me (Sender)"
                        else:
                            found_user = await get_user_by_name(session, ai_assignee_guess)
                            if found_user and found_user.asana_gid and found_user.asana_gid != "temp":
                                assignee_gid = found_user.asana_gid
                                assignee_name = found_user.full_name
                    
                    # Fallback to sender if no specific assignee found
                    if not assignee_gid:
                        if db_user and db_user.asana_gid and db_user.asana_gid != "temp":
                            assignee_gid = db_user.asana_gid
                            assignee_name = db_user.full_name
                        else:
                             # Fallback to Default Assignee (Ekaterina) or Me
                             if settings.ASANA_DEFAULT_ASSIGNEE_GID:
                                 assignee_gid = settings.ASANA_DEFAULT_ASSIGNEE_GID
                                 assignee_name = "Default (Ekaterina)"
                             else:
                                 assignee_gid = asana_service.get_me_gid()
                                 assignee_name = "Default (Me)"

                    # Determine Project Custom Field
                    project_enum = task_data.get('project_enum', 'Общая группа')
                    project_gid = PROJECT_OPTIONS.get(project_enum)
                    
                    custom_fields = {}
                    if project_gid and settings.ASANA_PROJECT_FIELD_GID:
                        custom_fields[settings.ASANA_PROJECT_FIELD_GID] = project_gid

                    # Determine Target Project and Section (Routing)
                    target_projects = None
                    target_section = None
                    
                    # Check if assignee maps to a specific section
                    if ai_assignee_guess and not is_self_assigned:
                        for name_key, section_gid in SECTION_MAPPING.items():
                            if name_key.lower() in ai_assignee_guess.lower():
                                # Found a match! Route to "Задачи отделов"
                                if settings.ASANA_DEPARTMENTS_PROJECT_GID:
                                    target_projects = [settings.ASANA_DEPARTMENTS_PROJECT_GID]
                                    target_section = section_gid
                                    project_enum = f"Задачи отделов ({name_key})" # Update display name
                                break
                    
                    # If self-assigned, force Inbox -> Unprocessed
                    if is_self_assigned:
                        target_projects = [settings.ASANA_INBOX_PROJECT_GID]
                        target_section = settings.ASANA_UNPROCESSED_SECTION_GID
                        project_enum = "Входящие (Не разобрано)"
                    
                    # If no assignee mentioned, route to Departments -> Unprocessed
                    elif not ai_assignee_guess and not target_projects:
                         if settings.ASANA_DEPARTMENTS_PROJECT_GID and settings.ASANA_DEPARTMENTS_UNPROCESSED_SECTION_GID:
                             target_projects = [settings.ASANA_DEPARTMENTS_PROJECT_GID]
                             target_section = settings.ASANA_DEPARTMENTS_UNPROCESSED_SECTION_GID
                             project_enum = "Задачи отделов (Неразобранное)"

                    await status_msg.edit_text(f"🚀 Создаю задачу в Asana...\n👤 Ответственный: {assignee_name}\n📂 Проект: {project_enum}")
                    
                    new_task = asana_service.create_task(
                        name=task_data.get('name'),
                        notes=task_data.get('notes', '') + f"\n\nOriginal Text: {text}",
                        assignee_gid=assignee_gid,
                        due_on=task_data.get('due_date'),
                        custom_fields=custom_fields,
                        projects=target_projects,
                        section=target_section
                    )
                    
                    # Reply to User
                    await status_msg.edit_text(
                        f"✅ **Задача создана!**\n\n"
                        f"📌 **{new_task['name']}**\n"
                        f"📂 **Проект:** {project_enum}\n"
                        f"👤 **Ответственный:** {assignee_name}\n"
                        f"📅 **Срок:** {task_data.get('due_date') or 'Не указан'}\n"
                        f"🔗 [Открыть в Asana]({new_task['permalink_url']})",
                        parse_mode="Markdown"
                    )

                    # Notify Assistant
                    if settings.ASSISTANT_TELEGRAM_ID:
                        try:
                            assistant_msg = (
                                f"🔔 **Новая задача от CEO (Текст)**\n\n"
                                f"📌 **{new_task['name']}**\n"
                                f"📂 **Проект:** {project_enum}\n"
                                f"👤 **Ответственный:** {assignee_name}\n"
                                f"🔗 [Открыть в Asana]({new_task['permalink_url']})"
                            )
                            await context.bot.send_message(chat_id=settings.ASSISTANT_TELEGRAM_ID, text=assistant_msg, parse_mode="Markdown")
                        except Exception as e:
                            logger.error(f"Failed to notify assistant: {e}")
            
            # --- 2. REPORT ---
            elif intent == "REPORT":
                await status_msg.edit_text("🔄 Обрабатываю отчет...")
                
                async with AsyncSessionLocal() as session:
                    db_user = await get_user_by_telegram_id(session, user.id)
                    
                    if not db_user:
                        await status_msg.edit_text("❌ Вы не зарегистрированы.")
                        return
                    
                    # Clean text (remove "Отчет:" prefix if present)
                    report_text = text
                    if text_lower.startswith("отчет"):
                        report_text = text[6:].strip()
                    
                    await status_msg.edit_text("🧠 Анализирую отчет с помощью AI...")
                    
                    analysis = await ai_service.analyze_report(report_text, db_user.asana_gid)
                    
                    if "error" in analysis:
                        await status_msg.edit_text(f"❌ Ошибка: {analysis['error']}")
                        return
                    
                    await status_msg.edit_text("💾 Сохраняю отчет...")
                    
                    new_report = DailyReport(
                        user_id=db_user.id,
                        report_date=datetime.date.today(),
                        raw_text=report_text,
                        completed_tasks=analysis.get("summary", ""),
                        blockers=analysis.get("blockers", ""),
                        sentiment=analysis.get("sentiment", "neutral")
                    )
                    session.add(new_report)
                    await session.commit()
                    
                    # Update Asana tasks
                    await status_msg.edit_text("✅ Отчет принят! Обновляю Asana...")
                    
                    response = f"✅ **Отчет принят!**\n\n"
                    response += f"📅 Дата: {datetime.date.today().strftime('%d.%m.%Y')}\n"
                    response += f"👤 Автор: {db_user.full_name}\n\n"
                    
                    if analysis.get("task_updates"):
                        response += f"✅ Обновлено задач: {len(analysis['task_updates'])}\n"
                    
                    await status_msg.edit_text(response, parse_mode="Markdown")

            # --- 3. KNOWLEDGE BASE (RAG) ---
            elif intent == "KNOWLEDGE_BASE":
                await status_msg.edit_text("📚 Ищу ответ в базе знаний...")
                try:
                    from app.services.llama_service import llama_service
                    answer = llama_service.query(text)
                    await status_msg.edit_text(f"🤖 **Ответ AI:**\n\n{answer}", parse_mode="Markdown")
                except Exception as e:
                    logger.error(f"RAG Error: {e}")
                    await status_msg.edit_text("❌ Ошибка при поиске в базе знаний.")

            # --- 4. FINANCE ---
            elif intent == "FINANCE":
                await status_msg.edit_text("💰 **Финансовый Агент**\n\nФункция в разработке. Скоро я смогу выставлять счета и показывать P&L.")

            # --- 5. HR ---
            elif intent == "HR":
                await status_msg.edit_text("👥 **HR Агент**\n\nФункция в разработке. Скоро я смогу искать кандидатов и отвечать на вопросы по кадрам.")

            # --- 6. OTHER / UNKNOWN ---
            else:
                await status_msg.edit_text(
                    "🤔 **Не понял запрос**\n\n"
                    "Я пока учусь понимать все контексты.\n"
                    "Попробуйте:\n"
                    "• 'Поставь задачу...'\n"
                    "• 'Отчет: ...'\n"
                    "• 'Как оформить отпуск?' (База знаний)"
                )

        except Exception as e:
            logger.error(f"Error in AI Router: {e}")
            await status_msg.edit_text("❌ Произошла системная ошибка.")
    
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text_shortcuts))

    return application

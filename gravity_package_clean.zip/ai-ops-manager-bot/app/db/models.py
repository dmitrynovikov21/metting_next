from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime, Text, JSON, Date, Time, Float
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.base import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    telegram_id = Column(Integer, unique=True, nullable=False, index=True)
    asana_gid = Column(String(50), unique=True, nullable=False)
    full_name = Column(String(100), nullable=False)
    role = Column(String(20), nullable=False)  # ceo, ceo_assistant, manager, employee, admin
    department = Column(String(50))
    manager_id = Column(Integer, ForeignKey("users.id"))
    timezone = Column(String(50), default="Asia/Dubai")
    language = Column(String(5), default="ru")
    position = Column(String(100))
    status = Column(String(20), default="pending") # pending, approved, rejected
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    manager = relationship("User", remote_side=[id], backref="subordinates")
    tasks = relationship("TaskCache", back_populates="assignee")
    reports = relationship("DailyReport", back_populates="user")


class TaskCache(Base):
    __tablename__ = "tasks_cache"

    id = Column(Integer, primary_key=True, index=True)
    asana_gid = Column(String(50), unique=True, nullable=False, index=True)
    name = Column(Text, nullable=False)
    description = Column(Text)
    assignee_user_id = Column(Integer, ForeignKey("users.id"))
    assignee_asana_gid = Column(String(50))
    project_gid = Column(String(50))
    section_gid = Column(String(50))
    due_date = Column(Date)
    completed = Column(Boolean, default=False)
    completed_at = Column(DateTime(timezone=True))
    status = Column(String(50))
    priority = Column(String(20))
    progress = Column(Integer, default=0)
    permalink_url = Column(Text)
    last_sync = Column(DateTime(timezone=True), server_default=func.now())

    assignee = relationship("User", back_populates="tasks")


class DailyReport(Base):
    __tablename__ = "daily_reports"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    report_date = Column(Date, nullable=False, index=True)
    
    completed_tasks = Column(JSON)
    in_progress = Column(JSON)
    blockers = Column(JSON)
    tomorrow_plans = Column(JSON)  # Stored as JSON list
    raw_text = Column(Text)
    
    sentiment = Column(String(20))
    sentiment_score = Column(Float)
    
    submitted_at = Column(DateTime(timezone=True), server_default=func.now())
    processed = Column(Boolean, default=False)
    
    user = relationship("User", back_populates="reports")

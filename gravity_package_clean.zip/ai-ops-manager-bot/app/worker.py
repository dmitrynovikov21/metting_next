import os
import asyncio
import httpx
import logging
from celery import Celery
from celery.schedules import crontab
from sqlalchemy.future import select

from app.db.base import AsyncSessionLocal
from app.db.models import User, DailyReport
from app.services.ai_service import ai_service
from app.services.asana_client import asana_service
from app.services.user_service import get_all_users
from app.services.google_calendar_service import google_calendar_service
from app.services.recall_service import recall_service
from app.bot.loader import create_bot_app
import datetime
from sqlalchemy.orm import selectinload
from app.core.config import settings

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Get Redis URL from environment or use default
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")

celery_app = Celery(
    "worker",
    broker=REDIS_URL,
    backend=REDIS_URL
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Asia/Dubai",
    enable_utc=True,
)

async def _send_reminders():
    """Async function to send reminders"""
    logger.info("Starting daily report reminders...")
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(User).where(User.is_active == True))
        users = result.scalars().all()
        
        if not users:
            logger.info("No active users found.")
            return

        async with httpx.AsyncClient() as client:
            for user in users:
                if not user.telegram_id:
                    continue
                    
                try:
                    logger.info(f"Sending reminder to {user.full_name} ({user.telegram_id})")
                    msg = (
                        f"👋 Привет, {user.full_name}!\n\n"
                        "🕕 **Время ежедневного отчета (18:00)**\n"
                        "Пожалуйста, запиши голосовое сообщение или напиши текст:\n"
                        "1. Что сделано сегодня?\n"
                        "2. Какие планы на завтра?\n"
                        "3. Есть ли проблемы/блокеры?"
                    )
                    await client.post(
                        f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}/sendMessage",
                        json={
                            "chat_id": user.telegram_id,
                            "text": msg,
                            "parse_mode": "Markdown"
                        }
                    )
                except Exception as e:
                    logger.error(f"Failed to send reminder to {user.telegram_id}: {e}")

@celery_app.task
def send_daily_report_reminder():
    """Celery task wrapper for reminders"""
    asyncio.run(_send_reminders())

async def _send_digest():
    """Async function to generate and send daily morning brief"""
    logger.info("Starting daily digest generation...")
    
    # 1. Get CEO User
    ceo_id = settings.CEO_TELEGRAM_ID
    if not ceo_id:
        logger.error("CEO_TELEGRAM_ID not set")
        return

    async with AsyncSessionLocal() as session:
        # Get CEO user object
        result = await session.execute(select(User).where(User.telegram_id == ceo_id))
        ceo_user = result.scalars().first()
        
        # 2. Fetch Team Reports (Yesterday)
        yesterday = datetime.date.today() - datetime.timedelta(days=1)
        query = select(DailyReport).options(selectinload(DailyReport.user)).where(DailyReport.report_date == yesterday)
        result = await session.execute(query)
        reports = result.scalars().all()
    
    # 3. Fetch Tasks (Due Today/Overdue)
    tasks = []
    if ceo_user and ceo_user.asana_gid and ceo_user.asana_gid != "temp":
        try:
            all_tasks = asana_service.get_user_tasks(ceo_user.asana_gid, completed=False)
            today = datetime.date.today()
            
            for task in all_tasks:
                due_on = task.get('due_on')
                if due_on:
                    from dateutil import parser as date_parser
                    due_date = date_parser.parse(due_on).date()
                    if due_date <= today:
                        tasks.append(task)
        except Exception as e:
            logger.error(f"Error fetching Asana tasks: {e}")

    # 4. Fetch Meetings (Today)
    meetings = []
    try:
        meetings = google_calendar_service.get_events_for_today()
    except Exception as e:
        logger.error(f"Error fetching Google Calendar events: {e}")

    # 5. Generate Brief
    user_name = ceo_user.full_name if ceo_user else "Denis"
    digest_text = await ai_service.generate_morning_brief(user_name, tasks, meetings, reports)

    # 6. Send to CEO
    async with httpx.AsyncClient() as client:
        try:
            await client.post(
                f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}/sendMessage",
                json={
                    "chat_id": ceo_id,
                    "text": digest_text,
                    "parse_mode": "Markdown"
                }
            )
            logger.info(f"Sent morning brief to {ceo_id}")
        except Exception as e:
            logger.error(f"Failed to send digest to {ceo_id}: {e}")

@celery_app.task
def send_daily_digest():
    """Celery task wrapper for digest"""
    asyncio.run(_send_digest())

async def _check_stale_tasks():
    """Check for tasks with no updates > 3 days"""
    logger.info("Checking for stale tasks...")
    
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(User).where(User.is_active == True))
        users = result.scalars().all()
        
        cutoff_date = datetime.datetime.now() - datetime.timedelta(days=3)
        
        async with httpx.AsyncClient() as client:
            for user in users:
                if not user.telegram_id or not user.asana_gid or user.asana_gid == "temp":
                    continue
                
                try:
                    # Get user's active tasks
                    tasks = asana_service.get_user_tasks(user.asana_gid, completed=False)
                    
                    stale_tasks = []
                    for task in tasks:
                        # Check last story/comment
                        stories = asana_service.get_task_stories(task['gid'])
                        
                        if stories:
                            # Check if last story is older than 3 days
                            last_story = stories[-1]
                            created_at_str = last_story.get('created_at', '')
                            if created_at_str:
                                # Parse ISO datetime
                                from dateutil import parser as date_parser
                                last_activity = date_parser.parse(created_at_str)
                                if last_activity < cutoff_date:
                                    stale_tasks.append(task['name'])
                        else:
                            # No stories at all, task might be stale
                            stale_tasks.append(task['name'])
                    
                    if stale_tasks:
                        msg = f"👋 {user.full_name}, у вас есть задачи без обновлений более 3 дней:\n\n"
                        for task_name in stale_tasks[:5]:  # Limit to 5
                            msg += f"• {task_name}\n"
                        msg += "\nЕсть новости по ним?"
                        
                        await client.post(
                            f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}/sendMessage",
                            json={"chat_id": user.telegram_id, "text": msg}
                        )
                        logger.info(f"Sent stale task reminder to {user.full_name}")
                        
                except Exception as e:
                    logger.error(f"Error checking stale tasks for {user.full_name}: {e}")

@celery_app.task
def check_stale_tasks():
    """Celery task wrapper for stale task checking"""
    asyncio.run(_check_stale_tasks())

async def _check_deadlines():
    logger.info("Checking deadlines... (Not implemented yet)")

@celery_app.task
def check_deadlines():
    """Celery task wrapper for deadline checking"""
    asyncio.run(_check_deadlines())

@celery_app.task
def check_calendar_events():
    """Check Google Calendar for upcoming meetings and schedule Recall bot"""
    logger.info("Checking Google Calendar for upcoming meetings...")
    
    # Run async code in sync task
    loop = asyncio.get_event_loop()
    if loop.is_closed():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    loop.run_until_complete(_check_calendar_events_async())

async def _check_calendar_events_async():
    try:
        # Get upcoming meetings
        meetings = google_calendar_service.get_upcoming_meetings(limit=10)
        
        if not meetings:
            return

        bot_app = create_bot_app()
        
        # Current time in UTC (as Google returns UTC usually)
        now = datetime.datetime.utcnow()
        
        for meeting in meetings:
            # Parse start time
            start_str = meeting['start']
            # Handle date-only events (all day)
            if 'T' not in start_str:
                continue
                
            # Parse ISO format (e.g. 2023-11-23T14:00:00Z or +04:00)
            from dateutil import parser as date_parser
            start_time = date_parser.parse(start_str)
            
            # Convert now to same timezone if needed, or rely on offset-naive/aware comparison
            # Best to convert both to UTC
            if start_time.tzinfo:
                now_aware = datetime.datetime.now(datetime.timezone.utc)
                time_diff = start_time - now_aware
            else:
                time_diff = start_time - now
            
            minutes_until = time_diff.total_seconds() / 60
            
            # Check for 15-minute reminder (window 10-15 mins)
            if 10 <= minutes_until <= 15:
                title = meeting['summary']
                meeting_url = meeting.get('meeting_url', 'No link')
                
                msg = (
                    f"⏰ **Встреча через 15 минут!**\n\n"
                    f"📌 {title}\n"
                    f"🔗 {meeting_url}\n"
                )
                
                if meeting.get('meeting_url'):
                    msg += f"\n🤖 Отправить бота? /zoom {meeting_url}"
                
                try:
                    await bot_app.bot.send_message(
                        chat_id=settings.CEO_TELEGRAM_ID,
                        text=msg,
                        parse_mode="Markdown"
                    )
                    logger.info(f"Sent meeting reminder for {title}")
                except Exception as e:
                    logger.error(f"Error sending meeting reminder: {e}")

            # Check for 30-minute PREP CARD (window 25-30 mins)
            elif 25 <= minutes_until <= 30:
                title = meeting['summary']
                description = meeting.get('description', '')
                attendees = meeting.get('attendees', [])
                
                # Format attendees
                attendees_list = ", ".join([a['name'] for a in attendees if a.get('email') != "denis@futurist.biz"]) # Exclude self if possible
                if not attendees_list:
                    attendees_list = "Нет участников"
                
                # Format agenda (first 3 lines of description)
                agenda = "\n".join(description.split('\n')[:3]) if description else "Нет описания"
                
                msg = (
                    f"📝 **Подготовка к встрече (через 30 мин)**\n\n"
                    f"📌 **{title}**\n"
                    f"👥 **Участники:** {attendees_list}\n\n"
                    f"📋 **Повестка/Контекст:**\n{agenda}\n\n"
                    f"💡 *Совет: Проверьте последние сообщения в чате с участниками.*"
                )
                
                try:
                    await bot_app.bot.send_message(
                        chat_id=settings.CEO_TELEGRAM_ID,
                        text=msg,
                        parse_mode="Markdown"
                    )
                    logger.info(f"Sent prep card for {title}")
                except Exception as e:
                    logger.error(f"Error sending prep card: {e}")

    except Exception as e:
        logger.error(f"Error in calendar check: {e}")

@celery_app.task
def test_task():
    return "Celery is working!"

@celery_app.task
def send_evening_summary():
    """Celery task wrapper for evening summary"""
    asyncio.run(_send_evening_summary())

async def _send_evening_summary():
    """Generate and send evening summary of daily reports"""
    logger.info("Starting evening summary generation...")
    
    today = datetime.date.today()
    
    async with AsyncSessionLocal() as session:
        query = select(DailyReport).options(selectinload(DailyReport.user)).where(DailyReport.report_date == today)
        result = await session.execute(query)
        reports = result.scalars().all()
        
        if not reports:
            logger.info(f"No reports found for {today}")
            return

        # Use existing generate_digest method which summarizes reports
        summary_text = await ai_service.generate_digest(reports)
        
        # Add header
        msg = f"🌙 **Вечерняя сводка за {today.strftime('%d.%m.%Y')}**\n\n{summary_text}"

    # Send to CEO
    ceo_id = settings.CEO_TELEGRAM_ID
    if not ceo_id:
        return
        
    async with httpx.AsyncClient() as client:
        try:
            await client.post(
                f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}/sendMessage",
                json={
                    "chat_id": ceo_id,
                    "text": msg,
                    "parse_mode": "Markdown"
                }
            )
            logger.info(f"Sent evening summary to {ceo_id}")
        except Exception as e:
            logger.error(f"Failed to send evening summary: {e}")

# Beat Schedule
celery_app.conf.beat_schedule = {
    "daily-report-reminder-1800": {
        "task": "app.worker.send_daily_report_reminder",
        "schedule": crontab(hour=18, minute=0), # 18:00 Dubai time
    },
    "evening-summary-1900": {
        "task": "app.worker.send_evening_summary",
        "schedule": crontab(hour=19, minute=0), # 19:00 Dubai time
    },
    "daily-digest-0900": {
        "task": "app.worker.send_daily_digest",
        "schedule": crontab(hour=9, minute=0), # 09:00 Dubai time
    },
    "check-stale-tasks-1000": {
        "task": "app.worker.check_stale_tasks",
        "schedule": crontab(hour=10, minute=0), # 10:00 Dubai time
    },
    "check-deadlines-0930": {
        "task": "app.worker.check_deadlines",
        "schedule": crontab(hour=9, minute=30), # 09:30 Dubai time
    },
    "check-calendar-events-every-5-minutes": {
        "task": "app.worker.check_calendar_events",
        "schedule": 300.0,  # 5 minutes
    },
}


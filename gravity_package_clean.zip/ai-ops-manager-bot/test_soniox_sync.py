import asyncio
import time
import os
import logging
from app.services.soniox_service import soniox_service

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def test_sync_speed():
    # Use the same test file
    test_file = "storage/uploads/a1af470a-9e18-468f-a86b-e4ebc59407f2.mp3"
    
    if not os.path.exists(test_file):
        logger.error(f"Test file not found: {test_file}")
        return

    file_size = os.path.getsize(test_file)
    logger.info(f"Starting SYNC benchmark for {test_file} ({file_size} bytes)")

    start_time = time.time()

    try:
        # Call synchronous transcription
        # This includes upload + processing
        transcript = await soniox_service.transcribe_synchronous(test_file, "en")
        
        total_time = time.time() - start_time
        logger.info(f"TOTAL TIME (SYNC): {total_time:.2f}s")
        logger.info(f"Transcript length: {len(transcript.get('text', ''))} chars")

    except Exception as e:
        import traceback
        logger.error(f"Benchmark failed: {repr(e)}")
        logger.error(traceback.format_exc())

if __name__ == "__main__":
    asyncio.run(test_sync_speed())

# AI-Ops Manager Bot 🤖

Telegram bot for task management and daily reporting automation at SORP Group.

## 🚀 Quick Start

### 1. Prerequisites
- Docker & Docker Compose
- Python 3.11+ (for local development)
- API Keys:
    - **Telegram Bot Token**: Get from [@BotFather](https://t.me/BotFather)
    - **OpenAI API Key**: Get from [OpenAI Platform](https://platform.openai.com/api-keys)
    - **Asana Access Token**: Get from [Asana Developer Console](https://app.asana.com/0/my-apps)

### 2. Configuration
1. Copy the example environment file:
   ```bash
   cp .env.example .env
   ```
2. Open `.env` and fill in your API keys and IDs.
   - `CEO_TELEGRAM_ID`: Your numeric Telegram ID (use [@userinfobot](https://t.me/userinfobot) to find it).

### 3. Run with Docker
```bash
# Build and start services
docker compose up --build

# Run in background
docker compose up -d
```

### 4. Development
```bash
# Install dependencies
pip install -e ".[dev]"

# Run tests
pytest
```

## 🏗 Project Structure
- `app/`: Main application code
    - `api/`: FastAPI endpoints
    - `bot/`: Telegram bot logic
    - `db/`: Database models & migrations
    - `tasks/`: Celery background tasks
- `tests/`: Automated tests
